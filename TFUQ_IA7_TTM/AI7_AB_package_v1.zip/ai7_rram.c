// ai7_rram.c -- Minimal 1T1R crossbar driver (abstract transport)
// SPDX-License-Identifier: MIT
#include "ai7_rram.h"
#include <string.h>
#include <math.h>

// Register map (see REGMAP.md)
#define REG_CTRL        0x0000
#define REG_STATUS      0x0004
#define REG_VSET_mV     0x0010
#define REG_VRST_mV     0x0014
#define REG_VREAD_mV    0x0018
#define REG_TOL_PCT     0x0020
#define REG_MAX_ITER    0x0021
#define REG_ADDR_ROW    0x0100
#define REG_ADDR_COL    0x0102
#define REG_DATA_uS     0x0200
#define REG_CMD         0x0300
#define REG_WEAR_BASE   0x0400

#define CMD_NOP         0x00
#define CMD_WRITE       0x01
#define CMD_READ        0x02
#define CMD_PROGRAM_BLK 0x03
#define CMD_READ_BLK    0x04

static inline int write_u16(uint16_t reg, uint16_t v){ uint8_t b[2]={(uint8_t)(v&0xFF),(uint8_t)(v>>8)}; return rram_bus_write(reg,b,2); }
static inline int write_u32(uint16_t reg, uint32_t v){ uint8_t b[4]={(uint8_t)(v&0xFF),(uint8_t)((v>>8)&0xFF),(uint8_t)((v>>16)&0xFF),(uint8_t)((v>>24)&0xFF)}; return rram_bus_write(reg,b,4); }
static inline int read_u32 (uint16_t reg, uint32_t* v){ uint8_t b[4]; int rc=rram_bus_read(reg,b,4); *v=b[0]|(b[1]<<8)|(b[2]<<16)|(b[3]<<24); return rc; }

int rram_init(void){
    if (rram_bus_init()!=0) return -1;
    // Clear CTRL, NOP
    write_u16(REG_CTRL, 0);
    write_u16(REG_CMD, CMD_NOP);
    return 0;
}

int rram_set_bias(float v_set, float v_reset, float v_read){
    write_u32(REG_VSET_mV , (uint32_t)lrintf(v_set*1000.0f));
    write_u32(REG_VRST_mV , (uint32_t)lrintf(v_reset*1000.0f));
    write_u32(REG_VREAD_mV, (uint32_t)lrintf(v_read*1000.0f));
    return 0;
}

int rram_set_verify(float tol_pct, uint8_t max_iter){
    rram_bus_write(REG_TOL_PCT, (const uint8_t*)&tol_pct, sizeof(float)); // store as float
    rram_bus_write(REG_MAX_ITER, &max_iter, 1);
    return 0;
}

int rram_write_cell(uint16_t row, uint16_t col, float conductance_uS){
    write_u16(REG_ADDR_ROW, row);
    write_u16(REG_ADDR_COL, col);
    rram_bus_write(REG_DATA_uS, (const uint8_t*)&conductance_uS, sizeof(float));
    write_u16(REG_CMD, CMD_WRITE);
    return 0;
}

int rram_read_cell(uint16_t row, uint16_t col, float* conductance_uS_out){
    write_u16(REG_ADDR_ROW, row);
    write_u16(REG_ADDR_COL, col);
    write_u16(REG_CMD, CMD_READ);
    return rram_bus_read(REG_DATA_uS, (uint8_t*)conductance_uS_out, sizeof(float));
}

int rram_program_block(uint16_t row0, uint16_t col0, const float* uS, uint16_t nrows, uint16_t ncols){
    // naive row-major push
    for(uint16_t r=0;r<nrows;r++){
        for(uint16_t c=0;c<ncols;c++){
            int rc = rram_write_cell(row0+r, col0+c, uS[r*ncols+c]);
            if (rc) return rc;
        }
    }
    write_u16(REG_CMD, CMD_PROGRAM_BLK);
    return 0;
}

int rram_read_block(uint16_t row0, uint16_t col0, float* uS, uint16_t nrows, uint16_t ncols){
    for(uint16_t r=0;r<nrows;r++){
        for(uint16_t c=0;c<ncols;c++){
            int rc = rram_read_cell(row0+r, col0+c, &uS[r*ncols+c]);
            if (rc) return rc;
        }
    }
    return 0;
}

int rram_get_status(uint32_t* status){
    return read_u32(REG_STATUS, status);
}

int rram_get_wear_map(uint16_t row0, uint16_t col0, uint16_t h, uint16_t w, uint16_t* wear_out){
    // Linearized read (mocked as contiguous registers)
    for(uint16_t r=0;r<h;r++){
        for(uint16_t c=0;c<w;c++){
            uint16_t reg = REG_WEAR_BASE + 2*(r*w+c);
            uint8_t b[2]={0};
            int rc = rram_bus_read(reg, b, 2);
            if (rc) return rc;
            wear_out[r*w+c] = b[0] | (b[1]<<8);
        }
    }
    return 0;
}
