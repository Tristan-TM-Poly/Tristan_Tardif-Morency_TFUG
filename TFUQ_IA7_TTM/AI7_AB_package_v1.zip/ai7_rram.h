// ai7_rram.h -- Minimal 1T1R crossbar driver (I2C/SPI abstracted)
// SPDX-License-Identifier: MIT
#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

// Transport hook (to be implemented per board)
int rram_bus_init(void);
int rram_bus_write(uint16_t reg, const uint8_t* data, uint16_t len);
int rram_bus_read (uint16_t reg, uint8_t* data, uint16_t len);

// Basic ops
int rram_init(void);
int rram_set_bias(float v_set, float v_reset, float v_read);
int rram_set_verify(float tol_pct, uint8_t max_iter);
int rram_write_cell(uint16_t row, uint16_t col, float conductance_uS);
int rram_read_cell (uint16_t row, uint16_t col, float* conductance_uS_out);
int rram_program_block(uint16_t row0, uint16_t col0, const float* uS, uint16_t nrows, uint16_t ncols);
int rram_read_block   (uint16_t row0, uint16_t col0, float* uS, uint16_t nrows, uint16_t ncols);
int rram_get_status(uint32_t* status);
int rram_get_wear_map(uint16_t row0, uint16_t col0, uint16_t h, uint16_t w, uint16_t* wear_out);

#ifdef __cplusplus
}
#endif
