#!/usr/bin/env python3
"""
ai7_postprocess_multiindex.py
- Build a multi-index table from SPICE measurement CSV/JSON and/or filename-embedded params.
- Generate stability and energy plots versus parameters (Df, Q1, Q2, g0, g1, g2).
- If a hp_v4_summary.json is provided, use its "sweeps" to order axes.
Usage:
  python ai7_postprocess_multiindex.py --meas_csv ./out/spice_meas_summary.csv \
      --summary ./hp_v4_summary.json --out ./out_mi
Filename parsing:
  Accepts tokens like Df=1.00_Q1=100_Q2=80_g0=1.0_g1=0.95_g2=0.90 in file names.
"""
import argparse, re, json
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

def parse_params_from_name(name: str):
    params = {}
    for key in ["Df","Q1","Q2","g0","g1","g2"]:
        m = re.search(rf'{key}\s*=?\s*([-+]?\d*\.?\d+)', name)
        if m:
            try: params[key] = float(m.group(1))
            except: pass
    return params

def load_meas_csv(csv_path: Path):
    df = pd.read_csv(csv_path)
    # Add parsed params from file name if missing
    for k in ["Df","Q1","Q2","g0","g1","g2"]:
        if k not in df.columns:
            df[k] = None
    for i, row in df.iterrows():
        params = parse_params_from_name(str(row.get("file","")))
        for k,v in params.items():
            df.loc[i,k] = v
    # Coerce numeric
    for k in ["Df","Q1","Q2","g0","g1","g2"]:
        df[k] = pd.to_numeric(df[k], errors="coerce")
    return df

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--meas_csv", type=str, required=True)
    ap.add_argument("--summary", type=str, default=None)
    ap.add_argument("--out", type=str, default="./out_mi")
    args = ap.parse_args()

    outdir = Path(args.out); outdir.mkdir(parents=True, exist_ok=True)
    df = load_meas_csv(Path(args.meas_csv))

    # Build MultiIndex table on available parameters
    idx_keys = [k for k in ["Df","Q1","Q2","g0","g1","g2"] if df[k].notna().any()]
    if not idx_keys: idx_keys = ["file"]
    metrics = [c for c in df.columns if c not in ["file"] + ["Df","Q1","Q2","g0","g1","g2"]]
    pivot = df.set_index(idx_keys)[metrics]
    pivot.sort_index(inplace=True)
    pivot.to_csv(outdir / "spice_multiindex_table.csv")

    # Stability proxy (phase margin at 50kHz if available; else use -PHASE_50kHZ)
    phase_col = None
    for c in metrics:
        if "PHASE_50" in c.upper():
            phase_col = c; break
    if phase_col is not None:
        # We assume phase margin positive is good
        stab = pivot[[phase_col]].rename(columns={phase_col: "phase_deg_50k"})
        stab.to_csv(outdir / "stability_phase_50k.csv")
        # Simple plots vs Df when available
        if "Df" in idx_keys:
            sub = stab.reset_index()
            plt.figure()
            plt.plot(sub["Df"], sub["phase_deg_50k"], marker="o")
            plt.xlabel("Df")
            plt.ylabel("Phase @50k (deg)")
            plt.title("Stability proxy vs Df")
            plt.tight_layout()
            plt.savefig(outdir / "stability_vs_Df.png", dpi=200)
            plt.close()

    # Energy plot if E_REC present
    e_col = None
    for c in metrics:
        if c.upper().startswith("E_REC"):
            e_col = c; break
    if e_col is not None:
        en = pivot[[e_col]].rename(columns={e_col: "E_REC"})
        en.to_csv(outdir / "energy_recovery.csv")
        if "Df" in idx_keys:
            sub = en.reset_index()
            plt.figure()
            plt.plot(sub["Df"], sub["E_REC"], marker="o")
            plt.xlabel("Df")
            plt.ylabel("E_REC (units of log)")
            plt.title("Recovered energy proxy vs Df")
            plt.tight_layout()
            plt.savefig(outdir / "energy_vs_Df.png", dpi=200)
            plt.close()

if __name__ == "__main__":
    main()
