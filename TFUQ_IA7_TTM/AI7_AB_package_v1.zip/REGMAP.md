# AI-7 RRAM Minimal Register Map (REGMAP.md)

> Version: v1.0 (baseline demo). Addresses are 16‑bit. Endianness: little.

| Address     | Name         | Width | Description |
|-------------|--------------|-------|-------------|
| 0x0000      | REG_CTRL     | 16    | Control flags (bit0: enable, bit1: reset) |
| 0x0004      | REG_STATUS   | 32    | Status (bit0: busy, bit1: error, bit2: verify_fail, ... ) |
| 0x0010      | REG_VSET_mV  | 32    | Programming SET voltage in mV |
| 0x0014      | REG_VRST_mV  | 32    | Programming RESET voltage in mV |
| 0x0018      | REG_VREAD_mV | 32    | Read voltage in mV |
| 0x0020      | REG_TOL_PCT  | 32f   | Verify tolerance (percent) as float |
| 0x0021      | REG_MAX_ITER | 8     | Max verify iterations |
| 0x0100      | REG_ADDR_ROW | 16    | Row address |
| 0x0102      | REG_ADDR_COL | 16    | Column address |
| 0x0200      | REG_DATA_uS  | 32f   | Conductance (micro‑Siemens) |
| 0x0300      | REG_CMD      | 16    | Command (0:NOP,1:WRITE,2:READ,3:PROGRAM_BLK,4:READ_BLK) |
| 0x0400..    | REG_WEAR_*   | 16×N  | Wear counters (per‑cell or per‑word) |

**Notes**
- Cette map est **minimale** pour prototypage HiL. Adapte les adresses/largeurs à ton ASIC/FPGA.
- Les commandes `PROGRAM_BLK`/`READ_BLK` déclenchent des séquences internes (DMA/row driver).
- Les tolérances de vérification sont stockées en **float** pour flexibilité.
