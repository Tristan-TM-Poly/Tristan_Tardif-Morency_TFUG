\
# TTM_Optech_Raman_AI_TFUG_v1.0 (FR)
Paquet Overleaf prêt à l'emploi (1 colonne). Figures en TikZ+PNG, bibliographie IEEE, feuille d'expérimentation et script de validation.
## Utilisation
1. Importer le ZIP dans Overleaf.
2. Compiler `main.tex` (pdfLaTeX). Le PDF est généré.
3. Les figures PNG sont utilisées par défaut; les versions `.tikz` peuvent être incluses via `\input{}` si désiré.
## Validation
Exécuter `python scripts/validate_pipeline.py` pour produire `output/validation_summary.txt`.
