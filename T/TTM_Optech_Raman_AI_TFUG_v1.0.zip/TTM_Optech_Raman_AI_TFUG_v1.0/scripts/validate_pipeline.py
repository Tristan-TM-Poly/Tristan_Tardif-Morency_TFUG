\
import hashlib, json, os, pathlib, datetime
base = pathlib.Path(__file__).resolve().parents[1]
files = sorted([p for p in base.rglob('*') if p.is_file() and p.suffix not in {'.zip'}])
lines = ["Validation du paquet TFUG Raman (FR)",
         f"Date: {datetime.datetime.now().isoformat()}",
         f"Racine: {base}",""]
for f in files:
    h = hashlib.sha256(f.read_bytes()).hexdigest()
    rel = f.relative_to(base)
    lines.append(f"{rel}  SHA256={h}")
out = base/'output'/'validation_summary.txt'
out.write_text("\n".join(lines), encoding='utf-8')
print(f"Ecrit: {out}")
