\
#!/usr/bin/env bash
set -e
latexmk -pdf -interaction=nonstopmode main.tex
mkdir -p output
cp main.pdf output/TTM_Optech_Raman_AI_TFUG_Report_FR.pdf || true
