# Répondre aux questions laboratoire

**User:** Tristan Tardif-Morency (tristan-tm@hotmail.com)  
**Created:** 10/24/2025 16:53:22  
**Updated:** 10/24/2025 16:55:15  
**Exported:** 10/31/2025 16:18:51  
**Link:** [https://chatgpt.com/c/68fbe741-f620-8320-8e02-0981ca430e19](https://chatgpt.com/c/68fbe741-f620-8320-8e02-0981ca430e19)  

## Prompt:
Laboratory 3\_Alignment-Deep-Etching\_A2020.pdf

PDF

Walker2001DRIE.pdf

PDF

peux-tu m'aider à répondre en anglais au questions ''Post laboratory questions'' pour ce laboratoire stp :

Pensé pendant34s

## Response:
Below are clear, exam-ready English answers to the **Post-laboratory questions (6 a → g)**. I keep it direct and practical — state the facts, explain the mechanism, and give formulas/benchmarks you can quote in your report. Where useful I give short examples or recommended settings.

**References:** course lab handout and Walker (2001) DRIE review.

Laboratory 3\_Alignment-Deep-Etc…

Walker2001DRIE

* * *

### a) Purpose of the lithography test pattern and how to detect over/under-exposure and over/under-development

**Purpose.** The test pattern (Figure 6.1) is a process control / exposure & development test structure: it contains a range of feature sizes, line/space patterns, islands, and resolution targets used to verify:

*   correct exposure dose and focus,
*   development time and aggressiveness,
*   resolution limits and pattern fidelity,
*   absence of bridging, footing or residuals.  
    (Used to confirm that the resist and exposure parameters will reproduce the smallest features on the real mask).
    Laboratory 3\_Alignment-Deep-Etc…

**How to detect problems (practical signs under microscope / profilometry / reflectometer):**

*   **Over-exposure**
    *   Fine lines are **widened**; isolated lines may **bridge** to neighbors.
    *   Small holes or narrow gaps **close up** (appear partially or fully filled with resist).
    *   Resist thickness at edges may show “foot” (reduced slope) under SEM/optical.
*   **Under-exposure**
    *   Small features **do not develop** (remain resist-covered) or appear **broken/incomplete**.
    *   Edges are **ragged** or missing; contrast is low.
*   **Over-development**
    *   Loss of fine detail: lines become **thinner** than nominal (resist eroded).
    *   Narrow features disappear; line bottoms or trapezoids indicate excessive dissolution.
*   **Under-development**
    *   Resist residues remain in trenches/holes; openings are **shallower** than expected.
    *   Measured step height (profilometer) shows incomplete removal of resist at intended openings.

**Checks / measurements to confirm:**

*   Optical inspection of smallest test features (pass/fail).
*   Reflectometer or profilometer to measure residual resist thickness and compare to expected (detect under-development).
    Laboratory 3\_Alignment-Deep-Etc…

* * *

### b) How back-side alignment works (vs front-side alignment)

**Front-side alignment** aligns the mask directly to features on the wafer’s top surface using top-side microscopes (what you performed in the lab).

Laboratory 3\_Alignment-Deep-Etc…

**Back-side alignment** (used when patterns on the wafer back must align to front features or when processing from the wafer back) works as follows:

1.  **Marks on both sides:** Alignment marks are placed on the back side (or special through-wafer marks are used).
2.  **IR or transmissive alignment optics:** Because silicon is partially transparent in the near-infrared, specialized alignment microscopes use IR illumination to see through the wafer and image front-side marks from the back (or vice versa).
3.  **Carrier / chuck considerations:** The wafer is held on a double-sided chuck designed for back-side alignment (good flatness and thermal coupling).
4.  **Procedure:** the system images the back-side mark and the corresponding front-side mark (via IR through the wafer) and adjusts X/Y/θ until the marks coincide; exposure is then performed from the appropriate side.
5.  **When used:** through-wafer vias, MEMS released structures, SOI devices where front/back features must be registered precisely.

**Key differences and constraints:**

*   Requires IR-capable alignment optics or transparent alignment windows; front alignment uses visible light.
*   Thermal/warpage and chuck mounting can change the relative position; accuracy depends on wafer flatness and the quality of clamping.
    Laboratory 3\_Alignment-Deep-Etc…

* * *

### c) Two ways to change the etch-wall angle (control parameters) — practical knobs and their effects

You can change sidewall angle by altering (1) the balance between **passivation** and **ion-assisted removal** and (2) the **reactive chemistry / temperature** (cryogenic). Two distinct practical approaches:

**1\. Change passivation vs. etch balance (Bosch process):**

*   **Increase deposition (passivation) step** or **increase c-C4F8 flow** → thicker sidewall polymer → more vertical or even slightly positive profiles; reduces lateral etching.
*   **Decrease passivation (shorter deposition time or less C4F8)** or **increase RF bias / ion energy** → more ion sputtering of sidewall polymer → sloped or undercut profiles (more isotropic).
*   **Practical use:** tune etch:deposition time ratio and C4F8/SF6 flows (Walker: modify cycle times and gas ratio). Beware: too much passivation can cause “bottling” or polymer build-up; too little gives undercut/roughness.
    Walker2001DRIE

**2\. Change temperature / oxygen content (Cryogenic process):**

*   **Lower stage temperature (more cryo)** and **adjust oxygen** → thicker SiOxFy protective layer on sidewalls → smoother, very anisotropic, positive profiles.
*   **Raise temperature slightly** or **increase oxygen** content (within limits) → profile becomes more positive or more etched depending on O₂ fraction; small adjustments produce measurable angle changes. Cryo is very sensitive to temperature and oxygen flow (Walker recommends precise temperature control and low-flow O₂ MFC).
    Walker2001DRIE

(Other knobs: chamber pressure and ICP/bias powers affect mean free path and ion energy — lowering pressure / increasing ICP power can improve transport into deep features and change wall angle by changing ion/neutral balance.)

Walker2001DRIE

* * *

### d) Effect of lateral feature dimension on etching profile; advantage of using SOI

**Effect (ARDE / microloading):**

*   **Aspect-ratio dependent etching (ARDE):** narrow features (high aspect ratio) etch **slower** than wide features because reactant transport into and etch product removal out of deep, narrow trenches/vias is limited. The incremental etch rate typically decreases with increasing aspect ratio. Walker shows that vias are affected more strongly than trenches.
    Walker2001DRIE
*   **Feature geometry effects:** isolated small features may etch to different depths than dense patterns (microloading); convex corners etch differently from concave corners (corner-enhanced etch or undercut).
*   **Consequences:** non-uniform depths across a chip when multiple lateral sizes are present; “notching” at buried layers; more sidewall roughness at top of deep narrow features.

**Advantage of SOI:**

*   **Buried oxide = etch-stop / depth control:** SOI device layer thickness defines the etch depth precisely without requiring full wafer through-etch, so depth is controlled by the buried oxide stop. This avoids large process windows to hit widely differing depths and reduces back-side handling for through-wafer etches.
    Laboratory 3\_Alignment-Deep-Etc…
*   **Reduces issues with through-wafer ARDE and notching** because you stop at the oxide instead of etching through to the back side. Also simplifies subsequent micromachining steps (release, membranes).

* * *

### e) Etch selectivity (resist : silicon) and minimum resist thickness for this process

**Typical etch selectivity numbers (practical ranges):**

*   **Bosch process (typical):** selectivity to photoresist commonly **~30–100:1**, typical quoted value ≈ **75:1** under moderate conditions (depends strongly on open area, aspect ratio and process tuning). Walker gives examples where selectivity varied (e.g., 35:1 in one tested condition and ~75:1 as a typical value).
    Walker2001DRIE
*   **Cryogenic process:** higher selectivity to resist and oxide; **\>100:1** for resist and even higher for oxide masks (Walker: cryo selectivity >100:1 for resist, up to 200:1 for oxide in some cases).
    Walker2001DRIE

**Minimum resist thickness (practical rule and formula):**  
Use the formula

$$
t_{\text{resist(min)}} \;=\; \frac{d_{\text{Si}}}{S}
$$

where  $d_{\text{Si}}$  is the silicon etch depth you plan and  $S$  is the resist:Si selectivity.

**Example / recommendation (lab context):**

*   If you plan to etch **30 µm** of silicon with Bosch and take  $S=75$ :  
     $t_{\text{resist(min)}} \approx 30\ \mu\text{m} / 75 \approx 0.4\ \mu\text{m}.$   
    — In practice you should add margin (edge erosion, loading, non-uniformity), so use **≥1 µm** resist or prefer a hard mask for deeper/high-aspect structures.
*   **For cryo**, because resist cracking is a risk above ~**1.5 µm** (Walker recommends resist **≤1.5 µm** for cryo), use **oxide** or metal hard mask for deep etches.
    Walker2001DRIE

**Practical lab note:** the lab uses AZ 900 MIR (spin @3000 rpm and measure thickness with reflectometer). Always measure the actual resist thickness after spin and ensure it exceeds the safety margin computed above; for very deep etches prefer an oxide or metal hard mask rather than relying solely on resist.

Laboratory 3\_Alignment-Deep-Etc…

* * *

### f) Why deep-reactive-ion etching (DRIE) is preferred over LIGA — and LIGA’s main advantage

**Why DRIE (Bosch/cryogenic) is usually preferred:**

*   **Accessibility & cost:** DRIE (ICP systems) is widely available in microfabrication labs and does not require synchrotron X-ray sources or specialized X-ray masks.
*   **Process speed & integration:** DRIE integrates directly with standard silicon CMOS/MEMS fab flows and can be automated; it is faster and simpler for many silicon MEMS applications.
*   **Flexibility:** DRIE can etch a wide variety of patterns, works on standard silicon wafers (and SOI), and is reproducible for production. Walker documents widespread industrial use of Bosch/cryogenic methods for MEMS.
    Walker2001DRIE

**Major advantage of LIGA over DRIE:**

*   **Extremely high aspect ratio with near-perfect vertical sidewalls and very smooth surfaces** — LIGA (X-ray lithography + electroplating) can produce structures with **exceptionally high aspect ratios and dimensional accuracy** and is ideal when those exacting geometries or metal microstructures are needed (moulds, microfluidic metal parts, very tall polymer molds). LIGA can exceed what DRIE routinely achieves in a single process step.  
    **Trade-off:** LIGA gives superb geometry but requires access to X-ray synchrotron or specialized X-ray tools and typically higher cost/complexity. (Hence DRIE is the practical choice for routine silicon MEMS.)

* * *

### g) Three main masking materials for DRIE ICP — advantages / disadvantages

**1\. Photoresist (organic resist, e.g., AZ, SPR):**

*   **Advantages:** easy to pattern by standard photolithography, low cost, fast iteration, compatible with Bosch. Bosch is relatively insensitive to resist type (no need for hard bake).
    Walker2001DRIE
*   **Disadvantages:** limited selectivity for very deep etches (resist may be consumed), possible mask erosion and footing; resist may **crack at cryogenic temperatures** if too thick (Walker: cryo recommends resist ≤1.5 µm). For deep/high-aspect processes, resist may be insufficient — then a hard mask is required.
    Walker2001DRIE

**2\. Silicon dioxide or silicon nitride (dielectric hard masks):**

*   **Advantages:** much **higher selectivity** (oxide/nitride withstands etch far longer than resist), can be used for deep etches and cryo where thick resist cannot be used, good dimensional stability, withstands post-process temperatures. Walker reports oxide masks give very high selectivity (cryo: up to hundreds:1).
    Walker2001DRIE
*   **Disadvantages:** need an extra deposition and mask-etch step (adds process complexity/time); possible stress and adhesion issues; oxide patterning requires its own lithography and etch chemistry.

**3\. Metal masks (e.g., Al, Cr, Ni, electroplated metal):**

*   **Advantages:** **very high selectivity** and mechanical robustness for extremely deep etches; electroplated metal (or evaporated metal) allows very thick and durable masks (especially for through-wafer holes). Useful when pattern must survive long etch times.
*   **Disadvantages:** can contaminate the chamber if not handled correctly; metal removal after etch can require aggressive chemistries; adhesion to silicon must be controlled; patterning/processing of metal masks can be more complex.

**Practical guidance:** for shallow/moderate depth DRIE (tens of microns) photoresist is often acceptable (Bosch); for deep etches or cryo where resist is too thin or may crack, **use oxide or metal hard masks**.

Walker2001DRIE

* * *

If you want, I can:

*   convert these answers into a polished **report paragraph** ready to paste into your lab hand-in, or
*   produce a concise **bullet checklist** for the lab notebook (equipment settings to record, thickness checks, example calculations for resist thickness vs planned etch depth).

Which format do you want for submission?



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)