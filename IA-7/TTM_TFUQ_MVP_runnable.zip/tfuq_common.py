
import math
import pandas as pd

def tc_tfuq(df, Df=3.05, alpha_f=0.10, eta_lambda=0.25, eta_mu=0.15, phi=(0.1,0.05,0.0)):
    df = df.copy()
    deltaD = Df - 3.0
    th = (phi[0]**2 + phi[1]**2 + phi[2]**2) ** 0.5
    phase_gain = 1.0 + 0.02*math.sin(th)

    def _row(r):
        w_eff = float(r["omega_log_K"]) * (1.0 + alpha_f*deltaD)
        lam_eff = float(r["lambda_ep"]) * (1.0 + eta_lambda*deltaD)
        mu_eff = float(r["mu_star"]) * (1.0 - eta_mu*deltaD)
        fam = str(r.get("family","")).lower()
        kappa_aniso = 0.15 if any(x in fam for x in ["lamellar","2d","nickelate","kagome","cuprate","interface"]) else 0.0
        aniso_gain = 1.0 + kappa_aniso
        den = lam_eff - mu_eff*(1.0 + 0.62*lam_eff)
        if den <= 0:
            return 0.0, w_eff, lam_eff, mu_eff
        Tc = (w_eff/1.2) * math.exp(-1.04*(1.0 + lam_eff)/den) * phase_gain * aniso_gain
        return max(0.0, Tc), w_eff, lam_eff, mu_eff

    out = df.apply(lambda r: _row(r), axis=1, result_type="expand")
    df["Tc_est_K"] = out[0]
    df["omega_log_K_eff"] = out[1]
    df["lambda_eff"] = out[2]
    df["mu_star_eff"] = out[3]
    df = df.sort_values("Tc_est_K", ascending=False).reset_index(drop=True)
    return df
