
import argparse, pandas as pd, os, sys
from tfuq_common import tc_tfuq

def main():
    ap = argparse.ArgumentParser(description="Rank superconductors with TFUQ-modified Allen–Dynes")
    ap.add_argument("--in_csv", required=True, help="Input CSV with columns: name,family,mu_star,lambda_ep,omega_log_K,...")
    ap.add_argument("--out_csv", required=True, help="Output ranked CSV")
    ap.add_argument("--top_csv", required=False, default="", help="Optional Top-N CSV")
    ap.add_argument("--topN", type=int, default=50, help="How many rows to export to top_csv")
    ap.add_argument("--Df", type=float, default=3.05)
    ap.add_argument("--alpha_f", type=float, default=0.10)
    ap.add_argument("--eta_lambda", type=float, default=0.25)
    ap.add_argument("--eta_mu", type=float, default=0.15)
    args = ap.parse_args()

    df = pd.read_csv(args.in_csv)
    ranked = tc_tfuq(df, Df=args.Df, alpha_f=args.alpha_f, eta_lambda=args.eta_lambda, eta_mu=args.eta_mu)
    ranked.to_csv(args.out_csv, index=False)
    if args.top_csv:
        ranked.head(args.topN).to_csv(args.top_csv, index=False)
    print(f"Wrote {args.out_csv}" + (f" and {args.top_csv}" if args.top_csv else ""))

if __name__ == "__main__":
    main()
