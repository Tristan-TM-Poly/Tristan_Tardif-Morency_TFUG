
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import JSONResponse
import pandas as pd, os, io
from tfuq_common import tc_tfuq

app = FastAPI(title="TFUQ MVP API")

@app.get("/api/health")
def health():
    return {"ok": True}

@app.post("/api/sc/tfuq/rank")
async def rank(
    file: UploadFile = File(...),
    Df: float = Form(3.05),
    alpha_f: float = Form(0.10),
    eta_lambda: float = Form(0.25),
    eta_mu: float = Form(0.15),
    topN: int = Form(50),
):
    content = await file.read()
    df = pd.read_csv(io.BytesIO(content))
    ranked = tc_tfuq(df, Df=Df, alpha_f=alpha_f, eta_lambda=eta_lambda, eta_mu=eta_mu)
    out_dir = "/mnt/data/api_out"; os.makedirs(out_dir, exist_ok=True)
    out_csv = os.path.join(out_dir, "ranked.csv")
    top_csv = os.path.join(out_dir, "topN.csv")
    ranked.to_csv(out_csv, index=False)
    ranked.head(topN).to_csv(top_csv, index=False)
    return JSONResponse({"ok": True, "out_csv": out_csv, "top_csv": top_csv, "rows": int(len(ranked))})
