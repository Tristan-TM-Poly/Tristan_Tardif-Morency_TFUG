
# TFUQ MVP (Runnable)

## 1) CLI (local)
```bash
python cli/rank_tfuq.py --in_csv /mnt/data/tfuq_ranked_200.csv --out_csv /mnt/data/out_rank.csv --top_csv /mnt/data/out_top.csv --topN 50
```

## 2) API (FastAPI)
```bash
uvicorn server.main:app --host 0.0.0.0 --port 8000
```
Then POST a CSV via multipart to `/api/sc/tfuq/rank` (fields: file, Df, alpha_f, eta_lambda, eta_mu, topN).

### Input CSV schema (minimum)
`name,family,mu_star,lambda_ep,omega_log_K` (+ optional: stiffness_GPa, DOS_EF)

Outputs are written to `/mnt/data/api_out/`.
