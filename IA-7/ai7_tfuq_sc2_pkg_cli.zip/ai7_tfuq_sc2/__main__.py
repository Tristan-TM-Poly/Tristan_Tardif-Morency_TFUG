
import argparse, sys, csv
from .ai7_tfuq_sc2 import (
    preset_materials, preset_scalings, Options, PinningModel, scan_over_Df,
    TFUQScaling, powlaw
)

def profile(name: str):
    name = name.lower()
    if name in ["cuprate", "ybco"]:
        return TFUQScaling(
            chi_v=powlaw(+0.15), chi_m=powlaw(-0.15), chi_ns=powlaw(+0.30),
            chi_lambdaep=powlaw(+0.20), chi_mu=powlaw(0.0), chi_theta=powlaw(+0.05),
            chi_N=powlaw(+0.10), chi_V=powlaw(+0.10), A_gap=lambda Df: 1.9
        )
    if name in ["mgb2"]:
        return TFUQScaling(
            chi_v=powlaw(+0.10), chi_m=powlaw(-0.10), chi_ns=powlaw(+0.20),
            chi_lambdaep=powlaw(+0.12), chi_mu=powlaw(0.0), chi_theta=powlaw(+0.05),
            chi_N=powlaw(+0.05), chi_V=powlaw(+0.05), A_gap=lambda Df: 1.76
        )
    if name in ["hydride","h3s"]:
        return TFUQScaling(
            chi_v=powlaw(+0.12), chi_m=powlaw(-0.12), chi_ns=powlaw(+0.25),
            chi_lambdaep=powlaw(+0.25), chi_mu=powlaw(0.0), chi_theta=powlaw(+0.10),
            chi_N=powlaw(+0.10), chi_V=powlaw(+0.10), A_gap=lambda Df: 2.1
        )
    return TFUQScaling(
        chi_v=powlaw(+0.10), chi_m=powlaw(-0.10), chi_ns=powlaw(+0.20),
        chi_lambdaep=powlaw(+0.15), chi_mu=powlaw(0.0), chi_theta=powlaw(+0.05),
        chi_N=powlaw(+0.10), chi_V=powlaw(+0.10), A_gap=lambda Df: 1.76
    )

def cmd_presets(args):
    mats = preset_materials()
    for k,v in mats.items():
        print(k, vars(v))

def cmd_scan(args):
    mats = preset_materials()
    scdefs = preset_scalings()
    if args.material.lower()=="ybco":
        scdefs["YBCO"] = profile("cuprate")
        mat = {"YBCO": mats["YBCO"]}
    elif args.material.lower()=="mgb2":
        scdefs["MgB2"] = profile("mgb2")
        mat = {"MgB2": mats["MgB2"]}
    elif args.material.lower()=="h3s":
        scdefs["H3S"]  = profile("hydride")
        mat = {"H3S": mats["H3S"]}
    elif args.material.lower()=="all":
        scdefs["YBCO"] = profile("cuprate")
        scdefs["MgB2"] = profile("mgb2")
        scdefs["H3S"]  = profile("hydride")
        mat = {"YBCO": mats["YBCO"], "MgB2": mats["MgB2"], "H3S": mats["H3S"]}
    else:
        print("Unknown material:", args.material); sys.exit(2)

    a,b,step = args.Df_range
    Df_vals = []
    x=a
    while x <= b+1e-12:
        Df_vals.append(round(x,12))
        x += step

    opt = Options(mode="mcmillan", T=args.T)
    pin = PinningModel(J0_base=args.J0, n=args.n, m=args.m) if args.pin else None

    rows = scan_over_Df(mat, scdefs, opt, Df_vals, pin=pin, Bext_T=args.Bext)

    with open(args.out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    print("Wrote", args.out, "rows:", len(rows))

def main():
    p = argparse.ArgumentParser(prog="ai7_tfuq_sc2")
    sub = p.add_subparsers()

    sp = sub.add_parser("presets", help="List material presets")
    sp.set_defaults(func=cmd_presets)

    ss = sub.add_parser("scan", help="Scan Tc/Jc across Df")
    ss.add_argument("--material", default="all", help="YBCO|MgB2|H3S|all")
    ss.add_argument("--Df-range", nargs=3, type=float, metavar=("START","END","STEP"), default=[0.8,1.5,0.02])
    ss.add_argument("--T", type=float, default=0.0, help="Temperature [K]")
    ss.add_argument("--Bext", type=float, default=1.0, help="External B [T]")
    ss.add_argument("--pin", action="store_true", help="Enable pinning model")
    ss.add_argument("--J0", type=float, default=5e12, help="J0_base [A/m^2]")
    ss.add_argument("--n", type=float, default=0.5, help="low-field exponent")
    ss.add_argument("--m", type=float, default=2.0, help="high-field exponent")
    ss.add_argument("--out", default="scan.csv", help="Output CSV path")
    ss.set_defaults(func=cmd_scan)

    args = p.parse_args()
    if hasattr(args, "func"):
        args.func(args)
    else:
        p.print_help()

if __name__ == "__main__":
    main()
