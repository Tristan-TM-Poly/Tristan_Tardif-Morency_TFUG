
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Optional, Dict, Any, Tuple, Iterable, List
import math

# Physical constants (SI)
kB   = 1.380649e-23
h    = 6.62607015e-34
hbar = h/(2*math.pi)
e    = 1.602176634e-19
mu0  = 4e-7*math.pi
Phi0 = h/(2*e)

Scaler = Callable[[float], float]

@dataclass
class MaterialBase:
    vF0: float
    m0: float
    ns0: float
    lambda_ep0: float = 0.0
    mu_star0: float = 0.1
    theta_b0: float = 300.0
    N0: float = 0.0
    V0: float = 0.0

@dataclass
class TFUQScaling:
    chi_v: Scaler        = lambda Df: 1.0
    chi_m: Scaler        = lambda Df: 1.0
    chi_ns: Scaler       = lambda Df: 1.0
    chi_lambdaep: Scaler = lambda Df: 1.0
    chi_mu: Scaler       = lambda Df: 1.0
    chi_theta: Scaler    = lambda Df: 1.0
    chi_N: Scaler        = lambda Df: 1.0
    chi_V: Scaler        = lambda Df: 1.0
    A_gap: Scaler        = lambda Df: 1.76

@dataclass
class Options:
    mode: str = "mcmillan"
    vortex_core_c: float = 0.5
    T: float = 0.0
    compute_Pc: bool = False
    Df_of_P: Optional[Callable[[float], float]] = None
    dP_max: float = 5e10
    root_tol: float = 1e-3

@dataclass
class PinningModel:
    J0_base: float = 1e12
    n: float = 0.5
    m: float = 2.0
    chi_pin: Scaler = lambda Df: 1.0

def safe_sqrt(x: float) -> float:
    return math.sqrt(max(x, 0.0))

def mcmillan_Tc(theta_b: float, lam_ep: float, mu_star: float) -> float:
    denom = lam_ep - mu_star*(1 + 0.62*lam_ep)
    if denom <= 1e-12:
        return 0.0
    expo = -1.04*(1+lam_ep)/denom
    return (theta_b/1.45)*math.exp(expo)

def bcs_Tc(omega_b: float, lam_eff: float) -> float:
    if lam_eff <= 1e-12:
        return 0.0
    return 1.14*(hbar*omega_b/kB)*math.exp(-1.0/lam_eff)

def lambda_eff_from_NVmu(N0: float, V0: float, mu_star: float) -> float:
    return max(0.0, N0*V0 - mu_star)

def xi0_from(vF: float, Delta0: float) -> float:
    return hbar*vF/(math.pi*Delta0) if Delta0>0 else float("inf")

def lambda0_from(m_eff: float, ns: float) -> float:
    denom = mu0*ns*(2*e)**2
    return safe_sqrt(m_eff/denom) if denom>0 else float("inf")

def temp_GL_scale(T: float, Tc: float) -> float:
    if Tc <= 0:
        return float("inf")
    if T <= 0:
        return 1.0
    x = 1.0 - T/max(Tc,1e-12)
    return 1.0/safe_sqrt(x) if x>1e-12 else float("inf")

def fields_from(xi: float, lam: float, kappa: float, c_core: float):
    if not (math.isfinite(xi) and math.isfinite(lam)) or xi<=0 or lam<=0:
        return (0.0, 0.0, 0.0)
    Bc  = Phi0/(2*math.sqrt(2)*math.pi*xi*lam)
    Bc2 = Phi0/(2*math.pi*xi*xi)
    k = max(kappa, 1.0001)
    Bc1 = Phi0/(4*math.pi*lam*lam)*(math.log(k) + c_core)
    return (Bc, Bc1, Bc2)

def Jd_from(Bc: float, lam: float) -> float:
    if lam<=0: return 0.0
    return (2.0/(3.0*math.sqrt(3.0)))*(Bc/(mu0*lam))

def Jpin_from(B: float, Bc2: float, Df: float, model: PinningModel) -> float:
    if model is None or Bc2<=0: return 0.0
    b = max(0.0, min(1.0, B/max(Bc2,1e-30)))
    J0 = max(0.0, model.J0_base * model.chi_pin(float(Df)))
    return J0 * (b**model.n) * ((1.0-b)**model.m)

def compute_all(Df: float, base: MaterialBase, sc: TFUQScaling, opt: Options) -> Dict[str, Any]:
    Df = float(Df)
    vF    = base.vF0*sc.chi_v(Df)
    m_eff = base.m0*sc.chi_m(Df)
    ns    = base.ns0*sc.chi_ns(Df)
    lam_ep= max(0.0, base.lambda_ep0*sc.chi_lambdaep(Df))
    mu_st = max(0.0, base.mu_star0*sc.chi_mu(Df))
    theta = max(1e-6, base.theta_b0*sc.chi_theta(Df))
    A_gap = max(1.0, sc.A_gap(Df))

    if opt.mode.lower()=="mcmillan":
        Tc = mcmillan_Tc(theta, lam_ep, mu_st)
        omega_b = (kB*theta)/hbar
    else:
        lam_eff = lambda_eff_from_NVmu(base.N0*sc.chi_N(Df), base.V0*sc.chi_V(Df), mu_st)
        omega_b = (kB*theta)/hbar
        Tc = bcs_Tc(omega_b, lam_eff)

    Delta0 = A_gap*kB*Tc
    xi0    = xi0_from(vF, Delta0) if Tc>0 else float("inf")
    lam0   = lambda0_from(m_eff, ns)

    scale = temp_GL_scale(opt.T, Tc)
    xiT, lamT = xi0*scale, lam0*scale
    kappa = lamT/xiT if (math.isfinite(lamT) and lamT>0 and math.isfinite(xiT) and xiT>0) else float("inf")
    Bc,Bc1,Bc2 = fields_from(xiT, lamT, kappa, opt.vortex_core_c)
    Hc,Hc1,Hc2 = Bc/mu0, Bc1/mu0, Bc2/mu0
    Jd = Jd_from(Bc, lamT)

    return {
        "inputs": {"Df": Df, "T_eval_K": opt.T, "mode": opt.mode},
        "renormalized": {"vF": vF, "m_eff": m_eff, "ns": ns, "lambda_ep": lam_ep, "mu_star": mu_st, "theta_b": theta, "A_gap": A_gap},
        "outputs": {
            "Tc_K": Tc, "Delta0_J": Delta0,
            "xi_m": xiT if opt.T>0 else xi0,
            "lambda_m": lamT if opt.T>0 else lam0,
            "kappa": kappa,
            "Bc_T": Bc, "Bc1_T": Bc1, "Bc2_T": Bc2,
            "Hc_Aperm": Hc, "Hc1_Aperm": Hc1, "Hc2_Aperm": Hc2,
            "Jd_Aperm2": Jd
        }
    }

def compute_with_pinning(Df: float, base: MaterialBase, sc: TFUQScaling, opt: Options,
                         pin: Optional[PinningModel]=None, Bext_T: float=0.0) -> Dict[str, Any]:
    r = compute_all(Df, base, sc, opt)
    o = r["outputs"]
    if pin is None:
        r["outputs"]["Jpin_Aperm2"] = 0.0
        r["outputs"]["Jc_Aperm2"] = o["Jd_Aperm2"]
        r["outputs"]["Bext_T"] = Bext_T
        return r
    Jpin = Jpin_from(Bext_T, o["Bc2_T"], Df, pin)
    r["outputs"]["Jpin_Aperm2"] = Jpin
    r["outputs"]["Jc_Aperm2"] = min(o["Jd_Aperm2"], Jpin if Jpin>0 else o["Jd_Aperm2"])
    r["outputs"]["Bext_T"] = Bext_T
    return r

def scan_over_Df(materials: Dict[str, MaterialBase],
                 scalings: Dict[str, TFUQScaling],
                 opt: Options,
                 Df_values: Iterable[float],
                 pin: Optional[PinningModel]=None,
                 Bext_T: float=0.0) -> List[Dict[str, Any]]:
    rows = []
    for name, base in materials.items():
        scmap = scalings.get(name, TFUQScaling())
        for Df in Df_values:
            r = compute_with_pinning(Df, base, scmap, opt, pin, Bext_T)
            o = r["outputs"]; ren = r["renormalized"]
            rows.append({
                "material": name, "Df": r["inputs"]["Df"], "T_eval_K": r["inputs"]["T_eval_K"], "mode": r["inputs"]["mode"],
                "Tc_K": o["Tc_K"],
                "xi_nm": (o["xi_m"]*1e9 if (o["xi_m"] is not None and o["xi_m"]!=float('inf')) else float('inf')),
                "lambda_nm": (o["lambda_m"]*1e9 if (o["lambda_m"] is not None and o["lambda_m"]!=float('inf')) else float('inf')),
                "kappa": o["kappa"],
                "Hc_Aperm": o["Hc_Aperm"], "Hc1_Aperm": o["Hc1_Aperm"], "Hc2_Aperm": o["Hc2_Aperm"],
                "Jd_Aperm2": o["Jd_Aperm2"], "Jpin_Aperm2": r["outputs"].get("Jpin_Aperm2", 0.0), "Jc_Aperm2": r["outputs"].get("Jc_Aperm2", o["Jd_Aperm2"]),
                "Bext_T": r["outputs"].get("Bext_T", 0.0),
                "vF": ren["vF"], "m_eff": ren["m_eff"], "ns": ren["ns"], "lambda_ep": ren["lambda_ep"], "mu_star": ren["mu_star"], "theta_b": ren["theta_b"],
            })
    return rows

def powlaw(alpha: float) -> Scaler:
    return lambda Df: max(1e-12, float(Df))**alpha

def preset_materials() -> Dict[str, MaterialBase]:
    me = 9.10938356e-31
    return {
        "YBCO": MaterialBase(vF0=2.0e5, m0=2.0*me, ns0=8e27, lambda_ep0=1.0, mu_star0=0.12, theta_b0=900.0),
        "MgB2": MaterialBase(vF0=3.0e5, m0=1.5*me, ns0=7e27, lambda_ep0=0.9, mu_star0=0.10, theta_b0=750.0),
        "FeSe": MaterialBase(vF0=1.5e5, m0=2.5*me, ns0=5e27, lambda_ep0=0.7, mu_star0=0.12, theta_b0=600.0),
        "NbTi": MaterialBase(vF0=2.5e5, m0=1.2*me, ns0=4e28, lambda_ep0=0.8, mu_star0=0.13, theta_b0=300.0),
        "Nb3Sn":MaterialBase(vF0=2.0e5, m0=1.5*me, ns0=3e28, lambda_ep0=1.1, mu_star0=0.13, theta_b0=400.0),
        "H3S":  MaterialBase(vF0=3.0e5, m0=1.0*me, ns0=1e29, lambda_ep0=2.0, mu_star0=0.10, theta_b0=1500.0),
    }

def preset_scalings() -> Dict[str, TFUQScaling]:
    return {
        name: TFUQScaling(
            chi_v=powlaw(+0.10), chi_m=powlaw(-0.10), chi_ns=powlaw(+0.20),
            chi_lambdaep=powlaw(+0.15), chi_mu=powlaw(0.0), chi_theta=powlaw(+0.05),
            chi_N=powlaw(+0.10), chi_V=powlaw(+0.10), A_gap=lambda Df: 1.76
        ) for name in preset_materials().keys()
    }

__all__ = [
    "kB","h","hbar","e","mu0","Phi0",
    "MaterialBase","TFUQScaling","Options","PinningModel",
    "compute_all","compute_with_pinning","scan_over_Df",
    "preset_materials","preset_scalings","powlaw"
]
