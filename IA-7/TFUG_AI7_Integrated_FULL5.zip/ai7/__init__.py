from .run_ai7 import main as run
