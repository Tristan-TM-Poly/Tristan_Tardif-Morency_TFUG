
import os, json, numpy as np, pandas as pd, matplotlib.pyplot as plt
from tfug.model import TFUGParams, run_pipeline
def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--ai7", default="out_ai7")
    ap.add_argument("--out", default="out_tfuq")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    feats = pd.read_csv(os.path.join(args.ai7, "ai7_features.csv"))
    rows = []
    for _, r in feats.iterrows():
        meta = dict(
            comp=str(r.get("id","raman_sample")),
            pressure_gpa=0.0, dH_eV_atom=0.0, tox_risk=0.1,
            Df=r["D0"], kappa_f=0.7, anis=np.tanh(1.5*r["anisotropy"]),
            flatness=r["flatness_w"], N0_eV=1.0,
            lambda_ph=0.8, theta_log_K=700.0, lambda_corr=0.2,
            slope_obs=r["slope"], flatness_w_obs=r["flatness_w"],
            notes="AI-7 Raman → TFUQ → TFUG"
        )
        rows.append(meta)
    cand = pd.DataFrame(rows)
    cand.to_csv(os.path.join(args.out, "candidate_tfuq_enriched.csv"), index=False)

    ranked = run_pipeline(cand, TFUGParams())
    ranked.to_csv(os.path.join(args.out, "ranked_tfuq.csv"), index=False)

    # export features summary (first sample for report convenience)
    if len(feats)>0:
        f0 = feats.iloc[0]
        pd.DataFrame([{
            "Df0_map": f0.get("Df_map", 2.0),
            "D1": f0.get("D1", 0.0),
            "D2": f0.get("D2", 0.0),
            "D3": f0.get("D3", 0.0),
            "eps_x": f0.get("eps_x", 1.0),
            "eps_y": f0.get("eps_y", 1.0),
            "eps_z": f0.get("eps_z", 1.0),
            "flatness_w": f0.get("flatness_w", 0.5),
            "slope": f0.get("slope", 0.0),
            "anisotropy_index": f0.get("anisotropy", 0.0)
        }]).to_csv(os.path.join(args.out,"tfuq_features.csv"), index=False)

    print("AI-7 → TFUG done ->", args.out)

if __name__=="__main__":
    main()
