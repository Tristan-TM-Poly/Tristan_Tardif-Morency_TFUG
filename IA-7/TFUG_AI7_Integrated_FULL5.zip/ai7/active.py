
import numpy as np, pandas as pd

def tfu_uncertainty_heuristic(rows):
    # Prioritize high misfit/energy regions indirectly via (flatness_w near target and slope far from target)
    # Simple ranking: higher |slope| and medium-high flatness_w
    scores = []
    for r in rows:
        s = abs(r["slope"]); f = r["flatness_w"]
        u = 0.6*s + 0.4*(1.0 - abs(f-0.8))
        scores.append(u)
    return np.array(scores)

def select_next(samples, k=3):
    u = tfu_uncertainty_heuristic(samples)
    idx = np.argsort(-u)[:k]
    return [samples[i] for i in idx]
