
import numpy as np, pandas as pd, os

def load_raman_folder(folder: str):
    rows = []
    for fn in sorted(os.listdir(folder)):
        if not fn.lower().endswith(".csv"): continue
        df = pd.read_csv(os.path.join(folder, fn))
        if set(["Shift_cm1","Intensity"]).issubset(df.columns):
            x = df["Shift_cm1"].values; y = df["Intensity"].values
            rows.append(dict(file=fn, x=x, y=y))
    return rows

def baseline_correction(y, lam=1e5, p=0.01, niter=10):
    # Asymmetric least squares baseline (simplified)
    L = len(y)
    D = np.diff(np.eye(L), 2)
    w = np.ones(L)
    for _ in range(niter):
        W = np.diag(w)
        Z = W + lam * (D.T @ D)
        z = np.linalg.solve(Z, w*y)
        w = p * (y > z) + (1-p) * (y < z)
    return y - z

def normalize(y): 
    y = y - np.min(y); m = np.max(y) + 1e-12; return y/m

def preproc_one(x, y):
    yb = baseline_correction(y)
    yn = normalize(yb)
    dx = float((x[-1]-x[0])/(len(x)-1))
    return dict(x=x, y=yn, dx=dx)
