
import numpy as np, pandas as pd
from tfug.wavelet import wavelet_features
from tfug.tfuq import quaternionize_features, anisotropy_index, eps_tensor
from tfug.inference_tfu import map_infer_Df

def extract_all(x, y, dx):
    feat, _ = wavelet_features(y, dx=dx)
    Df_map, J_map = map_infer_Df(slope_obs=feat["slope"], flatness_w_obs=feat["flatness_w"])
    Dq = quaternionize_features(Df_map, feat["flatness_w"], y, dx)
    ai = anisotropy_index(Dq)
    ex, ey, ez = eps_tensor(Dq)
    return dict(
        Df_map=Df_map, J_map=J_map, slope=feat["slope"], flatness_w=feat["flatness_w"],
        D0=Dq.D0, D1=Dq.D1, D2=Dq.D2, D3=Dq.D3, anisotropy=ai, eps_x=ex, eps_y=ey, eps_z=ez
    )
