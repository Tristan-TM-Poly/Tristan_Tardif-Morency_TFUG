
import numpy as np, pandas as pd
from tfug.model import TFUGParams, run_pipeline

def tfug_score_from_features(meta_row: dict, params: TFUGParams=None):
    if params is None: params = TFUGParams()
    df = pd.DataFrame([{
        "comp": meta_row.get("id","raman_sample"),
        "pressure_gpa": meta_row.get("pressure_gpa",0.0),
        "dH_eV_atom": meta_row.get("dH_eV_atom",0.0),
        "tox_risk": meta_row.get("tox_risk",0.1),
        "Df": meta_row["D0"],
        "kappa_f": meta_row.get("kappa_f",0.7),
        "anis": np.tanh(1.5*meta_row["anisotropy"]),
        "flatness": meta_row["flatness_w"],
        "N0_eV": meta_row.get("N0_eV",1.0),
        "lambda_ph": meta_row.get("lambda_ph",0.8),
        "theta_log_K": meta_row.get("theta_log_K",700.0),
        "lambda_corr": meta_row.get("lambda_corr",0.2),
        "slope_obs": meta_row["slope"],
        "flatness_w_obs": meta_row["flatness_w"],
        "notes": "AI-7 Raman → TFUQ → TFUG"
    }])
    ranked = run_pipeline(df, params)
    return ranked.iloc[0].to_dict()
