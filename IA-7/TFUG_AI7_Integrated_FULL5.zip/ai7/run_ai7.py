
import os, json, numpy as np, pandas as pd, matplotlib.pyplot as plt
from .preproc import load_raman_folder, preproc_one
from .features import extract_all

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="in_dir", default="data/raman")
    ap.add_argument("--out", dest="out_dir", default="out_ai7")
    args = ap.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)

    rows = []
    for item in load_raman_folder(args.in_dir):
        pp = preproc_one(item["x"], item["y"])
        feats = extract_all(pp["x"], pp["y"], pp["dx"])
        row = dict(id=item["file"], **feats)
        rows.append(row)

    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(args.out_dir, "ai7_features.csv"), index=False)

    # quick diagnostic plot
    if len(rows)>0:
        plt.figure()
        plt.scatter(df["slope"], df["flatness_w"])
        plt.xlabel("wavelet slope"); plt.ylabel("flatness_w")
        plt.title("AI-7 Raman — invariants")
        plt.tight_layout()
        plt.savefig(os.path.join(args.out_dir, "invariants_scatter.png"))
        plt.close()

    print("AI-7 done ->", args.out_dir)

if __name__=="__main__":
    main()
