
from __future__ import annotations
from dataclasses import dataclass
import numpy as np, pandas as pd

@dataclass
class TFUGParams:
    w_connectivity: float = 0.35
    w_anisotropy:   float = 0.15
    w_flatbands:    float = 0.25
    w_phonon:       float = 0.25
    penalty_pressure: float = 0.6
    penalty_metastab: float = 0.3
    penalty_tox: float = 0.15
    mu_star: float = 0.13
    f_fractal_max: float = 2.8
    alpha_misfit: float = 0.50
    beta_action:  float = 0.35
    gamma_viab:   float = 0.15
    target_slope: float = 0.0
    target_flat:  float = 0.8

def expected_columns():
    return ["comp","pressure_gpa","dH_eV_atom","tox_risk",
            "Df","kappa_f","anis","flatness","N0_eV",
            "lambda_ph","theta_log_K","lambda_corr","notes",
            "slope_obs","flatness_w_obs"]

def _allen_dynes(l, tL, mu):
    l=max(1e-6,float(l)); tL=max(50.0,float(tL)); mu=float(mu)
    return (tL/1.2)*np.exp(-(1.04*(1+l))/(l-mu*(1+0.62*l)+1e-6))

def _f_fractal(D,k,a,cap=2.8): return float(min((1+0.8*(D-2))*(1+0.6*k)*(1+0.5*a), cap))
def _f_flat(f): return 1+0.5*float(np.clip(f,0,1))
def _viab(P,dH,tox,p):
    P=max(0.0,float(P)); dH=float(dH); tox=float(np.clip(tox,0,1))
    v=np.exp(-p.penalty_pressure*P/100)*np.exp(-p.penalty_metastab*max(0.0,dH))*(1-p.penalty_tox*tox)
    return float(np.clip(v,0,1))
def _S_TFU(D,k,a): return (D-2.0)**2+0.25*(k-0.7)**2+0.25*(a-0.7)**2
def _misfit(row,p):
    s=float(row.get("slope_obs",0.0)); f=float(row.get("flatness_w_obs",0.5))
    return 0.7*(s-p.target_slope)**2+0.3*(f-p.target_flat)**2

def _score_row(r,p):
    t_ph=_allen_dynes(r["lambda_ph"],r["theta_log_K"],p.mu_star)
    t_corr=120.0*float(np.clip(r.get("lambda_corr",0.0),0,2))
    f_f=_f_fractal(r["Df"],r["kappa_f"],r["anis"],p.f_fractal_max)
    f_fb=_f_flat(r["flatness"]); v=_viab(r["pressure_gpa"],r["dH_eV_atom"],r["tox_risk"],p)
    base=(p.w_phonon*t_ph+(1-p.w_phonon)*t_corr)*f_f*f_fb*v
    S=_S_TFU(r["Df"],r["kappa_f"],r["anis"]); M=_misfit(r,p); logp=-p.alpha_misfit*M - p.beta_action*S + p.gamma_viab*np.log(max(v,1e-9))
    gain=float(np.exp(np.clip(logp,-1.5,1.5))); tc=base*gain
    return dict(tc_pred=tc, viability=v, f_fractal=f_f, f_flatband=f_fb, S_TFU=S, misfit_wavelet=M, logp=logp,
                Df=r["Df"], anis=r["anis"], flatness=r["flatness"], lambda_ph=r["lambda_ph"], theta_log_K=r["theta_log_K"], lambda_corr=r["lambda_corr"])

def run_pipeline(df, params=None):
    if params is None: params=TFUGParams()
    out=df.copy()
    if len(out)==0: return out
    rows=[_score_row(r,params) for _,r in out.iterrows()]
    for k in rows[0]: out[k]=[d[k] for d in rows]
    return out.sort_values("tc_pred", ascending=False).reset_index(drop=True)
