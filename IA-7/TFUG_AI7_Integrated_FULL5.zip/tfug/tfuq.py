
from __future__ import annotations
import numpy as np
from dataclasses import dataclass

@dataclass
class TFUQComponents:
    D0: float; D1: float; D2: float; D3: float

def _safe_norm(*vals, eps: float=1e-12): return float(np.sqrt(sum(v*v for v in vals)) + eps)

def hilbert_quadrature(y: np.ndarray):
    Y = np.fft.rfft(y)
    h = np.zeros_like(Y, dtype=float); n=y.size
    if n % 2 == 0: h[0]=1.0; h[-1]=1.0; h[1:-1]=2.0
    else: h[0]=1.0; h[1:]=2.0
    y_h = np.fft.irfft(Y * h, n=n)
    return y_h

def multi_scale_derivatives(y: np.ndarray, dx: float):
    def d_smooth(y, k):
        r = max(2, int(3*k))
        t = np.arange(-r, r+1)
        g = np.exp(-(t**2)/(2*(k**2))); g /= g.sum()
        yg = np.convolve(y, g, mode="same")
        dy = (np.roll(yg, -1) - np.roll(yg, 1)) / (2*dx)
        return dy
    return d_smooth(y,2), d_smooth(y,4), d_smooth(y,8)

def quaternionize_features(Df_like: float, flatness_w: float, y: np.ndarray, dx: float) -> TFUQComponents:
    D0 = float(np.clip(Df_like, 1.0, 3.5))
    yq   = hilbert_quadrature(y)
    d1, d2, d3 = multi_scale_derivatives(y, dx)
    e1 = float(np.sqrt(np.mean(yq**2)))
    e2 = float(np.sqrt(np.mean(d1**2)))
    e3 = float(np.sqrt(np.mean(d2**2) + np.mean(d3**2)))
    S = _safe_norm(e1, e2, e3)
    D1 = 2.0 * (e1 / S) * (0.5 + 0.5*flatness_w)
    D2 = 2.0 * (e2 / S)
    D3 = 2.0 * (e3 / S)
    return TFUQComponents(D0=D0, D1=float(np.clip(D1, 0.0, 3.5)), D2=float(np.clip(D2, 0.0, 3.5)), D3=float(np.clip(D3, 0.0, 3.5)))

def anisotropy_index(D: TFUQComponents) -> float:
    vec = np.array([D.D1, D.D2, D.D3], dtype=float)
    if np.allclose(vec, 0): return 0.0
    return float(np.var(vec) / (np.mean(vec**2) + 1e-12))

def eps_tensor(D: TFUQComponents, eps0: float=1.0):
    ex = eps0 * (1.0 + 0.3*D.D0) * (1.0 + 0.5*D.D1)
    ey = eps0 * (1.0 + 0.3*D.D0) * (1.0 + 0.5*D.D2)
    ez = eps0 * (1.0 + 0.3*D.D0) * (1.0 + 0.5*D.D3)
    return float(ex), float(ey), float(ez)
