
from __future__ import annotations
import numpy as np
from dataclasses import dataclass

@dataclass
class CWTResult:
    scales: np.ndarray
    freqs: np.ndarray
    coef: np.ndarray

def _morlet(t, s, w0=6.0):
    return (np.pi**-0.25) * np.exp(1j*w0*t/s) * np.exp(-(t**2)/(2*s**2))

def cwt_morlet(x: np.ndarray, dt: float=1.0, scales: np.ndarray|None=None, w0: float=6.0) -> CWTResult:
    n=len(x)
    if scales is None:
        s0, J, dj = 1.0, int(max(4, np.log2(n))), 1/8
        scales = s0 * 2**(np.arange(0, int(J/dj)) * dj)
        if len(scales) < 8: scales = np.linspace(1.0, max(8.0, n/8), 32)
    coef = np.zeros((len(scales), n), dtype=complex)
    for i, s in enumerate(scales):
        half = int(min(max(8, 8*s/dt), (n-1)//2))
        t = np.arange(-half, half+1) * dt
        psi = _morlet(t, s, w0)
        conv = np.convolve(x, np.conjugate(psi[::-1]), mode='same')
        coef[i, :] = conv * (dt / np.sqrt(s))
    freqs = w0 / (2*np.pi*scales*dt)
    return CWTResult(scales=np.asarray(scales), freqs=np.asarray(freqs), coef=coef)

def _ridge_energy(abs_coef: np.ndarray, k_window:int=5):
    n_sc, n = abs_coef.shape
    ridge = np.zeros(n)
    for j in range(n):
        col = abs_coef[:, j]
        ridge[j] = col[np.argmax(col)]
    if k_window>1:
        from numpy.lib.stride_tricks import sliding_window_view as swv
        arr = np.pad(ridge, (k_window//2,), mode='edge')
        ridge = np.mean(swv(arr, window_shape=k_window), axis=-1)
    return ridge

def _scale_slope(abs_coef: np.ndarray, scales: np.ndarray, smin:int=0, smax:int|None=None):
    if smax is None: smax = len(scales)
    Es = np.sum(abs_coef[smin:smax,:]**2, axis=1) + 1e-12
    x = np.log(scales[smin:smax] + 1e-12)
    y = np.log(Es)
    A = np.vstack([x, np.ones_like(x)]).T
    slope, b0 = np.linalg.lstsq(A, y, rcond=None)[0]
    return float(slope), float(b0), Es

def wavelet_features(y: np.ndarray, dx: float=1.0, scales: np.ndarray|None=None):
    res = cwt_morlet(y, dt=dx, scales=scales)
    A = np.abs(res.coef)
    ridge = _ridge_energy(A)
    slope, _, _ = _scale_slope(A, res.scales)
    rid_norm = (ridge - ridge.min()) / (ridge.ptp() + 1e-12)
    flatness = 1.0 / (1.0 + 10.0*np.var(rid_norm))
    Df_like = np.clip(2.0 + 0.8*slope, 1.0, 3.5)
    return dict(Df_like=float(Df_like), flatness_w=float(flatness), slope=float(slope)), res
