
# Minimal bilingual report wrapper (optional usage from AI-7 flow)
import os, pandas as pd, numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
def build_pdf_bilingual(outdir: str, pdf_path: str, title: str="AI-7 + TFUG/TFUQ — Bilingual"):
    feats = pd.read_csv(os.path.join(outdir,"tfuq_features.csv"))
    rank  = pd.read_csv(os.path.join(outdir,"ranked_tfuq.csv"))
    with PdfPages(pdf_path) as pdf:
        plt.figure(figsize=(8.27, 11.69)); plt.axis('off')
        plt.text(0.5,0.94,title,ha='center',fontsize=18,fontweight='bold')
        comp = rank.iloc[0].get("comp","?"); tc=rank.iloc[0].get("tc_pred",0.0)
        plt.text(0.1,0.85,f"Sample: {comp} | Tc_pred={tc:.2f} K",fontsize=11)
        pdf.savefig(); plt.close()
def main():
    import argparse; ap=argparse.ArgumentParser()
    ap.add_argument("--outdir", default="out_tfuq"); ap.add_argument("--pdf", default="AI7_TFUG_report.pdf")
    args=ap.parse_args(); os.makedirs(args.outdir, exist_ok=True)
    build_pdf_bilingual(args.outdir, os.path.join(args.outdir,args.pdf))
    print("Saved:", os.path.join(args.outdir,args.pdf))
if __name__=="__main__": main()
