
def map_infer_Df(slope_obs: float, flatness_w_obs: float,
                 target_slope: float=0.0, target_flat: float=0.8,
                 beta_action: float=0.35, alpha_misfit: float=0.5,
                 kappa_f: float=0.7, anis: float=0.7, n_iter:int=400, seed:int=1234):
    import numpy as np
    def S_TFU(Df, kappa_f=0.7, anis=0.7):
        return (Df-2.0)**2 + 0.25*(kappa_f-0.7)**2 + 0.25*(anis-0.7)**2
    rng = np.random.default_rng(seed)
    D0 = float(np.clip(2.0 + 0.8*float(slope_obs), 1.0, 3.5))
    best_D, best_J = D0, 1e9
    def J(D):
        slope_pred = (D-2.0)/0.8
        m1 = (slope_pred - target_slope)**2
        m2 = (flatness_w_obs - target_flat)**2
        misfit = 0.7*m1 + 0.3*m2
        return alpha_misfit*misfit + beta_action*S_TFU(D, kappa_f, anis)
    for _ in range(n_iter):
        cand = float(np.clip(best_D + rng.normal(0, 0.15), 1.0, 3.5))
        val = J(cand)
        if val < best_J: best_J, best_D = val, cand
    return float(best_D), float(best_J)
