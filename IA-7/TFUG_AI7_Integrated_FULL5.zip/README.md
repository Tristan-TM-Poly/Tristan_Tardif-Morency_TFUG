
# TFUG + TFUQ + TFU (MAP) integrated into Raman AI‑7 (FULL5)

This package wires your TFU/TFUG/TFUQ pipeline directly into a **Raman AI‑7** workflow:
- CWT wavelet invariants -> **MAP TFU** estimator of \(D_f\)
- Quaternionic TFUQ features (D0..D3), anisotropy, effective permittivity
- TFUG scoring (Allen–Dynes + fractal/flatband + viability + TFU log‑posterior)
- Active learning loop (uncertainty sampling on TFU diagnostics)
- Batch + streaming inference; minimal dependencies (numpy, pandas, matplotlib)

## Quick start

```bash
unzip TFUG_AI7_Integrated_FULL5.zip -d proj
cd proj
python -m venv .venv && source .venv/bin/activate
pip install numpy pandas matplotlib

# 1) Run AI‑7 on Raman spectra (batch)
python -m ai7.run_ai7 --in data/raman --out out_ai7

# 2) Produce integrated TFUG ranking from AI‑7 artifacts
python -m ai7.run_ai7_to_tfug --ai7 out_ai7 --out out_tfuq

# 3) Generate bilingual PDF + TikZ + IEEE report (optional)
python -m tfug.report_pdf_bilingual --outdir out_tfuq --pdf TFUG_TFUQ_report_bilingual_TFU.pdf
python -m tfug.tikz_export --features out_tfuq/tfuq_features.csv --outdir out_tfuq/tikz
python -m tfug.report_ieee --outdir out_tfuq
```

## Pipelines covered
- **Raman AI‑7** (this repo)  
- Hooks for **DOS/ARPES**, **IR/ellipsometry**, **impedance** via the shared `ai7/features.py` → `tfug/`

## Files
- `ai7/` — Raman AI‑7 pipeline (preproc, features, model, active learning, CLI)
- `tfug/` — TFU/TFUQ/TFUG inference, reporting and TikZ exporters
- `data/raman/*.csv` — example spectra
- `data/dos/*.csv` — example DOS
- `out_ai7/`, `out_tfuq/` — artifacts & reports
