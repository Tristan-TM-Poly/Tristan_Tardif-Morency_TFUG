
from __future__ import annotations
import math, random
from typing import Dict, Any, Tuple
import numpy as np
from dataclasses import dataclass
from scipy.optimize import minimize, Bounds

from tfu_sc_analytic import SCInputs, compute_all

EPS = 1e-12

def _logerr(pred: float, target: float) -> float:
    if target is None or target <= 0: return 0.0
    pred = max(pred, EPS); target = max(target, EPS)
    return math.log(pred/target)

def loss_vec(vec: np.ndarray, base: SCInputs, targets: Dict[str, float], weights: Dict[str, float]) -> float:
    Df, al, at, ans = float(vec[0]), float(vec[1]), float(vec[2]), float(vec[3])
    p = SCInputs(**{**base.__dict__})
    p.al, p.at, p.ans = al, at, ans
    obs = compute_all(Df, p)

    L = 0.0
    # Scalar targets
    for key in ("Tc_K","xi_iso_nm","lambda_iso_nm","Hc2_c_T","Hc2_ab_T","Pc_Jperm3"):
        if key in targets and targets[key] is not None:
            w = weights.get(key, 0.0)
            if w>0:
                L += w*_logerr(obs.get(key, float('nan')), targets[key])**2
    # Directional targets
    for key in ("lambda_ab_nm","lambda_c_nm","xi_ab_nm","xi_c_nm","Hc1_ab_T","Hc1_c_T","Jc_ab_Aperm2","Jc_c_Aperm2"):
        if key in targets and targets[key] is not None:
            w = weights.get(key, 0.0)
            if w>0:
                L += w*_logerr(obs.get(key, float('nan')), targets[key])**2

    # Regularization (keep exponents small)
    L += 0.01*(al*al + at*at + ans*ans)
    return L

def cooptimize(base: SCInputs, targets: Dict[str, float],
               weights: Dict[str, float] = None,
               n_starts: int = 10, seed: int = 42,
               bounds: Dict[str, Tuple[float,float]] = None) -> Dict[str, Any]:
    if weights is None:
        weights = {
            "Tc_K":1.0,
            "lambda_ab_nm":0.7,
            "xi_ab_nm":0.5,
            "Hc2_c_T":0.3,
            "Jc_ab_Aperm2":0.2
        }
    if bounds is None:
        bounds = {"Df":(0.2,3.0), "al":(-0.6,0.6), "at":(-0.6,0.6), "ans":(-0.6,0.6)}
    lb = [bounds["Df"][0], bounds["al"][0], bounds["at"][0], bounds["ans"][0]]
    ub = [bounds["Df"][1], bounds["al"][1], bounds["at"][1], bounds["ans"][1]]
    B = Bounds(lb, ub)

    rng = random.Random(seed)
    x_ref = [base.Df_ref, base.al, base.at, base.ans]
    best = {"fun": float("inf"), "x": None, "res": None}
    for k in range(n_starts):
        x0 = np.array([
            max(lb[0], min(ub[0], x_ref[0]*(1+0.15*(rng.random()-0.5)))),
            max(lb[1], min(ub[1], x_ref[1]+0.05*(rng.random()-0.5))),
            max(lb[2], min(ub[2], x_ref[2]+0.05*(rng.random()-0.5))),
            max(lb[3], min(ub[3], x_ref[3]+0.05*(rng.random()-0.5))),
        ], dtype=float)
        obj = lambda v: loss_vec(v, base, targets, weights)
        res = minimize(obj, x0, method="L-BFGS-B", bounds=B, options={"maxiter": 400, "ftol":1e-10})
        if res.fun < best["fun"]:
            best.update({"fun": float(res.fun), "x": res.x.copy(), "res": res})
    Df, al, at, ans = map(float, best["x"])
    p = SCInputs(**{**base.__dict__}); p.al, p.at, p.ans = al, at, ans
    obs = compute_all(Df, p)
    return {"Df":Df, "al":al, "at":at, "ans":ans, "loss":float(best["fun"]), "obs":obs,
            "success":bool(best["res"].success), "message":str(best["res"].message), "nfev":int(best["res"].nfev)}
