
# opt_demo_aniso.py — co-opt with anisotropy and Jc term (if targets provided)
import csv
from tfu_sc_analytic import SCInputs, compute_all
from tfu_sc_opt import cooptimize

# Targets (demonstration): Tc & lambda_ab, plus optional Jc_ab (rough order-of-magnitude)
targets = {
    "YBCO": {"Tc_K":92.0, "lambda_ab_nm":150.0, "Jc_ab_Aperm2": 1.0e11},
    "MgB2": {"Tc_K":39.0, "lambda_ab_nm":85.0,  "Jc_ab_Aperm2": 5.0e10},
    "H3S":  {"Tc_K":203.0,"lambda_ab_nm":70.0,  "Jc_ab_Aperm2": None},  # unknown, ignored
}
# Base inputs (with anisotropy guesses)
materials = {
    "YBCO": dict(theta0=900.0, lambda0=1.0, mu_star=0.12, vF0=2.0e5, mstar0=2.0*9.10938356e-31, ns0=8e27,
                 Df_ref=1.2, al=0.45, at=0.40, ans=-0.70, pf=0.25, beta=1.0, gamma0=6.0, a_gamma=0.0),
    "MgB2": dict(theta0=750.0, lambda0=0.9, mu_star=0.10, vF0=3.0e5, mstar0=1.5*9.10938356e-31, ns0=7e27,
                 Df_ref=1.2, al=0.39, at=-0.27, ans=-0.70, pf=0.15, beta=1.0, gamma0=1.1, a_gamma=0.0),
    "H3S":  dict(theta0=1500.0, lambda0=2.0, mu_star=0.10, vF0=3.0e5, mstar0=1.0*9.10938356e-31, ns0=1e29,
                 Df_ref=1.2, al=0.45, at=0.41, ans=-0.70, pf=0.20, beta=1.0, gamma0=1.5, a_gamma=0.0),
}

weights = {"Tc_K":1.0, "lambda_ab_nm":0.7, "Jc_ab_Aperm2":0.2}

rows = []
for name, base in materials.items():
    base_in = SCInputs(**base)
    res = cooptimize(base_in, targets[name], weights=weights)
    obs = res["obs"]
    rows.append({
        "material": name,
        "Df_opt": res["Df"],
        "al_opt": res["al"], "at_opt": res["at"], "ans_opt": res["ans"],
        "loss": res["loss"], "success": res["success"], "message": res["message"], "nfev": res["nfev"],
        "Tc_pred_K": obs["Tc_K"], "lambda_ab_pred_nm": obs["lambda_ab_nm"],
        "xi_ab_pred_nm": obs["xi_ab_nm"], "xi_c_pred_nm": obs["xi_c_nm"],
        "Hc2_c_pred_T": obs["Hc2_c_T"], "Hc2_ab_pred_T": obs["Hc2_ab_T"],
        "Jc_ab_pred_Aperm2": obs["Jc_ab_Aperm2"], "Jc_c_pred_Aperm2": obs["Jc_c_Aperm2"],
        "gamma_eff": obs["gamma"]
    })

with open("opt_results_aniso.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader()
    for r in rows:
        w.writerow(r)

print("Wrote opt_results_aniso.csv with", len(rows), "rows.")
