
# TFU/TFUQ Superconductivity — Anisotropic GL + Jc Co-Optimization

This report documents:
1) Anisotropic GL extension (ab/c) in the analytic kernel,
2) Inclusion of \(J_c\) in the multi-objective loss,
3) Co-optimization results on YBCO, MgB\(_2\), H\(_3\)S.

## Model summary
- \(T_c = \frac{\Theta_{\rm eff}}{1.2}\exp\!\big[-\frac{1.04(1+\lambda_{\rm eff})}{\lambda_{\rm eff}-\mu^\*(1+0.62\lambda_{\rm eff})}\big]\).
- \(\Delta_0 = \frac{\alpha_{\rm red}}{2}k_B T_c\).
- \(\xi_{ab} = \hbar v_{F,ab}/(\pi \Delta_0)\), \(\xi_c = \xi_{ab}/\gamma\).
- \(\lambda_{ab} = \sqrt{m_{ab}^\*/(\mu_0 n_s (2e)^2)}\), \(\lambda_c = \gamma \lambda_{ab}\).
- \(H_{c2}^c = \Phi_0/(2\pi \xi_{ab}^2)\), \(H_{c2}^{ab}=\Phi_0/(2\pi \xi_{ab}\xi_c)\).
- \(J_d \propto H_c/(\mu_0 \lambda)\). Pinning: \(J_c^{\rm pin} = C_{\rm pin}\,p_f^\beta \sqrt{n_s}/(\lambda^2 \sqrt{\xi})\).
- \(J_c = \min(J_d, J_c^{\rm pin})\).

## Targets used (demo)
- YBCO: \(T_c=92\,{\rm K}\), \(\lambda_{ab}=150\,{\rm nm}\), \(J_c^{ab}\sim10^{11}\,{\rm A/m^2}\).
- MgB\(_2\): \(T_c=39\,{\rm K}\), \(\lambda_{ab}=85\,{\rm nm}\), \(J_c^{ab}\sim5\times10^{10}\,{\rm A/m^2}\).
- H\(_3\)S: \(T_c=203\,{\rm K}\), \(\lambda_{ab}=70\,{\rm nm}\).

## Results (co-optimization)
See `opt_results_aniso.csv` for full numbers.
