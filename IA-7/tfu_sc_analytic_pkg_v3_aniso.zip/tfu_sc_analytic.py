
from __future__ import annotations
import math
from dataclasses import dataclass

# Physical constants
kB  = 1.380649e-23
h   = 6.62607015e-34
hbar= h/(2*math.pi)
e   = 1.602176634e-19
mu0 = 4e-7*math.pi
Phi0= h/(2*e)
me  = 9.10938356e-31

def _safe_sqrt(x: float) -> float:
    return math.sqrt(max(x, 0.0))

def allen_dynes_Tc(thetaK: float, lam: float, mu_star: float) -> float:
    if lam <= 0.0 or thetaK <= 0.0: return 0.0
    denom = lam - mu_star*(1.0 + 0.62*lam)
    if denom <= 1e-16: return 0.0
    return (thetaK/1.2) * math.exp(-1.04*(1.0+lam)/denom)

def delta0_from_Tc(Tc: float, alpha_red: float=3.52) -> float:
    return 0.5*alpha_red*kB*Tc

def xi0_from_vF_Delta(vF: float, Delta0: float) -> float:
    if Delta0 <= 0.0: return float("inf")
    return hbar*vF/(math.pi*Delta0)

def lambdaL_from_m_ns(mstar: float, ns: float) -> float:
    denom = mu0*ns*(2*e)**2
    if denom <= 0.0: return float("inf")
    return _safe_sqrt(mstar/denom)

def fields_from_xi_lambda_isotropic(xi: float, lamL: float, core_c: float=0.5):
    if xi<=0 or lamL<=0 or not math.isfinite(xi) or not math.isfinite(lamL):
        return (0.0, 0.0, 0.0, float('inf'))
    kappa = lamL/xi
    Bc  = Phi0/(2*math.sqrt(2)*math.pi*xi*lamL)
    Bc2 = Phi0/(2*math.pi*xi*xi)
    Bc1 = Phi0/(4*math.pi*lamL*lamL)*(math.log(max(kappa,1.0001)) + core_c)
    return (Bc, Bc1, Bc2, kappa)

def J_depair(Bc: float, lamL: float) -> float:
    if lamL <= 0.0: return 0.0
    return (2.0/(3.0*math.sqrt(3.0))) * (Bc/(mu0*lamL))

def J_pinning(pf: float, beta: float, ns: float, lamL: float, xi: float, Cpin: float=5e11) -> float:
    pf = max(0.0, min(1.0, pf))
    if lamL<=0 or xi<=0 or ns<=0: return 0.0
    return Cpin * (pf**beta) * (ns**0.5) / (lamL**2 * (xi**0.5))

def power_scale(Df: float, Df_ref: float, a: float) -> float:
    x = max(1e-12, Df)/max(1e-12, Df_ref)
    return x**a

@dataclass
class SCInputs:
    theta0: float
    lambda0: float
    mu_star: float
    vF0: float
    mstar0: float
    ns0: float
    Df_ref: float=1.0
    alpha_gap0: float=3.52
    # exponents
    al: float=0.45
    at: float=0.40
    ans: float=-0.70
    av: float=0.10
    am: float=-0.10
    aalpha: float=0.0
    # anisotropy (GL): gamma = xi_ab/xi_c = lambda_c/lambda_ab
    gamma0: float=1.0
    a_gamma: float=0.0
    # pinning
    pf: float=0.10
    beta: float=1.0
    Cpin: float=5e11

def compute_all(Df: float, p: SCInputs) -> dict:
    # Effective microscopic scales
    lam = p.lambda0 * power_scale(Df, p.Df_ref, p.al)
    theta = p.theta0 * power_scale(Df, p.Df_ref, p.at)
    ns = p.ns0 * power_scale(Df, p.Df_ref, p.ans)
    vF_ab = p.vF0 * power_scale(Df, p.Df_ref, p.av)
    mstar_ab = p.mstar0 * power_scale(Df, p.Df_ref, p.am)
    alpha_gap = p.alpha_gap0 * power_scale(Df, p.Df_ref, p.aalpha)
    # anisotropy gamma
    gamma = p.gamma0 * power_scale(Df, p.Df_ref, p.a_gamma)
    gamma = max(1.0, float(gamma))  # enforce >=1

    # Tc & gap
    Tc = allen_dynes_Tc(theta, lam, p.mu_star)
    Delta0 = delta0_from_Tc(Tc, alpha_gap)
    # Coherence lengths
    xi_ab = xi0_from_vF_Delta(vF_ab, Delta0)
    xi_c  = xi_ab/max(gamma,1e-12)

    # London depths (anisotropic masses: m_c = gamma^2 m_ab)
    lam_ab = lambdaL_from_m_ns(mstar_ab, ns)
    lam_c  = lam_ab*gamma

    # Isotropic "equivalents" (geom. means commonly used for comparisons)
    xi_iso = (xi_ab*xi_ab*xi_c)**(1/3)  # geometric mean
    lam_iso= (lam_ab*lam_ab*lam_c)**(1/3)

    # Fields
    Hc_iso, Hc1_iso, Hc2_c, kappa_iso = fields_from_xi_lambda_isotropic(xi_iso, lam_iso, core_c=0.5)
    # Directional Hc2 (GL anisotropic): Hc2^c = Phi0/(2π xi_ab^2); Hc2^ab = Phi0/(2π xi_ab xi_c)=gamma*Hc2^c
    Hc2_c_dir  = Phi0/(2*math.pi*xi_ab*xi_ab) if xi_ab>0 else 0.0
    Hc2_ab_dir = Phi0/(2*math.pi*xi_ab*xi_c) if xi_ab>0 and xi_c>0 else 0.0
    # Directional Hc1 using each lambda
    def Hc1_dir(lam, xi):
        if lam<=0 or xi<=0: return 0.0
        k = lam/xi
        return Phi0/(4*math.pi*lam*lam)*(math.log(max(k,1.0001))+0.5)
    Hc1_ab = Hc1_dir(lam_ab, xi_ab)
    Hc1_c  = Hc1_dir(lam_c,  xi_c)

    # Depairing J and pinning J in each direction
    Jd_ab = J_depair(Hc_iso, lam_ab); Jd_c = J_depair(Hc_iso, lam_c)
    Jp_ab = J_pinning(p.pf, p.beta, ns, lam_ab, xi_ab, p.Cpin)
    Jp_c  = J_pinning(p.pf, p.beta, ns, lam_c,  xi_c,  p.Cpin)
    Jc_ab = min(Jd_ab, Jp_ab); Jc_c = min(Jd_c, Jp_c)

    # Energy density (use isotropic Hc)
    Pc = (Hc_iso**2)/(2.0*mu0)

    return {
        "Df": Df, "gamma": gamma,
        "lambda_ep": lam, "thetaK": theta, "alpha_gap": alpha_gap,
        "Tc_K": Tc, "Delta0_J": Delta0,
        "xi_ab_nm": xi_ab*1e9, "xi_c_nm": xi_c*1e9, "xi_iso_nm": xi_iso*1e9,
        "lambda_ab_nm": lam_ab*1e9, "lambda_c_nm": lam_c*1e9, "lambda_iso_nm": lam_iso*1e9,
        "kappa_iso": kappa_iso,
        "Hc_T": Hc_iso, "Hc1_ab_T": Hc1_ab, "Hc1_c_T": Hc1_c,
        "Hc2_ab_T": Hc2_ab_dir, "Hc2_c_T": Hc2_c_dir,
        "Pc_Jperm3": Pc,
        "Jd_ab_Aperm2": Jd_ab, "Jd_c_Aperm2": Jd_c,
        "Jc_ab_Aperm2": Jc_ab, "Jc_c_Aperm2": Jc_c,
    }

def estimate_Df_from_Tc(Tc_target: float, p: SCInputs, Df_min: float=0.05, Df_max: float=5.0, iters: int=64) -> float:
    def fDf(Df):
        lam = p.lambda0 * power_scale(Df, p.Df_ref, p.al)
        theta = p.theta0 * power_scale(Df, p.Df_ref, p.at)
        return allen_dynes_Tc(theta, lam, p.mu_star) - Tc_target
    lo, hi = Df_min, Df_max
    flo, fhi = fDf(lo), fDf(hi)
    expand = 0
    while flo*fhi > 0 and expand < 8:
        hi *= 1.5; fhi = fDf(hi); expand += 1
    if flo*fhi > 0: return float("nan")
    for _ in range(iters):
        mid = 0.5*(lo+hi); fm = fDf(mid)
        if fm == 0.0: return mid
        if flo*fm <= 0: hi, fhi = mid, fm
        else: lo, flo = mid, fm
    return 0.5*(lo+hi)
