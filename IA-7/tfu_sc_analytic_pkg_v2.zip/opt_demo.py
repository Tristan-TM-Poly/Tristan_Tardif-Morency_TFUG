# opt_demo.py — run co-optimization on three materials
import csv
from tfu_sc_analytic import SCInputs, compute_all
from tfu_sc_opt import cooptimize

# Targets (Tc in K, lambdaL in nm); xi optional here
targets = {
    "YBCO": {"Tc":92.0, "lambdaL_nm":150.0},
    "MgB2": {"Tc":39.0, "lambdaL_nm":85.0},
    "H3S":  {"Tc":203.0, "lambdaL_nm":70.0},
}
# Base inputs per material
materials = {
    "YBCO": dict(theta0=900.0, lambda0=1.0, mu_star=0.12, vF0=2.0e5, mstar0=2.0*9.10938356e-31, ns0=8e27,
                 Df_ref=1.2, al=0.45, at=0.40, ans=-0.70, pf=0.2, beta=1.0),
    "MgB2": dict(theta0=750.0, lambda0=0.9, mu_star=0.10, vF0=3.0e5, mstar0=1.5*9.10938356e-31, ns0=7e27,
                 Df_ref=1.2, al=0.39, at=-0.27, ans=-0.70, pf=0.1, beta=1.0),
    "H3S":  dict(theta0=1500.0, lambda0=2.0, mu_star=0.10, vF0=3.0e5, mstar0=1.0*9.10938356e-31, ns0=1e29,
                 Df_ref=1.2, al=0.45, at=0.41, ans=-0.70, pf=0.15, beta=1.0),
}

rows = []
for name, base in materials.items():
    base_in = SCInputs(**base)
    res = cooptimize(base_in, targets[name], weights={"Tc":1.0, "lambdaL_nm":0.7})
    obs = res["obs"]
    rows.append({
        "material": name,
        "Df_opt": res["Df"],
        "al_opt": res["al"], "at_opt": res["at"], "ans_opt": res["ans"],
        "loss": res["loss"], "success": res["success"], "message": res["message"], "nfev": res["nfev"],
        "Tc_pred_K": obs["Tc_K"], "lambdaL_pred_nm": obs["lambdaL_nm"],
        "xi0_pred_nm": obs["xi0_nm"], "Hc2_pred_T": obs["Hc2_T"], "Jc_pred_Aperm2": obs["Jc_Aperm2"]
    })

with open("opt_results.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader()
    for r in rows:
        w.writerow(r)

print("Wrote opt_results.csv with", len(rows), "rows.")