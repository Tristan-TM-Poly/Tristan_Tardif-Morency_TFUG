"""
tfu_sc_opt.py
Co-optimization (Df + exponents) against multi-observables (Tc, lambda_L, xi, Hc2).

Usage:
    from tfu_sc_analytic import SCInputs, compute_all
    from tfu_sc_opt import cooptimize

Targets dictionary may contain any of:
    {"Tc": value[K], "lambdaL_nm": value[nm], "xi_nm": value[nm], "Hc2_T": value[T]}
Weights dictionary mirrors these keys.

Returns a dict with optimal parameters and predicted observables.
"""
from __future__ import annotations
import math, random
from dataclasses import dataclass
from typing import Dict, Any, Tuple, Optional
import numpy as np
from scipy.optimize import minimize, Bounds

from tfu_sc_analytic import SCInputs, compute_all

EPS = 1e-12

def _logerr(pred: float, target: float) -> float:
    if target is None or target <= 0: return 0.0
    pred = max(pred, EPS); target = max(target, EPS)
    return math.log(pred/target)

def loss_vec(vec: np.ndarray, base: SCInputs, targets: Dict[str, float], weights: Dict[str, float]) -> float:
    Df, al, at, ans = float(vec[0]), float(vec[1]), float(vec[2]), float(vec[3])

    # update inputs
    p = SCInputs(**{**base.__dict__})
    p.al, p.at, p.ans = al, at, ans

    obs = compute_all(Df, p)

    lt = targets; w = weights
    L = 0.0
    # Terms if present
    if "Tc" in lt and lt["Tc"]:
        e = _logerr(obs["Tc_K"], lt["Tc"]); L += w.get("Tc",1.0)*e*e
    if "lambdaL_nm" in lt and lt["lambdaL_nm"]:
        e = _logerr(obs["lambdaL_nm"], lt["lambdaL_nm"]); L += w.get("lambdaL_nm",0.5)*e*e
    if "xi_nm" in lt and lt["xi_nm"]:
        e = _logerr(obs["xi_nm"], lt["xi_nm"]); L += w.get("xi_nm",0.5)*e*e
    if "Hc2_T" in lt and lt["Hc2_T"]:
        e = _logerr(obs["Hc2_T"], lt["Hc2_T"]); L += w.get("Hc2_T",0.3)*e*e

    # Mild regularization to keep exponents small
    L += 0.01*(al*al + at*at + ans*ans)
    return L

def cooptimize(base: SCInputs,
               targets: Dict[str, float],
               weights: Dict[str, float] = None,
               n_starts: int = 12,
               seed: int = 42,
               bounds: Dict[str, Tuple[float,float]] = None) -> Dict[str, Any]:
    """
    Optimize variables x = [Df, al, at, ans].
    Bounds default: Df in [0.2, 3.0], al,at,ans in [-0.6, 0.6].
    """
    if weights is None:
        weights = {"Tc":1.0, "lambdaL_nm":0.6, "xi_nm":0.6, "Hc2_T":0.3}
    if bounds is None:
        bounds = {"Df":(0.2,3.0), "al":(-0.6,0.6), "at":(-0.6,0.6), "ans":(-0.6,0.6)}

    rng = random.Random(seed)
    best = {"fun": float("inf"), "x": None, "res": None}

    lb = [bounds["Df"][0], bounds["al"][0], bounds["at"][0], bounds["ans"][0]]
    ub = [bounds["Df"][1], bounds["al"][1], bounds["at"][1], bounds["ans"][1]]
    B = Bounds(lb, ub)

    # Initial guess near reference
    x_ref = [base.Df_ref, base.al, base.at, base.ans]

    for k in range(n_starts):
        # jittered start
        x0 = np.array([
            max(bounds["Df"][0], min(bounds["Df"][1], x_ref[0] * (1.0 + 0.10*(rng.random()-0.5)))),
            max(bounds["al"][0], min(bounds["al"][1], x_ref[1] + 0.05*(rng.random()-0.5))),
            max(bounds["at"][0], min(bounds["at"][1], x_ref[2] + 0.05*(rng.random()-0.5))),
            max(bounds["ans"][0], min(bounds["ans"][1], x_ref[3] + 0.05*(rng.random()-0.5))),
        ], dtype=float)

        obj = lambda v: loss_vec(v, base, targets, weights)

        res = minimize(obj, x0, method="L-BFGS-B", bounds=B, options={"maxiter": 400, "ftol":1e-10})
        if res.fun < best["fun"]:
            best["fun"] = float(res.fun)
            best["x"] = res.x.copy()
            best["res"] = res

    # Build output
    Df, al, at, ans = map(float, best["x"])
    p = SCInputs(**{**base.__dict__})
    p.al, p.at, p.ans = al, at, ans
    obs = compute_all(Df, p)

    return {
        "Df": Df, "al": al, "at": at, "ans": ans,
        "loss": float(best["fun"]),
        "obs": obs,
        "success": bool(best["res"].success),
        "message": str(best["res"].message),
        "nfev": int(best["res"].nfev)
    }
