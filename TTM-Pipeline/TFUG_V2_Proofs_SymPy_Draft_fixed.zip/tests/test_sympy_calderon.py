
import subprocess, sys, json, os, math
def test_calderon_sympy_script_runs_and_checks():
    here = os.path.dirname(__file__)
    script = os.path.join(here, '..', 'sympy_proofs', 'theorem_calderon_sympy.py')
    # Run the script with the current python
    ret = subprocess.run([sys.executable, script], cwd=os.path.join(here, '..'), capture_output=True, text=True)
    out = ret.stdout + '\\n' + ret.stderr
    # Basic check: script printed 'Symbolic integral I ='
    assert 'Symbolic integral I =' in out, "SymPy script did not run or did not print expected output."
    # If a JSON result was produced, check numeric equality for sigma=1
    jsonp = os.path.join(os.path.dirname(here), 'calderon_sympy_result.json')
    assert os.path.exists(jsonp), "Expected JSON result from sympy script missing."
    with open(jsonp,'r') as f:
        data = json.load(f)
    expr = data.get('integral_expr','')
    # Evaluate at sigma=1 numerically: expected 1/2
    # Use eval in a safe namespace
    val = eval(expr, {'sigma':1.0, '__builtins__':{}})
    assert abs(val - 0.5) < 1e-12, f"Numeric check failed: {val} != 0.5"
