
# Theorem: Calderón constant for LoG (SymPy verification)

This notebook demonstrates the symbolic computation of the Calderón integral for the Laplacian-of-Gaussian (LoG) wavelet.
See `theorem_calderon_sympy.py` for the core symbolic code.
