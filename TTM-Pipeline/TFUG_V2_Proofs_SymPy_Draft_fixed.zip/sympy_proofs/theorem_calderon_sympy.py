"""Symbolic verification of Calderon constant for LoG wavelet.

Compute I(r) = integral_0^infty a^3 r^4 exp(-sigma^2 r^2 a^2) da and simplify.
"""
from sympy import symbols, integrate, oo, simplify, exp, latex
r, a, sigma = symbols('r a sigma', positive=True)
expr = a**3 * r**4 * exp(-sigma**2 * r**2 * a**2)
I = integrate(expr, (a, 0, oo))
# simplify result; expect 1/(2*sigma**4)
I_s = simplify(I)
latex_I = latex(I_s)
print('Symbolic integral I =', I_s)
print('LaTeX:', latex_I)
# Also produce the difference I - 1/(2*sigma**4) to check it's identically zero
target = 1/(2*sigma**4)
diff = simplify(I_s - target)
print('Difference w.r.t. target (should be 0):', diff)
# Export to file
with open('calderon_sympy_result.json', 'w') as f:
    import json
    json.dump({'integral_latex': latex_I, 'integral_expr': str(I_s)}, f, indent=2)
