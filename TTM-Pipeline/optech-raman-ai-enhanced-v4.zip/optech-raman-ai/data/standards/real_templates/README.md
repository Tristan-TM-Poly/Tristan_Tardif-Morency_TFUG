# Référentiels Raman — Ét alons réels (templates)

Dépose ici des spectres **mesurés** et **certifiés** pour calibration :
- `Si_520cm-1_real.csv`
- `PS_polystyrene_real.csv`
- `PTFE_real.csv`
- `Al2O3_sapphire_real.csv`

## Format CSV
wavenumber,intensity
500,0.02
...

## Métadonnées optionnelles (JSON)
- `<name>.meta.json` avec:
  - instrument (string)
  - laser_nm (int/float)
  - power_mW (float)
  - integration_ms (float)
  - temperature_C (float)
  - date (ISO8601)
  - sample_ref (string)

Ces fichiers sont consommés par `raman_ai.io.standards`.
