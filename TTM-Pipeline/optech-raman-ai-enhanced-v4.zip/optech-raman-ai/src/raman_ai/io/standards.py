import os
import csv
from dataclasses import dataclass
from typing import List, Tuple

@dataclass
class ReferenceSpectrum:
    name: str
    wavenumber: List[float]
    intensity: List[float]

def load_reference_spectra(root: str) -> List[ReferenceSpectrum]:
    spectra = []
    if not os.path.isdir(root):
        return spectra
    for fn in sorted(os.listdir(root)):
        if not fn.lower().endswith(".csv"):
            continue
        path = os.path.join(root, fn)
        wn, inten = [], []
        with open(path, "r", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                wn.append(float(row["wavenumber"]))
                inten.append(float(row["intensity"]))
        spectra.append(ReferenceSpectrum(name=os.path.splitext(fn)[0], wavenumber=wn, intensity=inten))
    return spectra
