
from pydantic import BaseModel
from typing import List, Optional, Dict

class RamanRecord(BaseModel):
    sample_id: str
    instrument_id: str
    laser_nm: int
    power_mw: float
    integration_s: float
    temp_C: float | None = None
    datetime: int | None = None  # epoch ms
    x_cm_1: List[float]
    y: List[float]
    y_pp: List[float] | None = None
    label_material: str | None = None
    y_targets: Dict[str, float] | None = None
    split: str | None = None
