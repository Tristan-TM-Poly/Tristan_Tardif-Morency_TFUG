import typer
from pathlib import Path
import json
from .eval import evaluate as _evaluate
from .report import gen_latex as _report
from .preprocess import pipeline as _pp
from .features import pipeline as _feat
from .models import train as _train

app = typer.Typer(help="Optech Raman AI CLI")

@app.command()
def to_parquet(params: Path = Path("params.yaml")):
    # placeholder: rely on existing io/parquet.py if present
    from .io import parquet as io_parquet
    io_parquet.main(str(params))

@app.command()
def preprocess(params: Path = Path("params.yaml")):
    _pp.main(str(params))

@app.command()
def features(params: Path = Path("params.yaml")):
    _feat.main(str(params))

@app.command()
def train(params: Path = Path("params.yaml")):
    _train.main(str(params))

@app.command()
def evaluate(params: Path = Path("params.yaml")):
    _evaluate.main(str(params))

@app.command()
def report(params: Path = Path("params.yaml")):
    _report.main(str(params))

def main():
    app()

if __name__ == "__main__":
    main()


import argparse, os, numpy as np, json
from .models.train import train_bayesian_multioutput
from .report.gen_latex import inject_figures
from .io.standards import load_reference_spectra

def _dummy_features_path():
    return os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), '..', '..', 'data', 'features.parquet')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("cmd", choices=["train_bayes", "inject_figs", "list_standards"])
    parser.add_argument("--alpha", type=float, default=1.0)
    parser.add_argument("--beta", type=float, default=25.0)
    args = parser.parse_args()

    if args.cmd == "train_bayes":
        # Dummy placeholders: in real pipeline, load features matrix X, targets Y
        # Here we synthesize small arrays to ensure command works
        X = np.random.randn(64, 16)
        Y = X @ np.random.randn(16, 3) + 0.1*np.random.randn(64,3)
        out = train_bayesian_multioutput(X, Y, X_val=X[:16], Y_val=Y[:16], alpha=args.alpha, beta=args.beta)
        print(out)
    elif args.cmd == "inject_figs":
        path = inject_figures(fig_dir=os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), '..', '..', 'plots'))
        print(path)
    elif args.cmd == "list_standards":
        root = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), '..', '..', 'data', 'standards')
        refs = load_reference_spectra(root)
        print([r.name for r in refs])

if __name__ == "__main__":
    main()


from .eval.calibration import isotonic_sigma_mapping, interval_coverage, ece_regression
import json

def run_temp_scaling_demo():
    # Charge prédictions
    pred_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), '..', '..', 'models', 'bayes_multi', 'val_pred.json')
    with open(pred_path, 'r') as fh:
        pred = json.load(fh)
    mu = np.array(pred['mu']); std = np.array(pred['std'])
    # Reconstruire Y_val synthé pour demo (mêmes seeds que notebooks)
    np.random.seed(7)
    N, D, K = 256, 24, 4
    X = np.random.randn(N, D); Wtrue = np.random.randn(D, K)
    Y = X @ Wtrue + 0.12*np.random.randn(N, K)
    Y_val = Y[200:]
    # Fit scaling scalaire (déjà vu)
    targets = (0.5, 0.8, 0.9, 0.95)
    # Retour simple: val_mae et coverages
    mae = float(np.mean(np.abs(mu - Y_val)))
    covs = [interval_coverage(Y_val.flatten(), mu.flatten(), std.flatten(), conf=t).empirical for t in targets]
    print({'val_mae': mae, 'coverage_emp': covs})

def run_isotonic_calibration_demo():
    pred_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), '..', '..', 'models', 'bayes_multi', 'val_pred.json')
    with open(pred_path, 'r') as fh:
        pred = json.load(fh)
    mu = np.array(pred['mu']); std = np.array(pred['std'])
    np.random.seed(7)
    N, D, K = 256, 24, 4
    X = np.random.randn(N, D); Wtrue = np.random.randn(D, K)
    Y = X @ Wtrue + 0.12*np.random.randn(N, K)
    Y_val = Y[200:]
    f = isotonic_sigma_mapping(Y_val, mu, std, n_quantiles=15)
    std_cal = f(std)
    ece = ece_regression(Y_val.flatten(), mu.flatten(), std_cal.flatten(), n_bins=12)
    cov90 = interval_coverage(Y_val.flatten(), mu.flatten(), std_cal.flatten(), conf=0.90).empirical
    print({'ece_iso': float(ece), 'cov90_iso': float(cov90)})

if __name__ == "__main__":
    # extend parser minimally to avoid breaking earlier commands
    pass
