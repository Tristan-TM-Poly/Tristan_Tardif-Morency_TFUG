\
"""General integral and Calderón check using SymPy."""
from sympy import symbols, integrate, oo, simplify, gamma, Rational, latex
a, p, c, sigma, r = symbols('a p c sigma r', positive=True)
# Generic integral formula (symbolic expression)
I_generic = Rational(1,2) * c**(-(p+1)/2) * gamma((p+1)/2)
# Substitute p=3, c = sigma^2 * r^2
p_val = Rational(3,1)
c_expr = sigma**2 * r**2
I_specific = I_generic.subs({p: p_val, c: c_expr})
I_r = simplify(r**4 * I_specific)
target = Rational(1,2) * sigma**(-4)
diff = simplify(I_r - target)
res = {
    'I_generic_latex': latex(I_generic),
    'I_specific_latex': latex(I_specific),
    'I_r_latex': latex(I_r),
    'target_latex': latex(target),
    'difference': str(diff)
}
with open('general_calderon_sympy_result.json','w') as f:
    import json
    json.dump(res, f, indent=2)
print("I_r =", I_r)
print("target =", target)
print("difference =", diff)
