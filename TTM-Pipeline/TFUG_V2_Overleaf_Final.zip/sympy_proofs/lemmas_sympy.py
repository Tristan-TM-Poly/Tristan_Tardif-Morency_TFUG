\
"""SymPy lemmas for change-of-variable identity used in proofs."""
from sympy import symbols, integrate, exp, gamma, Rational, simplify, latex
a, sigma, r = symbols('a sigma r', positive=True)
p = 3
c = sigma**2 * r**2
I = integrate(a**p * exp(-c * a**2), (a, 0, oo))
expected = Rational(1,2) * c**(-(p+1)/2) * gamma((p+1)/2)
diff = simplify(I - expected)
res = {'I_latex': latex(I), 'expected_latex': latex(expected), 'difference': str(diff)}
with open('lemmas_sympy_result.json','w') as f:
    import json
    json.dump(res, f, indent=2)
print("lemma diff:", diff)
