
"""Derive ICWT normalization constant C_psi(d) for LoG in R^d, and evaluate for d=1..10."""
from sympy import symbols, gamma, pi, Rational, latex, simplify
import json

# Symbols
d, sigma = symbols('d sigma', positive=True)
# |S^{d-1}| = 2*pi^{d/2} / Gamma(d/2)
S = 2*pi**(d/2) / gamma(d/2)

# From the analytic derivation: C_psi(d) = (3 * pi^{d/2}) / (2^8 * sigma^8 * Gamma(d/2))
C = (3 * pi**(d/2)) / (2**8 * sigma**8 * gamma(d/2))

C_latex = latex(C)
C_simpl = simplify(C)

# Evaluate numerically for sigma=1 and integer d
vals = []
for di in range(1, 11):
    Ci = C_simpl.subs({d: di, sigma: 1})
    vals.append({"d": di, "C_sigma1": float(Ci.evalf())})

out = {
    "C_expr_latex": C_latex,
    "sphere_area_latex": latex(S),
    "values_sigma1": vals
}
with open("icwtd_Cpsi_values.json","w") as f:
    json.dump(out, f, indent=2)
print("C_psi(d) LaTeX:", C_latex)
print("Saved values for d=1..10 at sigma=1")
