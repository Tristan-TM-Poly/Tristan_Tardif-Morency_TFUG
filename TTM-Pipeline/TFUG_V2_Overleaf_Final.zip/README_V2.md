# TFUG V2 — Overleaf-ready (Formal Proofs + ICWT(d))
- overleaf/main.tex: compile twice with pdflatex
- overleaf/appendix: proofs (Calderón radial, ICWT(d))
- overleaf/figures: Cpsi_vs_d.png
- sympy_proofs/: SymPy scripts
- tests/: pytest suite
