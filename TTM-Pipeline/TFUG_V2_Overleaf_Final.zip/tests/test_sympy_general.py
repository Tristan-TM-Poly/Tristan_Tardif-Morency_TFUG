\
import runpy, os, json
def test_sympy_general_results():
    base = os.path.dirname(__file__)
    gp = os.path.join(base, '..', 'sympy_proofs', 'general_calderon_sympy.py')
    lp = os.path.join(base, '..', 'sympy_proofs', 'lemmas_sympy.py')
    runpy.run_path(gp, run_name="__main__")
    runpy.run_path(lp, run_name="__main__")
    r1 = os.path.join(base, '..', 'general_calderon_sympy_result.json')
    r2 = os.path.join(base, '..', 'sympy_proofs', 'lemmas_sympy_result.json')
    assert os.path.exists(r1), "general result missing"
    assert os.path.exists(r2), "lemmas result missing"
    j1 = json.load(open(r1))
    j2 = json.load(open(r2))
    assert j1.get('difference','') in ('0','0'), f"Non-zero diff: {j1.get('difference')}"
    assert j2.get('difference','') in ('0','0'), f"Non-zero diff lemma: {j2.get('difference')}"
