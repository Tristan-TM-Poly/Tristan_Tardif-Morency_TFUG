
import json, os, math, subprocess, sys

def test_icwtd_values_generated_and_sane():
    # Run the sympy script to generate the json
    root = os.path.dirname(__file__)
    script = os.path.join(root, "..", "sympy_proofs", "icwt_dimension_d.py")
    subprocess.run([sys.executable, script], check=True, cwd=os.path.join(root, ".."))
    # Load values
    js = os.path.join(root, "..", "icwtd_Cpsi_values.json")
    assert os.path.exists(js), "Missing output JSON"
    data = json.load(open(js))
    vals = data["values_sigma1"]
    # Basic sanity: positive and decreasing trend over d (not strictly for all d, but non-increasing overall is fine)
    prev = float("inf")
    for item in vals:
        v = float(item["C_sigma1"])
        assert v > 0.0, f"C(d) must be positive, got {v} for d={item['d']}"
        assert v <= prev + 1e-12, f"C(d) should not increase with d (heuristic); got {v} > {prev}"
        prev = v
