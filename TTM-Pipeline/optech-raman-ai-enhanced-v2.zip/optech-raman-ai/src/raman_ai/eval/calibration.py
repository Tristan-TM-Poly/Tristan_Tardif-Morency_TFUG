import numpy as np
from dataclasses import dataclass

@dataclass
class IntervalCalibrationResult:
    nominal: float
    empirical: float
    miscalibration: float

def interval_coverage(y_true: np.ndarray, mu: np.ndarray, sigma: np.ndarray, conf: float = 0.90) -> IntervalCalibrationResult:
    # assume Gaussian predictive. coverage if |y - mu| <= z * sigma
    from scipy.stats import norm
    z = norm.ppf(0.5 + conf/2.0)
    inside = np.abs(y_true - mu) <= z * sigma
    emp = inside.mean()
    return IntervalCalibrationResult(nominal=conf, empirical=float(emp), miscalibration=float(emp - conf))

def ece_regression(y_true: np.ndarray, mu: np.ndarray, sigma: np.ndarray, n_bins: int = 10):
    # Expected Calibration Error for regression using normalized residuals
    # r = |y - mu| / sigma ~ HalfNormal(0,1) if calibrated.
    r = np.abs(y_true - mu) / (sigma + 1e-12)
    # Bin by predicted sigma (uncertainty buckets)
    edges = np.quantile(sigma.flatten(), np.linspace(0,1,n_bins+1))
    ece = 0.0
    for i in range(n_bins):
        mask = (sigma >= edges[i]) & (sigma <= edges[i+1])
        if mask.sum() == 0:
            continue
        # Ideal E[r] in half-normal is sqrt(2/pi) ~ 0.7979
        ideal = np.sqrt(2/np.pi)
        gap = np.abs(r[mask].mean() - ideal)
        ece += (mask.mean() * gap)
    return float(ece)
