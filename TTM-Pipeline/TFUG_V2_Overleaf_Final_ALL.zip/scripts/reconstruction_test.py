
import numpy as np, json
import matplotlib.pyplot as plt

N = 256
sigma = 1.0
kx = np.fft.fftfreq(N) * 2*np.pi*N
ky = np.fft.fftfreq(N) * 2*np.pi*N
KX, KY = np.meshgrid(kx, ky, indexing='xy')
R = np.sqrt(KX*KX + KY*KY); R[0,0] = 1e-12

def I_estimate(R, sigma=1.0, nA=400):
    c = 8.0
    a_max = c / (sigma*np.maximum(R, 1e-6))
    U = np.linspace(0.0, 1.0, nA)
    A = U[None,None,:] * a_max[:,:,None]
    integrand = (A**3) * (R[:,:,None]**4) * np.exp(-(sigma**2) * (R[:,:,None]**2) * (A**2))
    from numpy import trapz
    I = trapz(integrand, U, axis=2) * a_max
    return I

I = I_estimate(R, sigma=sigma, nA=300)
C_true = 1.0/(2.0*sigma**4)
rel_err = np.abs(I - C_true)/C_true

plt.figure(); plt.imshow(rel_err, origin='lower'); plt.colorbar(); plt.title("Relative error"); plt.savefig("overleaf/figures/recon_relerr.png", dpi=160, bbox_inches="tight"); plt.close()

x = np.linspace(-2, 2, N)
X, Y = np.meshgrid(x, x, indexing='xy')
img = np.exp(- (X**2 + Y**2))
F = np.fft.fft2(img)
S = I / C_true
F_rec = F * (1.0/ S)
img_rec = np.fft.ifft2(F_rec).real
diff = img_rec - img
mse = float(np.mean((diff)**2))

plt.figure(); plt.imshow(img, origin='lower'); plt.title("Original"); plt.savefig("overleaf/figures/recon_orig.png", dpi=160, bbox_inches="tight"); plt.close()
plt.figure(); plt.imshow(img_rec, origin='lower'); plt.title("Reconstructed"); plt.savefig("overleaf/figures/recon_rec.png", dpi=160, bbox_inches="tight"); plt.close()
plt.figure(); plt.imshow(diff, origin='lower'); plt.title("Difference"); plt.savefig("overleaf/figures/recon_diff.png", dpi=160, bbox_inches="tight"); plt.close()

with open("reconstruction_report.json","w") as f:
    json.dump({"max_rel_err": float(np.max(rel_err)), "mean_rel_err": float(np.mean(rel_err)), "mse": mse}, f, indent=2)
print("OK", mse)
