# Optech Raman AI — Clean Bundle
Generated: 2025-11-04T17:16:16

## Contents
- Project source (cleaned): `optech_raman_ai_v5/`
  - includes `tests/`, `pytest.ini`, `requirements-dev.txt`, `.github/workflows/ci.yml`
  - excludes caches and virtualenvs
- Notebook: `Optech_Raman_AI_Testbench.ipynb`

## Quick start
```
pip install -r optech_raman_ai_v5/requirements-dev.txt
pytest -q
```
Open the notebook and run the first cells (Environment Check, Config).

