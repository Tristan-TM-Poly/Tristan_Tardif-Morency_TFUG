# Auto-generated tests for optech-raman-ai.src.raman_ai
import importlib, inspect, pytest

MODULE = "optech-raman-ai.src.raman_ai"

def test_import_module():
    m = importlib.import_module(MODULE)
    assert m is not None

def test_public_api_listable():
    m = importlib.import_module(MODULE)
    public = [(n, o) for n,o in inspect.getmembers(m) if not n.startswith("_")]
    assert isinstance(public, list)

