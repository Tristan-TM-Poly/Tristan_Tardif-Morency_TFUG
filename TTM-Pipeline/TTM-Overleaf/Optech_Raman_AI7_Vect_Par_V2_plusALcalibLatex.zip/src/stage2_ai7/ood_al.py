
import numpy as np

def mahalanobis_params(X: np.ndarray):
    mu = X.mean(axis=0, keepdims=True)
    cov = np.cov(X.T) + 1e-6*np.eye(X.shape[1])
    cov_inv = np.linalg.inv(cov)
    return mu, cov_inv

def mahalanobis_dist(X: np.ndarray, mu, cov_inv):
    D = X - mu
    return np.sqrt(np.sum(D @ cov_inv * D, axis=1))

def threshold_from_dist(d: np.ndarray, q: float = 0.95):
    return float(np.quantile(d, q))

def acquisition_variance(pred_var: np.ndarray, k: int = 5):
    idx = np.argsort(-pred_var)[:k]
    return idx


def acquisition_bald(pred_var: np.ndarray, noise_var: float = 1e-2, k: int = 5):
    # Proxy BALD (Gaussian): log(1 + v_epistemic / v_noise)
    v_epi = np.maximum(pred_var - noise_var, 0.0)
    score = np.log1p(v_epi / (noise_var + 1e-12))
    idx = np.argsort(-score)[:k]
    return idx, score

def acquisition_ei(mean: np.ndarray, pred_std: np.ndarray, y_best: float, k: int = 5, maximize: bool = True):
    # Expected Improvement (Gaussian predictive)
    from math import sqrt
    def phi(z):  # pdf
        return (1.0/math.sqrt(2*math.pi))*math.exp(-0.5*z*z)
    def Phi(z):  # cdf (approx via erf)
        import math
        return 0.5*(1.0+math.erf(z/math.sqrt(2.0)))
    m = mean.copy()
    s = np.clip(pred_std, 1e-9, None)
    if not maximize:
        m = -m; y_best = -y_best
    z = (m - y_best) / s
    # vectorized EI
    import numpy as np
    v_phi = np.vectorize(phi); v_Phi = np.vectorize(Phi)
    ei = (m - y_best) * v_Phi(z) + s * v_phi(z)
    idx = np.argsort(-ei)[:k]
    return idx, ei
