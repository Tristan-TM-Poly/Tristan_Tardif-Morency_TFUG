
import pandas as pd
from pathlib import Path

def df_to_booktabs(df: pd.DataFrame, caption: str, label: str) -> str:
    cols = list(df.columns)
    header = " & ".join(cols) + " \\ \midrule\n"
    rows = [" & ".join(str(df.iloc[i,j]) for j in range(len(cols))) + " \\" for i in range(len(df))]
    body = "\n".join(rows)
    table = f"""
\begin{table}[ht]
\centering
\begin{tabular}{{{}}}
\toprule
{}{}\bottomrule
\end{tabular}
\caption{{{}}}
\label{{{}}}
\end{table}
""".format("l"*len(cols), header, body, caption, label)
    return table

def export_csv_to_latex(csv_path: str, out_tex: str, caption: str, label: str):
    df = pd.read_csv(csv_path)
    tex = df_to_booktabs(df, caption, label)
    Path(out_tex).parent.mkdir(parents=True, exist_ok=True)
    with open(out_tex, 'w', encoding='utf-8') as f:
        f.write(tex)
    return out_tex
