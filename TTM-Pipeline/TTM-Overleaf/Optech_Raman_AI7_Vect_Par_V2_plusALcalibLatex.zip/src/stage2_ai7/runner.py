
import pandas as pd
import numpy as np
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed

from .config import ConfigStage2
from .features import feature_vector
from .bayes import fit_blr_multi, predict_blr_multi
from .ood_al import mahalanobis_params, mahalanobis_dist, threshold_from_dist, acquisition_variance, acquisition_bald, acquisition_ei

def _load_proc(path: str):
    return pd.read_csv(path)

def _feat_one(path: str):
    df = _load_proc(path)
    vec, keys = feature_vector(df)
    return Path(path).name, vec, keys

def run_stage2(cfg: ConfigStage2, acq: str = 'var', calib_method: str = 'none', report_dir: str = 'report'):
    in_dir = Path(cfg.input_path); out = Path(cfg.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    rdir = Path(report_dir); rdir.mkdir(parents=True, exist_ok=True)

    # gather processed files from stage1
    files = sorted([str(x) for x in Path(in_dir).glob("proc_*.csv")])
    meta_path = Path(in_dir).parent / "synth" / "metadata.csv"
    if not files or not meta_path.exists():
        raise FileNotFoundError("Stage1 outputs or metadata missing. Run stage1 first.")

    meta = pd.read_csv(meta_path)
    # Parallel feature extraction
    X_list = []; names = []; feat_keys = None
    with ProcessPoolExecutor() as ex:
        futs = {ex.submit(_feat_one, f): f for f in files}
        for fut in as_completed(futs):
            name, vec, keys = fut.result()
            names.append(name); X_list.append(vec); feat_keys = keys
    X = np.vstack(X_list)

    # Targets from metadata (match by original file name)
    base_names = [n.replace("proc_", "") for n in names]
    Y = np.vstack([
        [float(meta.loc[meta['file']==bn, 'dopant_ppm'].values[0]),
         float(meta.loc[meta['file']==bn, 'temperature_true'].values[0])]
        for bn in base_names
    ])

    # BLR multi-output
    post = fit_blr_multi(X, Y, alpha=cfg.alpha, beta=cfg.beta)
    mean, var = predict_blr_multi(post, X)

    # OOD
    mu, cov_inv = mahalanobis_params(X)
    maha = mahalanobis_dist(X, mu, cov_inv)
    thr = threshold_from_dist(maha, 0.95)

    # Save artifacts
    pd.DataFrame(X, columns=feat_keys).to_csv(out/'features.csv', index=False)
    preds = pd.DataFrame({
        'file': base_names,
        'dopant_ppm_true': Y[:,0],
        'temperature_true': Y[:,1],
        'dopant_ppm_pred': mean[:,0],
        'temperature_pred': mean[:,1],
        'pred_var_shared': var,
        'mahalanobis': maha,
    })
    preds.to_csv(out/'predictions.csv', index=False)

    # Reliability + export LaTeX tables
    from .calibration import reliability_curve, apply_recalibration
    from .latex import export_csv_to_latex
    rel = reliability_curve(Y[:,0], mean[:,0], var, out_png=str(out/'reliability_multi.png'))
    # Export LaTeX tables
    export_csv_to_latex(str(out/'predictions.csv'), str(rdir/'table_predictions.tex'), 'Predictions (shared variance)', 'tab:preds')
    export_csv_to_latex(str(out/'features.csv'), str(rdir/'table_features.tex'), 'Feature matrix (excerpt)', 'tab:features')


    # Active learning candidates (variance-max on dopant var proxy)
    k = int(cfg.active_k)
    if acq == 'var':
        cand_idx = acquisition_variance(var, k=k)
        scores = var[cand_idx]
    elif acq == 'bald':
        cand_idx, scores = acquisition_bald(var, noise_var=1.0/cfg.beta, k=k)
    elif acq == 'ei':
        # EI sur dopant (maximisation)
        y_best = float(np.max(mean[:,0]))
        pred_std = np.sqrt(np.maximum(var, 1e-12))
        cand_idx, scores = acquisition_ei(mean[:,0], pred_std, y_best, k=k, maximize=True)
    else:
        cand_idx = acquisition_variance(var, k=k); scores = var[cand_idx]
    pd.DataFrame({'rank': list(range(1, k+1)), 'file': [base_names[i] for i in cand_idx], 'score': scores}).to_csv(out/'al_candidates.csv', index=False)

    return {'n': len(files), 'features': X.shape[1], 'ood_thr': float(thr)}
