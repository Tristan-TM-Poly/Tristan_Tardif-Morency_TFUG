
# Optech Raman AI

Pipeline reproductible pour spectroscopie Raman :
- Format **Parquet** + schéma canonique
- Prétraitement vectorisé (spikes, baseline, normalisation, alignement, lissage)
- Featurisation hybride (pics, ratios, **FWT/TFUG** placeholder)
- Tête **bayésienne** multi-sorties (architecture extensible)
- **DVC** stages + **CLI** (`raman`)
- Rapport IEEE auto (LaTeX, TikZ/PGF)

> Généré le 2025-11-04T16:13:07.447338Z

## Installation (dev)

```
python -m venv .venv && source .venv/bin/activate  # (Windows: .venv\Scripts\activate)
pip install -e .
```

## Commandes clés

```
raman prep   --in data/raw --out data/parquet --align --baseline asls --norm snv --smooth sg
raman feats  --in data/parquet --out data/features --fwt --df --peaks voigt --ratios default
raman train  --feats data/features --model conv1d_bayes --cv 5 --seed 42
raman eval   --feats data/features --model models/conv1d_bayes.pt --uncertainty
raman report --metrics reports/metrics.json --latex templates/ieee/main.tex --out reports/paper.pdf
```

## Arborescence

```
optech-raman-ai/
  src/raman_ai/...
  data/{{raw, parquet, features, models, reports}}
  dvc.yaml
  params.yaml
  tests/
```

## Notes
- Les modules **FWT/TFUG** sont fournis en *squelette* pour brancher vos implémentations (ou packages internes).
- **Torch** et **DVC** sont laissés en option pour éviter un lock d'environnement ici.


### Option TFUQ
Ajoute des features basées sur des invariants TFUQ/TFQ:

```
raman feats --in data/parquet --out data/features --fwt --df --tfuq
```
