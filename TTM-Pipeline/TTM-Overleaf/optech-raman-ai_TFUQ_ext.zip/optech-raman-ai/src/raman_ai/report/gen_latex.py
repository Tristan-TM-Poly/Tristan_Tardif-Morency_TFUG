
import os, json, shutil, subprocess, tempfile
from jinja2 import Environment, FileSystemLoader

def run(metrics_path: str, latex_template: str, out_pdf: str):
    here = os.path.dirname(__file__)
    tpl_dir = os.path.join(here, "templates", "ieee")
    env = Environment(loader=FileSystemLoader(tpl_dir))
    with open(metrics_path, "r") as f:
        metrics = json.load(f)
    tpl = env.get_template("main.tex")
    tex = tpl.render(metrics=metrics)
    tmp = tempfile.mkdtemp()
    tex_path = os.path.join(tmp, "paper.tex")
    with open(tex_path, "w") as f:
        f.write(tex)
    try:
        subprocess.run(["pdflatex", "-interaction=nonstopmode", "paper.tex"], cwd=tmp, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        os.makedirs(os.path.dirname(out_pdf), exist_ok=True)
        shutil.copy(os.path.join(tmp, "paper.pdf"), out_pdf)
    except Exception:
        os.makedirs(os.path.dirname(out_pdf), exist_ok=True)
        shutil.copy(tex_path, out_pdf.replace(".pdf",".tex"))
