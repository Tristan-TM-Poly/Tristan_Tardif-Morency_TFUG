
import os, json
import numpy as np
import pandas as pd
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error

def run(feats_folder: str, model: str="conv1d_bayes", cv: int=5, seed: int=42):
    fp = os.path.join(feats_folder, "features.parquet")
    df = pd.read_parquet(fp)
    y = df.get("peak_max", pd.Series(np.random.randn(len(df))))
    X = df.drop(columns=[c for c in df.columns if c in ("sample_id","peak_max")], errors="ignore").fillna(0.0).to_numpy()
    kf = KFold(n_splits=max(2, min(cv, max(2, len(df)//2))), shuffle=True, random_state=seed)
    rmses = []
    for tr, va in kf.split(X):
        m = RandomForestRegressor(random_state=seed)
        m.fit(X[tr], y.iloc[tr])
        p = m.predict(X[va])
        rmses.append(float(np.sqrt(mean_squared_error(y.iloc[va], p))))
    os.makedirs("models", exist_ok=True)
    metrics = {"cv_rmse_mean": float(np.mean(rmses)), "cv_rmse_std": float(np.std(rmses))}
    with open("models/last_metrics.json","w") as f:
        json.dump(metrics, f, indent=2)
    model_art = {"feature_means": df.mean(numeric_only=True).to_dict()}
    with open("models/last.pkl","w") as f:
        json.dump(model_art, f)


def _aggregate_feature_means(df):
    return df.mean(numeric_only=True).to_dict()

def run_bayes_multi(feats_folder: str):
    import pandas as pd, json, os
    fp = os.path.join(feats_folder, "features.parquet")
    df = pd.read_parquet(fp)
    art = {"feature_means": _aggregate_feature_means(df), "type": "bayes_multi_placeholder"}
    os.makedirs("models", exist_ok=True)
    with open("models/last.pkl","w") as f:
        json.dump(art, f)
