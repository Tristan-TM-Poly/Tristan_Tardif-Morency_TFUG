
from typing import Optional
import typer
from rich import print
from .io import parquet as io_parquet
from .preprocess import pipeline as prepipe
from .features import pipeline as featpipe
from .models import train as train_mod
from .eval import evaluate as eval_mod
from .report import gen_latex as report_mod

app = typer.Typer(add_completion=False, help="Optech Raman AI CLI")

@app.command()
def prep(
    in_: str = typer.Option(..., "--in", help="Input folder (raw or parquet)."),
    out: str = typer.Option(..., "--out", help="Output folder."),
    align: bool = typer.Option(True, "--align/--no-align"),
    baseline: str = typer.Option("asls", "--baseline", help="asls|airpls"),
    norm: str = typer.Option("snv", "--norm", help="snv|area"),
    smooth: str = typer.Option("sg", "--smooth", help="sg|none"),
    do: str = typer.Option("all", "--do", help="raw2parquet|all"),
):
    print("[bold cyan]Prep:[/bold cyan] reading, preprocessing and writing Parquet.")
    io_parquet.ensure_parquet(in_, out)  # raw→parquet if needed
    if do in ("all", "preprocess"):
        prepipe.run(out, align=align, baseline=baseline, norm=norm, smooth=smooth)

@app.command()
def feats(
    in_: str = typer.Option(..., "--in", help="Parquet folder (preprocessed)."),
    out: str = typer.Option(..., "--out", help="Features output folder."),
    fwt: bool = typer.Option(True, "--fwt/--no-fwt"),
    df: bool = typer.Option(True, "--df/--no-df"),
    tfuq_on: bool = typer.Option(True, "--tfuq/--no-tfuq"),
    peaks: str = typer.Option("voigt", "--peaks", help="voigt|gauss|lorentz"),
    ratios: str = typer.Option("default", "--ratios"),
):
    print("[bold cyan]Features:[/bold cyan] extracting features.")
    featpipe.run(in_, out, fwt=fwt, df=df, peaks=peaks, ratios=ratios, tfuq_on=tfuq_on)

@app.command()
def train(
    feats: str = typer.Option(..., "--feats", help="Features folder."),
    model: str = typer.Option("conv1d_bayes", "--model"),
    cv: int = typer.Option(5, "--cv"),
    seed: int = typer.Option(42, "--seed"),
):
    print("[bold cyan]Train:[/bold cyan] training model.")
    train_mod.run(feats, model=model, cv=cv, seed=seed)

@app.command()
def eval(
    feats: str = typer.Option(..., "--feats", help="Features folder."),
    model: str = typer.Option(..., "--model", help="Model path (.pt or .pkl)."),
    out: str = typer.Option("reports/metrics.json", "--out"),
    uncertainty: bool = typer.Option(True, "--uncertainty/--no-uncertainty"),
):
    print("[bold cyan]Eval:[/bold cyan] evaluating model.")
    eval_mod.run(feats, model, out, uncertainty=uncertainty)

@app.command()
def report(
    metrics: str = typer.Option(..., "--metrics"),
    latex: str = typer.Option("templates/ieee/main.tex", "--latex"),
    out: str = typer.Option("reports/paper.pdf", "--out"),
):
    print("[bold cyan]Report:[/bold cyan] generating LaTeX/PDF report.")
    report_mod.run(metrics, latex, out)

if __name__ == "__main__":
    app()
