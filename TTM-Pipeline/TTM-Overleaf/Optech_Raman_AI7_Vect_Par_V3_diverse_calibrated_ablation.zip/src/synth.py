
import numpy as np
import pandas as pd
from pathlib import Path

def gauss(x, mu, sig, amp):
    return amp * np.exp(-0.5*((x-mu)/sig)**2)

def synth_spectrum(x, alpha, laser_nm=532, pol='parallel', temp_C=23.0):
    compA = gauss(x, 520.7, 4.0, 1.0) + gauss(x, 960, 6.5, 0.45)
    compB = gauss(x, 1350, 10.0, 0.6) + gauss(x, 1580, 8.0, 0.7)
    baseline = 0.0006*(x-200) + 0.02*np.sin(x/120.0)
    pol_scale = 1.0 if pol=='parallel' else 0.95
    laser_scale = 1.0 if laser_nm==532 else (0.96 if laser_nm==633 else 0.92)
    y = (alpha*compA + (1-alpha)*compB)
    y = laser_scale * pol_scale * y + baseline
    return y

def ensure_synth_dataset(folder: str, n: int = 64, seed: int = 1234):
    p = Path(folder); p.mkdir(parents=True, exist_ok=True)
    if any(p.glob("*.csv")):
        return
    rng = np.random.default_rng(seed)
    w = np.linspace(200, 2000, 2200)
    rows = []
    lasers = [532, 633, 785]
    pols = ['parallel','perp']
    for i in range(n):
        alpha = rng.uniform(0.0, 1.0)
        laser = int(rng.choice(lasers))
        pol = str(rng.choice(pols))
        temp = float(20 + 10*rng.random())
        y = synth_spectrum(w, alpha, laser_nm=laser, pol=pol, temp_C=temp)
        noise = rng.normal(0, 0.01, size=w.shape)
        y = y + noise
        pd.DataFrame({'wavenumber': w, 'intensity': y}).to_csv(p/f"sample_{i:04d}.csv", index=False)
        rows.append({'file': f"sample_{i:04d}.csv", 'alpha': alpha, 'laser_nm': laser, 'pol': pol, 'temperature_C': temp,
                     'dopant_ppm': 1000*alpha, 'temperature_true': temp})
    pd.DataFrame(rows).to_csv(p/'metadata.csv', index=False)
