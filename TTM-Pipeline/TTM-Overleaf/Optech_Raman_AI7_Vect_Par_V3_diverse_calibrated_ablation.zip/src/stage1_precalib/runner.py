
import pandas as pd
import numpy as np
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed

from .config import ConfigStage1
from .io_utils import ensure_parent, list_csvs, load_csv
from .preprocess import preprocess_df
from .peaks import extract_peaks
from .standards import match_standards

def _process_one(path: str, cfg: ConfigStage1):
    df = load_csv(path)
    dfp = preprocess_df(df, cfg.smoothing_window, cfg.baseline_order, cfg.normalize)
    peaks = extract_peaks(dfp, cfg.peak_prominence, cfg.peak_min_distance)
    calib = match_standards(peaks, tol_cm1=cfg.tol_cm1)
    if abs(calib['offset_cm1']) > 0:
        dfp['wavenumber'] = dfp['wavenumber'] - calib['offset_cm1']
        peaks = extract_peaks(dfp, cfg.peak_prominence, cfg.peak_min_distance)
    name = Path(path).name
    return name, dfp, peaks, calib

def run_stage1(cfg: ConfigStage1):
    in_dir = Path(cfg.input_path); out = Path(cfg.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    # list
    files = list_csvs(str(in_dir))
    if not files:
        from synth import ensure_synth_dataset
        ensure_synth_dataset(str(in_dir), n=cfg.n_synth, seed=cfg.seed)
        files = list_csvs(str(in_dir))

    peaks_rows = []
    calibs = []
    # Parallel map
    with ProcessPoolExecutor() as ex:
        futs = {ex.submit(_process_one, f, cfg): f for f in files}
        for fut in as_completed(futs):
            name, dfp, peaks, calib = fut.result()
            dfp.to_csv(out/f"proc_{name}", index=False)
            peaks.insert(0, 'file', name)
            peaks_rows.append(peaks)
            calibs.append({'file': name, **calib})
    if peaks_rows:
        pd.concat(peaks_rows, axis=0).to_csv(out/'peaks_top.csv', index=False)
    pd.DataFrame(calibs).to_csv(out/'calibration_log.csv', index=False)
    return {'n': len(files), 'out': str(out)}
