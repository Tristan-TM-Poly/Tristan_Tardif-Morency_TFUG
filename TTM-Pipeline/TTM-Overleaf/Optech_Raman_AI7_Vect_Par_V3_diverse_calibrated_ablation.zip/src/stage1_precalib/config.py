
from dataclasses import dataclass

@dataclass
class ConfigStage1:
    input_path: str = "data/synth"
    out_dir: str = "artifacts/stage1"
    smoothing_window: int = 7
    baseline_order: int = 3
    normalize: bool = True
    peak_prominence: float = 0.03
    peak_min_distance: int = 5
    tol_cm1: float = 10.0
    n_synth: int = 64
    seed: int = 1234
