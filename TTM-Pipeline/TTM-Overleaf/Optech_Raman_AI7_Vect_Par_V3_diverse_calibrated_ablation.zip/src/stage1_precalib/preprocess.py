
import numpy as np
import pandas as pd

def moving_average(x: np.ndarray, w: int) -> np.ndarray:
    w = max(1, int(w)); w += (w%2==0)
    pad = w//2
    xpad = np.pad(x, (pad,pad), mode='edge')
    kern = np.ones(w)/w
    return np.convolve(xpad, kern, mode='valid')

def poly_baseline(x: np.ndarray, y: np.ndarray, order: int = 3) -> np.ndarray:
    order = max(1, int(order))
    coeff = np.polyfit(x, y, order)
    return np.polyval(coeff, x)

def normalize_area(y: np.ndarray) -> np.ndarray:
    area = np.trapz(np.maximum(y, 0.0))
    return y/area if area>0 else y

def preprocess_df(df: pd.DataFrame, smoothing_window: int, baseline_order: int, do_normalize: bool) -> pd.DataFrame:
    x = df['wavenumber'].to_numpy()
    y = df['intensity'].to_numpy()
    y_s = moving_average(y, smoothing_window)
    base = poly_baseline(x, y_s, baseline_order)
    y_c = np.maximum(y_s - base, 0.0)
    y_p = normalize_area(y_c) if do_normalize else y_c
    out = df.copy()
    out['intensity_smooth'] = y_s
    out['baseline'] = base
    out['intensity_proc'] = y_p
    return out
