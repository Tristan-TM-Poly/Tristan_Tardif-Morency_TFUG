
import numpy as np
import pandas as pd

def _peaks_indices(y: np.ndarray, prominence: float, min_distance: int):
    dy = np.diff(y)
    sign = np.sign(dy)
    zero = np.where((sign[:-1]>0) & (sign[1:]<0))[0] + 1
    peaks = []
    last = -min_distance
    for i in zero:
        if y[i] >= prominence and (i-last) >= min_distance:
            peaks.append(i); last = i
    return np.array(peaks, dtype=int)

def _fwhm(x, y, idx):
    h = y[idx]/2.0
    i = idx
    while i>0 and y[i] > h: i -= 1
    xL = x[i]
    if i<idx and y[i]!=y[i+1]:
        xL = np.interp(h, [y[i], y[i+1]], [x[i], x[i+1]])
    j = idx
    while j<len(y)-1 and y[j] > h: j += 1
    xR = x[j]
    if j>idx and y[j-1]!=y[j]:
        xR = np.interp(h, [y[j-1], y[j]], [x[j-1], x[j]])
    return max(xR - xL, 1e-9)

def _area(x, y, idx, w=10):
    i0 = max(0, idx-w); i1 = min(len(x)-1, idx+w)
    return np.trapz(y[i0:i1+1], x[i0:i1+1])

def extract_peaks(dfp: pd.DataFrame, prominence: float, min_distance: int) -> pd.DataFrame:
    x = dfp['wavenumber'].to_numpy()
    y = dfp['intensity_proc'].to_numpy()
    pk = _peaks_indices(y, prominence, min_distance)
    if pk.size == 0:
        return pd.DataFrame(columns=['wavenumber','height','fwhm','area'])
    heights = y[pk]
    fwhms = np.array([_fwhm(x,y,i) for i in pk], dtype=float)
    areas  = np.array([_area(x,y,i) for i in pk], dtype=float)
    return pd.DataFrame({'wavenumber': x[pk], 'height': heights, 'fwhm': fwhms, 'area': areas})
