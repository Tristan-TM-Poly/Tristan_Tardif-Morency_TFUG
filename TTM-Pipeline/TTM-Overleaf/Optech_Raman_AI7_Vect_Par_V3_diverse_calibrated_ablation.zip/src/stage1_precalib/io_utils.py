
from pathlib import Path
import pandas as pd

def ensure_parent(path: str):
    Path(path).parent.mkdir(parents=True, exist_ok=True)

def list_csvs(folder: str):
    p = Path(folder)
    return sorted([str(x) for x in p.glob("*.csv") if x.name != "metadata.csv"])

def load_csv(path: str) -> pd.DataFrame:
    return pd.read_csv(path)
