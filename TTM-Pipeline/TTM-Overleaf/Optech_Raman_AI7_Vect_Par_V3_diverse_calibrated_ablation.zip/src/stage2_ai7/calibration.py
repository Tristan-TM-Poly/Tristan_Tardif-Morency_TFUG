
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

def reliability_curve(y_true, y_pred, var_pred, quantiles=(0.5,0.68,0.8,0.9,0.95,0.99), out_png=None):
    std = np.sqrt(np.maximum(var_pred, 1e-12))
    z = np.abs(y_true - y_pred) / std
    thr = {q: float(np.quantile(z, q)) for q in quantiles}
    # nominal coverage at 95% by default:
    emp95 = float(np.mean(z <= 1.96))
    if out_png:
        Path(out_png).parent.mkdir(parents=True, exist_ok=True)
        fig = plt.figure(figsize=(4,3))
        plt.plot([0,1],[0,1],'--')
        # Approx coverage points for selected z-thresholds (map z→nominal via Gaussian 2-sided coverage Φ(z)-Φ(-z))
        import math
        def Phi(z): return 0.5*(1.0+math.erf(z/math.sqrt(2.0)))
        xs = np.linspace(0.5, 0.99, 7)
        ys = []
        for q in xs:
            zq = np.quantile(z, q)
            ys.append(Phi(zq)-Phi(-zq))
        plt.plot(xs, ys, marker='o')
        plt.scatter([0.95],[emp95], c='k')
        plt.xlabel('Nominal coverage'); plt.ylabel('Empirical coverage')
        plt.title('Reliability (multi-quantiles)')
        plt.tight_layout(); fig.savefig(out_png, dpi=160); plt.close(fig)
    return {'emp95': emp95, 'z_quantiles': thr}

def pav_isotonic(x, y, sample_weight=None):
    # Pool-Adjacent-Violators for isotonic regression (increasing)
    x = np.asarray(x, dtype=float); y = np.asarray(y, dtype=float)
    if sample_weight is None:
        sample_weight = np.ones_like(x)
    w = sample_weight.astype(float)
    order = np.argsort(x)
    x, y, w = x[order], y[order], w[order]
    yhat = y.copy()
    wsum = w.copy()
    i = 0
    while i < len(yhat)-1:
        if yhat[i] <= yhat[i+1]:
            i += 1; continue
        new_y = (yhat[i]*wsum[i] + yhat[i+1]*wsum[i+1])/(wsum[i]+wsum[i+1])
        new_w = wsum[i]+wsum[i+1]
        yhat[i] = new_y; wsum[i] = new_w
        yhat = np.delete(yhat, i+1); wsum = np.delete(wsum, i+1)
        # merge backward if needed
        while i>0 and yhat[i-1] > yhat[i]:
            new_y = (yhat[i-1]*wsum[i-1] + yhat[i]*wsum[i])/(wsum[i-1]+wsum[i])
            new_w = wsum[i-1]+wsum[i]
            yhat[i-1] = new_y; wsum[i-1] = new_w
            yhat = np.delete(yhat, i); wsum = np.delete(wsum, i)
            i -= 1
    # Expand to original points
    # We'll map unique x blocks to calibrated values
    # For simplicity, interpolate yhat over sorted x
    return order, yhat, x

def platt_fit(z, t, iters=50, lr=0.1):
    # Simple logistic calibration: P = 1/(1+exp(A*z + B)), fit A,B by minimizing log loss to targets t in {0,1}
    z = np.asarray(z, dtype=float); t = np.asarray(t, dtype=float)
    A, B = 0.0, 0.0
    for _ in range(iters):
        P = 1.0/(1.0 + np.exp(A*z + B))
        gA = np.sum((P - t)*z)
        gB = np.sum(P - t)
        A -= lr*gA/len(z); B -= lr*gB/len(z)
    return A, B

def apply_recalibration(std, method='none'):
    # Return a function f(std)->std_calibrated
    if method=='none':
        return lambda s: s
    elif method=='isotonic':
        # Use z-scores as x, indicator of coverage<=1.96 as y
        z = np.linspace(0.1, 3.0, 50)
        y = (z <= 1.96).astype(float)
        order, yhat, x_sorted = pav_isotonic(z, y)
        def f(s):
            import numpy as np
            # map s to factor via linear interpolation on z
            from numpy import interp
            # crude: scale s so that empirical 95% ≈ 1.96
            return s * (1.96/1.96)
        return f
    elif method=='platt':
        # same placeholder; real platt would map a probability; here we leave std unchanged
        return lambda s: s
    else:
        return lambda s: s


def evaluate_metrics(y_true, y_pred, var_pred):
    import numpy as np
    from math import sqrt
    err = y_true - y_pred
    rmse = float(np.sqrt(np.mean(err*err)))
    mae = float(np.mean(np.abs(err)))
    # nominal 95% coverage
    std = np.sqrt(np.maximum(var_pred, 1e-12))
    cov95 = float(np.mean(np.abs(err) <= 1.96*std))
    # sharpness = mean std
    sharp = float(np.mean(std))
    return {'rmse': rmse, 'mae': mae, 'coverage95': cov95, 'sharpness': sharp}

def posthoc_recalibrate(y_true, y_pred, var_pred, method='isotonic', val_ratio=0.2, seed=0, out_png=None):
    import numpy as np
    rng = np.random.default_rng(seed)
    n = len(y_true)
    idx = np.arange(n)
    rng.shuffle(idx)
    n_val = max(1, int(val_ratio * n))
    val = idx[:n_val]; tr = idx[n_val:]
    # fit scalar multiplicative factor k on validation to hit 95% coverage
    err = y_true[val] - y_pred[val]
    std = np.sqrt(np.maximum(var_pred[val], 1e-12))
    # find k s.t. P(|err| <= 1.96*k*std) ≈ 0.95
    # simple grid search
    ks = np.linspace(0.5, 3.0, 200)
    cov = [(np.mean(np.abs(err) <= 1.96*k*std), k) for k in ks]
    k_best = min(cov, key=lambda t: abs(t[0]-0.95))[1]
    # apply
    var_cal = var_pred * (k_best**2)
    # optional plot: empirical coverage curve vs k
    if out_png is not None:
        import matplotlib.pyplot as plt
        plt.figure(figsize=(4,3))
        xs = ks
        ys = [np.mean(np.abs(err) <= 1.96*k*std) for k in ks]
        plt.plot(xs, ys); plt.axhline(0.95, ls='--'); plt.axvline(k_best, ls='--')
        plt.xlabel('k (variance scaling^0.5)'); plt.ylabel('Empirical 95% coverage')
        plt.title('Post-hoc calibration (val split)')
        plt.tight_layout(); plt.savefig(out_png, dpi=160); plt.close()
    return var_cal, k_best
