
from dataclasses import dataclass

@dataclass
class ConfigStage2:
    input_path: str = "artifacts/stage1"
    out_dir: str = "artifacts/stage2"
    active_k: int = 5
    alpha: float = 1.0    # BLR prior precision
    beta: float = 100.0   # BLR noise precision
