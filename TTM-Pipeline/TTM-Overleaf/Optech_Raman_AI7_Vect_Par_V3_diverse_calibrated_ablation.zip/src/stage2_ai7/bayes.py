
import numpy as np
from dataclasses import dataclass

@dataclass
class BLRPosterior:
    M: np.ndarray  # p x q
    S: np.ndarray  # p x p
    alpha: float
    beta: float

def fit_blr_multi(X: np.ndarray, Y: np.ndarray, alpha: float=1.0, beta: float=100.0) -> BLRPosterior:
    XtX = X.T @ X
    S_inv = alpha * np.eye(X.shape[1]) + beta * XtX
    S = np.linalg.inv(S_inv)
    M = beta * S @ X.T @ Y
    return BLRPosterior(M=M, S=S, alpha=alpha, beta=beta)

def predict_blr_multi(post: BLRPosterior, Xnew: np.ndarray):
    mean = Xnew @ post.M                 # (n x q)
    var  = (1.0/post.beta) + np.sum(Xnew @ post.S * Xnew, axis=1)  # (n,)
    return mean, var
