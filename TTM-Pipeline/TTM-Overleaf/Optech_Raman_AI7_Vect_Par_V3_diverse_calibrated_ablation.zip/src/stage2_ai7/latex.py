
import pandas as pd
from pathlib import Path

def df_to_booktabs(df: pd.DataFrame, caption: str, label: str) -> str:
    cols = list(df.columns)
    header = " & ".join(cols) + " \\ \midrule\n"
    rows = [" & ".join(str(df.iloc[i,j]) for j in range(len(cols))) + " \\" for i in range(len(df))]
    body = "\n".join(rows)
    table = f"""
\begin{table}[ht]
\centering
\begin{tabular}{{{}}}
\toprule
{}{}\bottomrule
\end{tabular}
\caption{{{}}}
\label{{{}}}
\end{table}
""".format("l"*len(cols), header, body, caption, label)
    return table

def export_csv_to_latex(csv_path: str, out_tex: str, caption: str, label: str):
    df = pd.read_csv(csv_path)
    tex = df_to_booktabs(df, caption, label)
    Path(out_tex).parent.mkdir(parents=True, exist_ok=True)
    with open(out_tex, 'w', encoding='utf-8') as f:
        f.write(tex)
    return out_tex


def ablation_table_from_predictions(csv_path: str, out_tex: str, caption: str, label: str, config_col: str = 'config'):
    import pandas as pd, numpy as np
    from pathlib import Path
    df = pd.read_csv(csv_path)
    # expected columns: y_true_*, y_pred_*, pred_var_shared, optionally 'config'
    # choose first target columns
    y_cols = [c for c in df.columns if c.startswith('y_true')]
    p_cols = [c for c in df.columns if c.startswith('y_pred')]
    if not y_cols or not p_cols:
        # fallback: infer 'true' and 'pred' generic names
        y_cols = ['true'] if 'true' in df.columns else [df.columns[0]]
        p_cols = ['pred'] if 'pred' in df.columns else [df.columns[1]]
    y = df[y_cols[0]].values.astype(float)
    m = df[p_cols[0]].values.astype(float)
    v = df['pred_var_shared'].values.astype(float) if 'pred_var_shared' in df.columns else np.full_like(m, np.var(y-m))
    def metrics(a,b,vv):
        err = a-b
        rmse = float(np.sqrt(np.mean(err*err)))
        mae = float(np.mean(np.abs(err)))
        std = np.sqrt(np.maximum(vv, 1e-12))
        cov95 = float(np.mean(np.abs(err) <= 1.96*std))
        return rmse, mae, cov95
    rows = []
    if config_col in df.columns:
        for cfg, g in df.groupby(config_col):
            rmse, mae, cov = metrics(g[y_cols[0]].values, g[p_cols[0]].values, g['pred_var_shared'].values if 'pred_var_shared' in g else np.full(len(g), np.var(g[y_cols[0]]-g[p_cols[0]])))
            rows.append((cfg, rmse, mae, cov))
    else:
        rmse, mae, cov = metrics(y, m, v)
        rows.append(("current", rmse, mae, cov))
    table_df = pd.DataFrame(rows, columns=['Config','RMSE','MAE','Cov95'])
    tex = df_to_booktabs(table_df, caption, label)
    Path(out_tex).parent.mkdir(parents=True, exist_ok=True)
    with open(out_tex, 'w', encoding='utf-8') as f:
        f.write(tex)
    return out_tex
