
import numpy as np
import pandas as pd

def multiscale_features(x: np.ndarray, y: np.ndarray, scales=(3,5,9,17,33)):
    feats = {}
    for s in scales:
        w = int(s) + (int(s)%2==0)
        pad = w//2
        ypad = np.pad(y, (pad,pad), mode='edge')
        kern = np.ones(w)/w
        y_lp = np.convolve(ypad, kern, mode='valid')
        res = y - y_lp
        feats[f"lp_mean_s{w}"] = float(np.mean(y_lp))
        feats[f"lp_std_s{w}"] = float(np.std(y_lp))
        feats[f"res_std_s{w}"] = float(np.std(res))
    # log-log slope (fractal proxy)
    s_arr = np.array([int(s) + (int(s)%2==0) for s in scales], dtype=float)
    v_arr = np.array([feats[f"res_std_s{int(s) + (int(s)%2==0)}"] for s in scales])
    s_log = np.log(s_arr+1e-9); v_log = np.log(v_arr+1e-9)
    A = np.vstack([s_log, np.ones_like(s_log)]).T
    m, c = np.linalg.lstsq(A, v_log, rcond=None)[0]
    feats["fractal_variance_slope"] = float(m)
    return feats

def quaternionic_proxies(x: np.ndarray, y: np.ndarray):
    dy = np.gradient(y); s = np.arange(1, len(y)+1, dtype=float)
    s_log = np.log(s+1e-9); v_log = np.log(np.abs(dy)+1e-9)
    A = np.vstack([s_log, np.ones_like(s_log)]).T
    m, c = np.linalg.lstsq(A, v_log, rcond=None)[0]
    D_f = float(-m)
    return {"D_f": D_f, "roughness": float(np.std(dy))}

def feature_vector(df: pd.DataFrame) -> np.ndarray:
    x = df['wavenumber'].to_numpy()
    y = df['intensity_proc'].to_numpy()
    f1 = multiscale_features(x,y)
    f2 = quaternionic_proxies(x,y)
    stats = dict(mean=float(np.mean(y)), std=float(np.std(y)), sum=float(np.sum(y)))
    # pack
    keys = sorted(list(f1.keys())+list(f2.keys())+list(stats.keys()))
    vec = np.array([ (f1|f2|stats)[k] for k in keys ], dtype=float)
    return vec, keys
