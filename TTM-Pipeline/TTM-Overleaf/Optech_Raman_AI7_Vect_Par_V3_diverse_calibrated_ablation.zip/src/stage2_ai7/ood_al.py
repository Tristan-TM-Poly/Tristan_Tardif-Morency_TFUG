
import numpy as np

def mahalanobis_params(X: np.ndarray):
    mu = X.mean(axis=0, keepdims=True)
    cov = np.cov(X.T) + 1e-6*np.eye(X.shape[1])
    cov_inv = np.linalg.inv(cov)
    return mu, cov_inv

def mahalanobis_dist(X: np.ndarray, mu, cov_inv):
    D = X - mu
    return np.sqrt(np.sum(D @ cov_inv * D, axis=1))

def threshold_from_dist(d: np.ndarray, q: float = 0.95):
    return float(np.quantile(d, q))

def acquisition_variance(pred_var: np.ndarray, k: int = 5):
    idx = np.argsort(-pred_var)[:k]
    return idx


def acquisition_bald(pred_var: np.ndarray, noise_var: float = 1e-2, k: int = 5):
    # Proxy BALD (Gaussian): log(1 + v_epistemic / v_noise)
    v_epi = np.maximum(pred_var - noise_var, 0.0)
    score = np.log1p(v_epi / (noise_var + 1e-12))
    idx = np.argsort(-score)[:k]
    return idx, score

def acquisition_ei(mean: np.ndarray, pred_std: np.ndarray, y_best: float, k: int = 5, maximize: bool = True):
    # Expected Improvement (Gaussian predictive)
    from math import sqrt
    def phi(z):  # pdf
        return (1.0/math.sqrt(2*math.pi))*math.exp(-0.5*z*z)
    def Phi(z):  # cdf (approx via erf)
        import math
        return 0.5*(1.0+math.erf(z/math.sqrt(2.0)))
    m = mean.copy()
    s = np.clip(pred_std, 1e-9, None)
    if not maximize:
        m = -m; y_best = -y_best
    z = (m - y_best) / s
    # vectorized EI
    import numpy as np
    v_phi = np.vectorize(phi); v_Phi = np.vectorize(Phi)
    ei = (m - y_best) * v_Phi(z) + s * v_phi(z)
    idx = np.argsort(-ei)[:k]
    return idx, ei


def _pairwise_sq_dists(X):
    import numpy as np
    # X: (n, d)
    # compute squared distances efficiently: ||x||^2 + ||y||^2 - 2 x.y
    G = X @ X.T
    nrm = np.sum(X*X, axis=1, keepdims=True)
    D = nrm + nrm.T - 2.0*G
    np.maximum(D, 0.0, out=D)
    return D

def acquisition_diverse(scores: np.ndarray, feats: np.ndarray, k: int = 5, lam: float = 0.5):
    """Greedy selection maximizing: score(i) - lam * max_j_in_S dist_penalty(i,j)
    where dist_penalty uses inverse similarity (we use 1 / (1 + d^0.5)) so far points reduce penalty.
    feats: (n, d) features, standardized upstream.
    """
    import numpy as np
    n = len(scores)
    S = []
    if n == 0: 
        return np.array([], dtype=int), np.array([])
    D = _pairwise_sq_dists(feats)
    # convert to similarity in [0,1]
    sim = 1.0 / (1.0 + np.sqrt(D) + 1e-12)
    # greedy
    remaining = np.argsort(-scores).tolist()
    while remaining and len(S) < k:
        best_i = None; best_val = -1e18
        for i in remaining[:min(200, len(remaining))]:  # cap for speed
            if not S:
                val = float(scores[i])
            else:
                # diversity penalty = lam * max similarity to current set
                pen = lam * float(np.max(sim[i, S]))
                val = float(scores[i]) - pen
            if val > best_val:
                best_val = val; best_i = i
        S.append(best_i)
        remaining.remove(best_i)
    S = np.array(S, dtype=int)
    return S, scores[S]
