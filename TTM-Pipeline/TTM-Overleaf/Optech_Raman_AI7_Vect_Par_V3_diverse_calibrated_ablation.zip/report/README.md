Compile your LaTeX report here; stage2 exports CSV/PNGs you can include.
