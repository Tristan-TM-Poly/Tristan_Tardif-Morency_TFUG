
import os, subprocess, sys, pathlib, json

def test_e2e():
    root = pathlib.Path(__file__).resolve().parents[1]
    # stage1
    subprocess.run([sys.executable, str(root/'scripts/run_stage1.py'), '--input', str(root/'data/synth'), '--out', str(root/'artifacts/stage1')], check=True)
    # stage2
    subprocess.run([sys.executable, str(root/'scripts/run_stage2.py'), '--input', str(root/'artifacts/stage1'), '--out', str(root/'artifacts/stage2')], check=True)
    assert (root/'artifacts/stage1/peaks_top.csv').exists()
    assert (root/'artifacts/stage2/predictions.csv').exists()
