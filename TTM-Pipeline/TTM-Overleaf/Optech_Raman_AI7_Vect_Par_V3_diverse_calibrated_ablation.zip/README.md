
# Optech Raman AI‑7 — Vectorized + Parallel Pipeline (V2)

This repository contains a **two‑stage** pipeline optimized for speed and structure:

1) **Preprocessing & Calibration** (`stage1_precalib`): smoothing, baseline, normalization, peak detection, standards‑based calibration.
2) **Physical Compression & Analytical + AI‑7** (`stage2_ai7`): multiscale TFUG/FWT features, quaternionic proxies, Bayesian multi‑output regression, OOD, active‑learning hooks.

- Parallel execution with `concurrent.futures`.
- Vectorized NumPy operations.
- Clean CLI under `scripts/` with `argparse`.
- Formatting configs: Black + Ruff.
- Dockerfile for reproducible runs.

## Quickstart
```bash
# Stage 1 (preprocess + calibrate all CSV spectra)
python scripts/run_stage1.py --input data/synth --out artifacts/stage1

# Stage 2 (features + AI)
python scripts/run_stage2.py --input artifacts/stage1 --out artifacts/stage2
```

Artifacts: processed CSVs, peaks, calibration logs, features, predictions, OOD scores, ablation CSV, reliability PNG.

