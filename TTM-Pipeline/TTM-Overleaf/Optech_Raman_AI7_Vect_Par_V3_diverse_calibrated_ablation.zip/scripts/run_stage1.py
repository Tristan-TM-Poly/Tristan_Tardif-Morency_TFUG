
import argparse
from stage1_precalib.config import ConfigStage1
from stage1_precalib.runner import run_stage1
from synth import ensure_synth_dataset

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="data/synth")
    ap.add_argument("--out", default="artifacts/stage1")
    ap.add_argument("--n_synth", type=int, default=64)
    ap.add_argument("--seed", type=int, default=1234)
    args = ap.parse_args()

    # Ensure synthetic data exists
    ensure_synth_dataset(args.input, n=args.n_synth, seed=args.seed)

    cfg = ConfigStage1(input_path=args.input, out_dir=args.out, n_synth=args.n_synth, seed=args.seed)
    info = run_stage1(cfg)
    print(f"[stage1] processed={info['n']} → {info['out']}")

if __name__ == "__main__":
    main()
