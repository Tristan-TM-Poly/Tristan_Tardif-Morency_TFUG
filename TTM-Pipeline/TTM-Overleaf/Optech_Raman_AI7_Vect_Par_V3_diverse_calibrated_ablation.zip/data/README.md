Place CSV spectra here. A synthetic set is generated at first run.
