# Optech Raman AI-7 — Runtime

## 1) Environnement
- Conda: `conda env create -f environment.yml && conda activate optech-raman-ai7`
- Docker: `docker build -t optech-raman-ai7:cpu .`

## 2) Configuration
- Éditez `config/config.yaml` pour le profil (site/instrument).

## 3) Exécution pipeline
- `make all` (ingest→qa→calibrate→preprocess→peaks→maps→identify→quantify→validate→pdf)
- Artefacts dans `artifacts/` (CSV/JSON/PNG).

## 4) Interfaces
- PDF: compilez `main.tex` (ou laissez la CI publier).
- Notebooks: ouvrez `notebooks/QA_Review.ipynb`, `ID_Inspection.ipynb`, `Quant_Audit.ipynb` (lecture des artefacts).
- Dashboard: `artifacts/qc_dashboard/index.html` (statique).

## 5) Traçabilité
- Tous les JSON contiennent `run_uuid`, `code_version`, `model_version`.
