
import click
from pathlib import Path
import sys, json

try:
    from .data.convert_csv_to_parquet import convert_folder as convert_csv_folder
except Exception:
    convert_csv_folder = None

try:
    from .utils.deduplicate import deduplicate_folder
except Exception:
    deduplicate_folder = None

from .features.fwt_tfug import TFUGFWTEmbedder, TFUGFWTConfig

import pandas as pd
import numpy as np
from scipy.signal import find_peaks

import yaml
from .utils.schema import validate_schema
from .pipelines.preprocess import preprocess_df, load_params_yaml, PreprocessParams
from .features.physics import features_physics
from .features.fwt_tfug import TFUGFWTEmbedder, TFUGFWTConfig
from .plotting.plot_spectra import plot_folder
from ..pipeline import report_gen as _report


@click.group()
def main():
    """Optech Raman AI — CLI."""

@main.command("convert-csv")
@click.option("--input", "input_dir", type=click.Path(path_type=Path), required=True)
@click.option("--output", "output_dir", type=click.Path(path_type=Path), required=True)
def convert_csv(input_dir: Path, output_dir: Path):
    """Convertir tous les CSV d'un dossier en Parquet (schéma auto minimal)."""
    if convert_csv_folder is None:
        raise click.ClickException("convert_csv_folder indisponible dans ce build.")
    convert_csv_folder(input_dir, output_dir)

@main.command("dedup")
@click.option("--input", "input_dir", type=click.Path(path_type=Path), required=True)
@click.option("--hash", "algo", type=click.Choice(["sha1","md5","size_mtime"], case_sensitive=False), default="sha1")
def dedup(input_dir: Path, algo: str):
    """Dé-duplication simple d'un dossier (parquet/...) via hash ou taille+mtime."""
    if deduplicate_folder is None:
        raise click.ClickException("deduplicate_folder indisponible dans ce build.")
    deduplicate_folder(input_dir, algo=algo)

def _deprecated_extract_features_physics(df: pd.DataFrame, prominence: float, distance: int, topk: int) -> dict:
    x = df["wavenumber_cm1"].to_numpy()
    y = df["intensity"].to_numpy()
    peaks, props = find_peaks(y, prominence=prominence, distance=distance)
    prom = props.get("prominences", np.zeros_like(peaks))
    order = np.argsort(prom)[::-1]
    peaks = peaks[order][:topk]
    feats = {
        "n_peaks": int(len(peaks)),
        "y_mean": float(np.mean(y)),
        "y_std": float(np.std(y)),
        "area": float(np.trapz(y, x)),
    }
    for i, p in enumerate(peaks):
        feats[f"peak_{i+1}_pos"] = float(x[p])
        feats[f"peak_{i+1}_height"] = float(y[p])
    return feats

def run_features_dir(input_dir: Path, output_path: Path, method: str, prominence: float, distance: int, topk: int, downsample: int):
    rows = []
    emb_dim = None
    for p in sorted(input_dir.glob("*.parquet")):
        df = pd.read_parquet(p)
        if method == "physics":
            feats = extract_features_physics(df, prominence=prominence, distance=distance, topk=topk)
        elif method == "tfug":
            emb = TFUGFWTEmbedder(TFUGFWTConfig(downsample=downsample)).transform(df)
            if emb_dim is None:
                emb_dim = len(emb)
            feats = {f"emb_{i}": float(v) for i, v in enumerate(emb)}
        else:
            raise ValueError("Unknown method")
        feats["file"] = p.name
        rows.append(feats)
    out_df = pd.DataFrame(rows)
    if output_path.suffix.lower() == ".csv":
        out_df.to_csv(output_path, index=False)
    else:
        out_df.to_parquet(output_path, index=False)
    return out_df

@main.command("features")
@click.option("--input", "input_dir", type=click.Path(path_type=Path), required=True, help="Dossier contenant des .parquet (wavenumber_cm1,intensity,...)")
@click.option("--output", "output_path", type=click.Path(path_type=Path), required=True, help="Fichier de sortie (.parquet ou .csv)")
@click.option("--method", type=click.Choice(["physics","tfug"], case_sensitive=False), default="physics")
@click.option("--prominence", type=float, default=0.01, help="Prominence minimale (physics)")
@click.option("--distance", type=int, default=5, help="Distance minimale entre pics (physics)")
@click.option("--topk", type=int, default=5, help="Nombre max de pics à reporter (physics)")
@click.option("--downsample", type=int, default=64, help="Taille cible de l'embedding (tfug)")
def features_cmd(input_dir: Path, output_path: Path, method: str, prominence: float, distance: int, topk: int, downsample: int):
    """Extraire des features d'un dossier de .parquet (méthodes: physics|tfug)."""
    try:
        df = run_features_dir(input_dir, output_path, method.lower(), prominence, distance, topk, downsample)
        click.echo(f"[OK] Features écrites -> {output_path} ({len(df)} lignes)")
    except Exception as e:
        raise click.ClickException(str(e))

if __name__ == "__main__":
    main()


from .pipelines.preprocess import preprocess_df, load_params_yaml, PreprocessParams

@main.command("preprocess")
@click.option("--input", "input_dir", type=click.Path(path_type=Path), required=True, help="Dossier avec .parquet bruts/convertis")
@click.option("--output", "output_dir", type=click.Path(path_type=Path), required=True, help="Dossier de sortie pour .parquet prétraités")
@click.option("--params", "params_path", type=click.Path(path_type=Path), required=False, help="Fichier YAML (params.yaml)")
def preprocess_cmd(input_dir: Path, output_dir: Path, params_path: Path | None):
    """Applique Savitzky–Golay + ALS + normalisation d'aire, selon params.yaml."""
    p = load_params_yaml(params_path) if params_path else PreprocessParams()
    output_dir.mkdir(parents=True, exist_ok=True)
    n_in, n_ok = 0, 0
    for q in sorted(input_dir.glob("*.parquet")):
        n_in += 1
        df = pd.read_parquet(q)
        out = preprocess_df(df, p)
        out_path = output_dir / q.name
        out.to_parquet(out_path, index=False)
        n_ok += 1
    click.echo(f"[OK] Prétraitement terminé: {n_ok}/{n_in} fichiers -> {output_dir}")


from .plotting.plot_spectra import plot_folder

@main.command("plot")
@click.option("--input", "input_dir", type=click.Path(path_type=Path), required=True, help="Dossier .parquet")
@click.option("--output", "output_dir", type=click.Path(path_type=Path), required=True, help="Dossier .png")
@click.option("--prominence", type=float, default=0.02, help="Prominence min pour détection de pics")
@click.option("--distance", type=int, default=5, help="Distance min entre pics")
@click.option("--dpi", type=int, default=120, help="DPI des figures")
def plot_cmd(input_dir: Path, output_dir: Path, prominence: float, distance: int, dpi: int):
    """Export PNG avec marquage des pics pour tous les .parquet du dossier."""
    paths = plot_folder(input_dir, output_dir, prominence=prominence, distance=distance, dpi=dpi)
    click.echo(f"[OK] {len(paths)} figures -> {output_dir}")


from datetime import datetime
import uuid as _uuid
from .plotting.plot_spectra import plot_folder
from .cli import run_features_dir  # self-import ok after module load
from ..pipeline import report_gen as _report


@main.command("report")
@click.option("--params", "params_path", type=click.Path(path_type=Path), required=False,
              help="Chemin params.yaml (par défaut: pipeline/params.yaml)")
def report_cmd(params_path: Path | None):
    """
    End-to-end: preprocess (if needed) -> features -> plot -> LaTeX tables/gallery.
    Lit les chemins/hyperparamètres depuis pipeline/params.yaml par défaut.
    """
    # Load unified params
    pfile = params_path or Path("pipeline")/ "params.yaml"
    p = yaml.safe_load(Path(pfile).read_text(encoding="utf-8"))
    pp = p.get("preprocess", {})
    ff = p.get("features", {})
    rr = p.get("report", {})

    in_proc = Path(pp.get("input_dir","data/processed"))
    out_clean = Path(pp.get("output_dir","data/clean"))
    out_clean.mkdir(parents=True, exist_ok=True)

    # Preprocess all *.parquet in input_dir to output_dir
    n_in, n_ok = 0, 0
    for q in sorted(in_proc.glob("*.parquet")):
        n_in += 1
        df = pd.read_parquet(q)
        validate_schema(df)
        params = PreprocessParams(
            savgol_window=int(pp.get("savgol_window",21)),
            savgol_poly=int(pp.get("savgol_poly",3)),
            als_lambda=float(pp.get("als_lambda",1.0e5)),
            als_p=float(pp.get("als_p",0.01)),
            area_norm=bool(pp.get("area_norm",True)),
        )
        out_df = preprocess_df(df, params)
        out_df.to_parquet(out_clean / q.name, index=False)
        n_ok += 1
    click.echo(f"[preprocess] {n_ok}/{n_in} fichiers -> {out_clean}")

    # Features
    inp_feats = Path(ff.get("input_dir","data/clean"))
    feat_out = Path(ff.get("output_path","data/features/features.parquet"))
    feat_out.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    method = (ff.get("method","physics")).lower()
    for pth in sorted(inp_feats.glob("*.parquet")):
        df = pd.read_parquet(pth)
        if method == "physics":
            row = extract_features_physics(
                df,
                prominence=float(ff.get("prominence",0.02)),
                distance=int(ff.get("distance",5)),
                topk=int(ff.get("topk",5)),
            )
        else:
            emb = TFUGFWTEmbedder(TFUGFWTConfig(downsample=int(ff.get("downsample",64)))).transform(df)
            row = {"file": pth.name, **{f"emb_{i}": float(v) for i, v in enumerate(emb)}}
        row["file"] = pth.name
        rows.append(row)
    pd.DataFrame(rows).to_parquet(feat_out, index=False)
    click.echo(f"[features] -> {feat_out}")

    # Figures
    fig_dir = Path(rr.get("fig_dir","figures"))
    fig_dir.mkdir(parents=True, exist_ok=True)
    plot_folder(inp_feats, fig_dir,
                prominence=float(ff.get("prominence",0.02)),
                distance=int(ff.get("distance",5)),
                dpi=120)
    click.echo(f"[plot] -> {fig_dir}")

    # LaTeX tables
    latex_dir = Path(rr.get("latex_dir","latex"))
    latex_dir.mkdir(parents=True, exist_ok=True)
    runs_dir = Path(rr.get("runs_dir","runs"))
    runs_dir.mkdir(parents=True, exist_ok=True)

    # minimal metrics
    import uuid, datetime as _dt
    rid = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")+"_"+uuid.uuid4().hex[:6]
    metrics = {"run_id": rid, "ts": _dt.datetime.now().isoformat(),
               "n_files": int(len(list(inp_feats.glob('*.parquet')))), "method": method}
    (runs_dir / f"{rid}_metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")

    _report.main(runs_dir=str(runs_dir), out_tex=str(latex_dir/"metrics_table.tex"))
    _report.make_gallery(images_dir=str(fig_dir), out_tex=str(latex_dir/"fig_gallery.tex"))
    click.echo(f"[latex] metrics_table.tex & fig_gallery.tex -> {latex_dir}")

    click.echo("[OK] Rapport complet prêt.")
