from __future__ import annotations
import pandas as pd

REQUIRED_COLS = {
    "wavenumber_cm1": "float",
    "intensity": "float",
}
OPTIONAL_COLS = {"sample_id": "string"}

def validate_schema(df: pd.DataFrame) -> None:
    for col, typ in REQUIRED_COLS.items():
        if col not in df.columns:
            raise ValueError(f"Missing required column: {col}")
        # type check (permissive to float64/float32)
        if typ == "float" and not pd.api.types.is_numeric_dtype(df[col]):
            raise TypeError(f"Column {col} must be numeric")
    # Optional cols are coerced if present
    if "sample_id" in df.columns:
        df["sample_id"] = df["sample_id"].astype("string")
