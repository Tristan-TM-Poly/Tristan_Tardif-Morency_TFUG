# TFUG V2 — ICWT(d) Package

Contents:
- `sympy_proofs/icwt_dimension_d.py`: derives formula C_psi(d) and outputs JSON.
- `tests/test_icwt_dimension_d.py`: runs generator and validates positivity + non-increase over d.
- `overleaf/appendix/proofs_icwt_dimension_d.tex`: LaTeX appendix with full derivation.
- `overleaf/figures/Cpsi_vs_d.png`: plot of C(d) for sigma=1.
- `overleaf/main.tex`: Overleaf-ready main file.

How to use:
1. `PYTHONPATH=. pytest -q`   # run tests
2. `cd overleaf && pdflatex main.tex && pdflatex main.tex`  # build PDF
