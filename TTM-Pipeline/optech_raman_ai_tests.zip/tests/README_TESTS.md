# Optech Raman AI — Tests

## Prérequis
```
pip install -r requirements-dev.txt
```
(ou au minimum `pytest`)

## Lancer les tests
Depuis la racine du projet:
```
pytest -q
```

- `tests/test_imports.py` : vérifie les imports de tous les modules Python.
- `tests/test_signatures.py` : valide l'introspection `inspect` sans exécuter de code applicatif.
- `tests/conftest.py` : fournit des fixtures réutilisables (spectre synthétique, métadonnées, mode test).
- `tests/data/synthetic_raman.csv` : petit dataset synthétique stable pour tests.

## Marqueurs Pytest
- `@pytest.mark.slow`  : désigne un test lent (charge modèles, gros fichiers).
- `@pytest.mark.io`    : test qui touche au système de fichiers ou ressources externes.
- `@pytest.mark.model` : test nécessitant des frameworks lourds ou des poids.
