import os
import numpy as np
import pandas as pd
import pytest

@pytest.fixture(scope="session")
def test_mode(monkeypatch):
    """Enable lightweight test mode for code that supports it."""
    monkeypatch.setenv("OPTECH_TEST_MODE", "1")
    return True

@pytest.fixture(scope="session")
def example_spectrum():
    """Small synthetic Raman-like spectrum (wavenumber, intensity)."""
    rng = np.random.default_rng(42)
    wn = np.linspace(200, 2000, 400)  # cm^-1
    # three Gaussian peaks
    def g(x, mu, sigma, amp): return amp * np.exp(-(x-mu)**2/(2*sigma**2))
    signal = (g(wn, 520, 6, 1.0) + g(wn, 1000, 12, 0.6) + g(wn, 1580, 8, 0.8))
    noise = 0.03 * rng.standard_normal(wn.size)
    intensity = signal + noise
    return pd.DataFrame({"wavenumber_cm_1": wn, "intensity": intensity})

@pytest.fixture(scope="session")
def example_metadata():
    return {
        "sample_id": "SYNTH-001",
        "laser_nm": 532,
        "integration_ms": 100.0,
        "operator": "pytest",
        "timestamp": "1970-01-01T00:00:00Z"
    }
