# Auto-generated signature presence tests (no execution)
import importlib, inspect, types, pytest

MODULES = ['optech-raman-ai.src.raman_ai', 'optech-raman-ai.src.raman_ai.cli', 'optech-raman-ai.src.raman_ai.eval.calibration', 'optech-raman-ai.src.raman_ai.eval.evaluate', 'optech-raman-ai.src.raman_ai.features.df_estim', 'optech-raman-ai.src.raman_ai.features.fwt', 'optech-raman-ai.src.raman_ai.features.peaks', 'optech-raman-ai.src.raman_ai.features.pipeline', 'optech-raman-ai.src.raman_ai.features.ratios', 'optech-raman-ai.src.raman_ai.features.tfuq', 'optech-raman-ai.src.raman_ai.io.parquet', 'optech-raman-ai.src.raman_ai.io.schema', 'optech-raman-ai.src.raman_ai.io.standards', 'optech-raman-ai.src.raman_ai.models.heads.bayes_multi', 'optech-raman-ai.src.raman_ai.models.heads.dielectric', 'optech-raman-ai.src.raman_ai.models.heads.magnetic', 'optech-raman-ai.src.raman_ai.models.heads.superconductor', 'optech-raman-ai.src.raman_ai.models.train', 'optech-raman-ai.src.raman_ai.preprocess.align', 'optech-raman-ai.src.raman_ai.preprocess.baseline', 'optech-raman-ai.src.raman_ai.preprocess.norm', 'optech-raman-ai.src.raman_ai.preprocess.pipeline', 'optech-raman-ai.src.raman_ai.preprocess.smooth', 'optech-raman-ai.src.raman_ai.preprocess.spikes', 'optech-raman-ai.src.raman_ai.report.calib_table', 'optech-raman-ai.src.raman_ai.report.gen_latex', 'optech-raman-ai.src.raman_ai.report.plots']

@pytest.mark.parametrize("modname", MODULES)
def test_signatures_listed(modname):
    m = importlib.import_module(modname)
    public = [(n, o) for n, o in inspect.getmembers(m) if not n.startswith("_")]
    # At least module imports and introspection runs without exceptions
    assert isinstance(public, list)
