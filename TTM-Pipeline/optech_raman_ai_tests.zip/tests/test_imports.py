# Auto-generated import tests
import importlib, os

FAILED = []
MODULES = ['optech-raman-ai.src.raman_ai', 'optech-raman-ai.src.raman_ai.cli', 'optech-raman-ai.src.raman_ai.eval.calibration', 'optech-raman-ai.src.raman_ai.eval.evaluate', 'optech-raman-ai.src.raman_ai.features.df_estim', 'optech-raman-ai.src.raman_ai.features.fwt', 'optech-raman-ai.src.raman_ai.features.peaks', 'optech-raman-ai.src.raman_ai.features.pipeline', 'optech-raman-ai.src.raman_ai.features.ratios', 'optech-raman-ai.src.raman_ai.features.tfuq', 'optech-raman-ai.src.raman_ai.io.parquet', 'optech-raman-ai.src.raman_ai.io.schema', 'optech-raman-ai.src.raman_ai.io.standards', 'optech-raman-ai.src.raman_ai.models.heads.bayes_multi', 'optech-raman-ai.src.raman_ai.models.heads.dielectric', 'optech-raman-ai.src.raman_ai.models.heads.magnetic', 'optech-raman-ai.src.raman_ai.models.heads.superconductor', 'optech-raman-ai.src.raman_ai.models.train', 'optech-raman-ai.src.raman_ai.preprocess.align', 'optech-raman-ai.src.raman_ai.preprocess.baseline', 'optech-raman-ai.src.raman_ai.preprocess.norm', 'optech-raman-ai.src.raman_ai.preprocess.pipeline', 'optech-raman-ai.src.raman_ai.preprocess.smooth', 'optech-raman-ai.src.raman_ai.preprocess.spikes', 'optech-raman-ai.src.raman_ai.report.calib_table', 'optech-raman-ai.src.raman_ai.report.gen_latex', 'optech-raman-ai.src.raman_ai.report.plots']
def test_import_all():
    for mod in MODULES:
        try:
            importlib.import_module(mod)
        except Exception as e:
            FAILED.append((mod, type(e).__name__, str(e)))
    if FAILED:
        # Provide a compact failure summary
        msgs = ["%s -> %s: %s" % x for x in FAILED[:20]]
        raise AssertionError("Import failures (showing up to 20):\n" + "\n".join(msgs))
