# TTM Optech Raman AI — Skeleton

Objectif: dépôt standardisé, reproductible, prêt pour CI/CD, avec pipeline données (CSV→Parquet), scripts utilitaires, LaTeX Overleaf-ready, et base de tests.

## Installation rapide

### Option Conda
```bash
conda env create -f environment.yml
conda activate ttm-optech
```

### Option pip (isolée)
```bash
python -m venv .venv && source .venv/bin/activate  # (Windows: .venv\Scripts\activate)
pip install -U pip
pip install -e .
pre-commit install
```

## Données
```
data/
  raw/       # brutes (spectres, dark, étalons)
  interim/   # calibrées / partiellement transformées
  processed/ # finales (Parquet/CSV)
```

## Utilisation CLI
```bash
optech-raman-ai convert-csv --input data/raw --output data/processed
optech-raman-ai dedup --input some/folder --hash sha1
```

## Tests
```bash
pytest -q
```

## LaTeX
`latex/main.tex` + `latex/references.bib` — prêt pour compilation locale (latexmk) ou Overleaf.

## DVC (optionnel)
- `dvc.yaml` + `params.yaml` fournis pour tracer datasets/artefacts.
