
import click
from pathlib import Path
from .data.convert_csv_to_parquet import convert_folder as convert_csv_folder
from .utils.deduplicate import deduplicate_folder

@click.group()
def main():
    """Optech Raman AI — CLI."""

@main.command("convert-csv")
@click.option("--input", "input_dir", type=click.Path(path_type=Path), required=True)
@click.option("--output", "output_dir", type=click.Path(path_type=Path), required=True)
def convert_csv(input_dir: Path, output_dir: Path):
    """Convertir tous les CSV d'un dossier en Parquet (schéma auto)."""
    convert_csv_folder(input_dir, output_dir)

@main.command("dedup")
@click.option("--input", "folder", type=click.Path(path_type=Path), required=True)
@click.option("--hash", "algo", type=click.Choice(["sha1","md5"]), default="sha1")
def dedup(folder: Path, algo: str):
    """Dédupliquer des fichiers par hash (SHA1 par défaut)."""
    deduplicate_folder(folder, algo=algo)
