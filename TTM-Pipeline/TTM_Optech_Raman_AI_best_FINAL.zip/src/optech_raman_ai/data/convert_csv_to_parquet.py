
from pathlib import Path
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

def convert_folder(input_dir: Path, output_dir: Path) -> None:
    input_dir = Path(input_dir)
    output_dir = Path(output_dir); output_dir.mkdir(parents=True, exist_ok=True)
    for csv in input_dir.rglob("*.csv"):
        df = pd.read_csv(csv)
        table = pa.Table.from_pandas(df, preserve_index=False)
        out = output_dir / (csv.stem + ".parquet")
        pq.write_table(table, out, compression="snappy")
        print(f"[OK] {csv} -> {out}")
