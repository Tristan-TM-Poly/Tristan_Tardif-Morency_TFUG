
from pathlib import Path
import hashlib
import shutil

def _hash_file(path: Path, algo: str = "sha1") -> str:
    h = hashlib.new(algo)
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def deduplicate_folder(folder: Path, algo: str = "sha1") -> None:
    folder = Path(folder)
    seen = {}
    removed = 0
    for file in folder.rglob("*"):
        if not file.is_file():
            continue
        digest = _hash_file(file, algo=algo)
        if digest in seen:
            # Remove duplicate file
            file.unlink()
            removed += 1
        else:
            seen[digest] = file
    print(f"[DEDUP] Removed {removed} duplicates. Unique files: {len(seen)}")
