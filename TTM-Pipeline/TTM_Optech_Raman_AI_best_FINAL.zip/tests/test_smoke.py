
def test_smoke_import():
    import optech_raman_ai
    assert hasattr(optech_raman_ai, "__version__")
