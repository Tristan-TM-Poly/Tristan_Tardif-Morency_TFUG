
from __future__ import annotations
import numpy as np

def snr0(intensity: np.ndarray) -> float:
    y = np.asarray(intensity, float)
    s = y.std()
    mu = y.mean()
    return float(mu / (s + 1e-12))

def saturation_pct(y: np.ndarray, sat_level: float = 0.99) -> float:
    y = np.asarray(y, float)
    ymax = y.max()
    if ymax <= 0: return 0.0
    return float((y > sat_level * ymax).mean())

def rmse(y_true, y_pred) -> float:
    y_true = np.asarray(y_true, float); y_pred = np.asarray(y_pred, float)
    return float(np.sqrt(((y_true - y_pred) ** 2).mean()))
