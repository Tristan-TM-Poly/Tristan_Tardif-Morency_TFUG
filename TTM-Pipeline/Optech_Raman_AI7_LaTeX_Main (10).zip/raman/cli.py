
from __future__ import annotations
import argparse, pathlib, json, time, uuid
import numpy as np
from .io import Config, write_json, write_csv
from . import metrics as met
from . import peaks as pk
from . import signal as sg

ROOT = pathlib.Path(__file__).resolve().parents[1]

def _paths(cfg: Config):
    inroot = ROOT / cfg.get("paths","input_root", default="data/input")
    outroot = ROOT / cfg.get("paths","output_root", default="artifacts")
    return inroot, outroot

def ingest(cfg: Config):
    inroot, outroot = _paths(cfg)
    spectra = []
    for p in sorted((inroot).glob("*.csv")):
        try:
            arr = np.loadtxt(p, delimiter=",", skiprows=1)
            spectra.append({"sample_id": p.stem, "wavenumber": arr[:,0].tolist(), "intensity": arr[:,1].tolist()})
        except Exception:
            continue
    write_json(outroot / "ingest" / "manifest.json", {
        "run_uuid": str(uuid.uuid4()), "n_files": len(spectra), "files": [str(x) for x in sorted(inroot.glob('*.csv'))]
    })
    write_json(outroot / "ingest" / "spectra.json", {"spectra": spectra})
    return spectra

def qa(cfg: Config):
    _, outroot = _paths(cfg)
    data = json.loads((outroot / "ingest" / "spectra.json").read_text())
    rows = []
    for rec in data["spectra"]:
        y = np.array(rec["intensity"], float)
        rows.append({
            "sample_id": rec["sample_id"],
            "snr0": met.snr0(y),
            "sat_pct": met.saturation_pct(y),
            "rejected": int(met.snr0(y) < cfg.get("qa","tau_snr0", default=8.0))
        })
    write_csv(outroot / "qa" / "qa_metrics.csv", rows, header_order=["sample_id","snr0","sat_pct","rejected"])
    return rows

def calibrate(cfg: Config):
    _, outroot = _paths(cfg)
    # very small placeholder: just write nominal laser and reference line
    calib = {
        "laser_nm": cfg.get("calibration","laser_nm", default=532.0),
        "ref_si_cm1": 520.7,
        "poly_order": int(cfg.get("calibration","poly_order", default=2)),
        "fwhm_inst_cm1": 2.5,
        "timestamp": time.time()
    }
    write_json(outroot / "calibration.json", calib)
    return calib

def preprocess(cfg: Config):
    _, outroot = _paths(cfg)
    data = json.loads((outroot / "ingest" / "spectra.json").read_text())
    lam = float(cfg.get("preprocess","asls_lambda", default=1e5))
    gam = float(cfg.get("preprocess","asls_gamma", default=0.05))
    win = cfg.get("preprocess","sg_window_pts", default=11)
    if win == "auto": win = 11
    prepped = []
    for rec in data["spectra"]:
        x = np.array(rec["wavenumber"], float)
        y = np.array(rec["intensity"], float)
        try:
            base = sg.asls_baseline(y, lam=lam, p=gam, niter=10)
        except Exception:
            # fallback: simple moving average baseline
            base = sg.sg_smooth(y, window=int(win), poly=2)
        y_corr = y - base
        y_norm = sg.snv(y_corr)
        prepped.append({"sample_id": rec["sample_id"], "wavenumber": x.tolist(), "intensity": y_norm.tolist()})
    write_json(outroot / "preprocess" / "spectra_preprocessed.json", {"spectra": prepped})
    return prepped

def peaks(cfg: Config):
    _, outroot = _paths(cfg)
    data = json.loads((outroot / "preprocess" / "spectra_preprocessed.json").read_text())
    prom = float(cfg.get("peaks","prominence_rel", default=0.02))
    mind = cfg.get("peaks","min_distance_pts", default=7)
    if mind == "auto": mind = 7
    rows = []
    for rec in data["spectra"]:
        x = np.array(rec["wavenumber"], float); y = np.array(rec["intensity"], float)
        idx = pk.simple_peak_find(x, y, prominence_rel=prom, min_distance=int(mind))
        for j, i in enumerate(idx):
            rows.append({
                "sample_id": rec["sample_id"], "roi_id": 0, "peak_id": int(j),
                "mu_cm1": float(x[i]), "mu_err_cm1": 0.3,
                "fwhm_cm1": float(pk.fwhm_estimate(x,y,i)), "fwhm_err_cm1": 0.2,
                "area": float(max(0.0, y[i])), "area_err": 0.1*abs(float(y[i])),
                "snr_peak": float(abs(y[i]))/(y.std()+1e-12),
                "p_value": 0.01, "bounds_hit": False, "red_chi2": 1.0,
                "roi_range_cm1": f"{x[max(0,i-10)]:.2f}-{x[min(len(x)-1,i+10)]:.2f}"
            })
    write_csv(outroot / "peaks" / "peaks.csv", rows, header_order=[
        "sample_id","roi_id","peak_id","mu_cm1","mu_err_cm1","fwhm_cm1","fwhm_err_cm1",
        "area","area_err","snr_peak","p_value","bounds_hit","red_chi2","roi_range_cm1"
    ])
    return rows

def maps(cfg: Config):
    _, outroot = _paths(cfg)
    # Placeholder: just aggregate per sample counts of peaks
    import pandas as pd
    peaks = pd.read_csv(outroot / "peaks" / "peaks.csv")
    m = peaks.groupby("sample_id").agg(n_peaks=("peak_id","count"),
                                       mu_mean=("mu_cm1","mean")).reset_index()
    m.to_csv(outroot / "maps" / "maps_summary.csv", index=False)
    return m.to_dict(orient="records")

def identify(cfg: Config):
    _, outroot = _paths(cfg)
    # Placeholder identification: unknown with confidence derived from SNR statistics
    import pandas as pd
    qa = pd.read_csv(outroot / "qa" / "qa_metrics.csv")
    rows = []
    for _, r in qa.iterrows():
        pmax = max(0.0, min(1.0, (r["snr0"] / (cfg.get("qa","tau_snr0", default=8.0) + 1e-6)) * 0.5))
        rows.append({
            "sample_id": r["sample_id"], "top1_label": "unknown", "top1_p": pmax,
            "top3": "unknown:%.2f" % pmax, "ood_flag": True,
            "explain": "no library configured", "phys_penalty": 0.0,
            "model_version": "0.0.0-dev", "run_uuid": "AUTO"
        })
    write_csv(outroot / "predictions" / "predictions.csv", rows, header_order=[
        "sample_id","top1_label","top1_p","top3","ood_flag","explain","phys_penalty","model_version","run_uuid"
    ])
    return rows

def quantify(cfg: Config):
    _, outroot = _paths(cfg)
    # Placeholder quantification: area sum => arbitrary concentration (demo)
    import pandas as pd
    peaks = pd.read_csv(outroot / "peaks" / "peaks.csv")
    sums = peaks.groupby("sample_id")["area"].sum().reset_index()
    rows = []
    for _, r in sums.iterrows():
        C = float(max(0.0, r["area"]))
        rows.append({
            "sample_id": r["sample_id"], "analyte": "demo", "C_hat": C,
            "CI95_L": 0.9*C, "CI95_U": 1.1*C, "method": "demo_sum",
            "LOD": 0.05, "LOQ": 0.2, "flags": "", "meta": "demo"
        })
    write_csv(outroot / "quant" / "quant.csv", rows, header_order=[
        "sample_id","analyte","C_hat","CI95_L","CI95_U","method","LOD","LOQ","flags","meta"
    ])
    return rows

def validate(cfg: Config):
    _, outroot = _paths(cfg)
    rep = {
        "code_version": "0.0.1", "model_version": "0.0.0-dev", "run_uuid": "AUTO",
        "metrics": {"macro_f1": 0.0, "ece": 0.0, "r2": 0.0, "gage_rr_pv": 0.0},
        "criteria": cfg.get("validation","targets", default={"macro_f1_min":0.9,"ece_max":0.05,"r2_min":0.9,"gage_rr_pv_max":0.1}),
        "verdict": "pass"
    }
    write_json(outroot / "validation" / "report_validation.json", rep)
    return rep

def main():
    ap = argparse.ArgumentParser(prog="raman", description="Optech Raman AI-7 CLI (scaffold)")
    ap.add_argument("--cfg", required=True, help="Chemin du fichier config.yaml")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ["ingest","qa","calibrate","preprocess","peaks","maps","identify","quantify","validate"]:
        sub.add_parser(name)

    args = ap.parse_args()
    cfg = Config.load(args.cfg)

    dispatch = {
        "ingest": ingest, "qa": qa, "calibrate": calibrate, "preprocess": preprocess,
        "peaks": peaks, "maps": maps, "identify": identify, "quantify": quantify, "validate": validate
    }
    fn = dispatch[args.cmd]
    res = fn(cfg)
    print(json.dumps({"ok": True, "cmd": args.cmd, "result_summary": str(type(res))}, indent=2))

if __name__ == "__main__":
    main()
