
from __future__ import annotations
import yaml, json, pathlib, csv
from dataclasses import dataclass
from typing import Dict, Any, List

@dataclass
class Config:
    data: Dict[str, Any]

    @classmethod
    def load(cls, path: str | pathlib.Path) -> "Config":
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        return cls(data=data)

    def get(self, *keys, default=None):
        cur = self.data
        for k in keys:
            if cur is None: return default
            cur = cur.get(k)
        return cur if cur is not None else default

def write_json(path: str | pathlib.Path, obj: Any):
    p = pathlib.Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)

def write_csv(path: str | pathlib.Path, rows: List[Dict[str, Any]], header_order: List[str] | None = None):
    p = pathlib.Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        rows = []
    if header_order is None:
        # union of keys
        keys = set()
        for r in rows: keys |= set(r.keys())
        fieldnames = sorted(keys)
    else:
        fieldnames = header_order
    with open(p, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows: w.writerow(r)

def read_csv_simple(path: str | pathlib.Path):
    import pandas as pd
    return pd.read_csv(path)
