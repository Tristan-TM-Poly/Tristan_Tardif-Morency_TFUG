
from __future__ import annotations
import numpy as np

def simple_peak_find(x: np.ndarray, y: np.ndarray, prominence_rel: float = 0.02, min_distance: int = 5):
    # very small peak picker: local maxima over threshold and separated
    y = np.asarray(y, float); x = np.asarray(x, float)
    thr = y.min() + prominence_rel * (y.max() - y.min())
    cand = (y[1:-1] > y[:-2]) & (y[1:-1] > y[2:]) & (y[1:-1] > thr)
    idx = np.where(cand)[0] + 1
    if idx.size == 0: return np.array([], dtype=int)
    # enforce min distance
    selected = [int(idx[0])]
    for i in idx[1:]:
        if (i - selected[-1]) >= min_distance:
            selected.append(int(i))
        elif y[i] > y[selected[-1]]:
            selected[-1] = int(i)
    return np.array(selected, dtype=int)

def fwhm_estimate(x: np.ndarray, y: np.ndarray, i_max: int) -> float:
    # crude FWHM around index i_max
    half = y[i_max] / 2.0
    L = i_max
    while L > 0 and y[L] > half: L -= 1
    R = i_max
    while R < len(y) - 1 and y[R] > half: R += 1
    return abs(x[R] - x[L]) if R > L else np.nan
