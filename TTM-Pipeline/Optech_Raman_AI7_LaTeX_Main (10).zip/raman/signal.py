
from __future__ import annotations
import numpy as np

def snv(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, float)
    return (x - x.mean()) / (x.std() + 1e-12)

def sg_smooth(y: np.ndarray, window: int = 11, poly: int = 2) -> np.ndarray:
    # Minimal Savitzky–Golay using numpy (no scipy)
    # Build Vandermonde and convolution weights
    if window % 2 == 0: window += 1
    half = window // 2
    X = np.arange(-half, half + 1, dtype=float)[:, None] ** np.arange(0, poly + 1, dtype=float)[None, :]
    beta = np.linalg.pinv(X).T[0]  # smoothing (zeroth derivative)
    # pad reflect
    ypad = np.r_[y[1:half+1][::-1], y, y[-half-1:-1][::-1]]
    conv = np.convolve(ypad, beta[::-1], mode="valid")
    return conv

def asls_baseline(y: np.ndarray, lam: float = 1e5, p: float = 0.01, niter: int = 10) -> np.ndarray:
    # Asymmetric least squares baseline (Eilers 2005)
    import scipy.sparse as sp
    import numpy as np
    L = len(y)
    D = sp.diags([1, -2, 1], [0, 1, 2], shape=(L-2, L))
    w = np.ones(L)
    for _ in range(niter):
        W = sp.spdiags(w, 0, L, L)
        Z = W + lam * D.T @ D
        z = sp.linalg.spsolve(Z, w * y)
        w = p * (y > z) + (1 - p) * (y < z)
    return z
