# Optech Raman AI–7 — Documentation LaTeX
Compilez `main.tex` avec LaTeX (pdflatex/xelatex) après avoir ajouté d'éventuelles figures.
Sections incluses : 0 (Config), 1 (Ingestion), 2 (Schéma), 3 (QA), 4 (Calibration), 5 (Prétraitements), 6 (Pics), 7 (Cartographie).
Sorties attendues et artefacts sont décrits dans chaque section.
