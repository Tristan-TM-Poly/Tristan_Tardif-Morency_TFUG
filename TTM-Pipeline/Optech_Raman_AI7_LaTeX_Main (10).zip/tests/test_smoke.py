
import pathlib, json, subprocess, sys

ROOT = pathlib.Path(__file__).resolve().parents[1]

def run(cmd):
    return subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, check=True)

def test_cli_ingest_to_validate():
    cfg = ROOT / "config" / "config.yaml"
    run([sys.executable, "-m", "raman.cli", "ingest", "--cfg", str(cfg)])
    run([sys.executable, "-m", "raman.cli", "qa", "--cfg", str(cfg)])
    run([sys.executable, "-m", "raman.cli", "calibrate", "--cfg", str(cfg)])
    run([sys.executable, "-m", "raman.cli", "preprocess", "--cfg", str(cfg)])
    run([sys.executable, "-m", "raman.cli", "peaks", "--cfg", str(cfg)])
    run([sys.executable, "-m", "raman.cli", "maps", "--cfg", str(cfg)])
    run([sys.executable, "-m", "raman.cli", "identify", "--cfg", str(cfg)])
    run([sys.executable, "-m", "raman.cli", "quantify", "--cfg", str(cfg)])
    run([sys.executable, "-m", "raman.cli", "validate", "--cfg", str(cfg)])
