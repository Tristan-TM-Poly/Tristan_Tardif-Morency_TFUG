# Optech Raman AI-7 — Runtime

## 1) Environnement
- Conda: `conda env create -f environment.yml && conda activate optech-raman-ai7`
- Docker: `docker build -t optech-raman-ai7:cpu .`

## 2) Configuration
- Éditez `config/config.yaml` pour le profil (site/instrument).

## 3) Exécution pipeline
- `make all` (ingest→qa→calibrate→preprocess→peaks→maps→identify→quantify→validate→pdf)
- Artefacts dans `artifacts/` (CSV/JSON/PNG).

## 4) Interfaces
- PDF: compilez `main.tex` (ou laissez la CI publier).
- Notebooks: ouvrez `notebooks/QA_Review.ipynb`, `ID_Inspection.ipynb`, `Quant_Audit.ipynb` (lecture des artefacts).
- Dashboard: `artifacts/qc_dashboard/index.html` (statique).

## 5) Traçabilité
- Tous les JSON contiennent `run_uuid`, `code_version`, `model_version`.


## 6) Exécuter la CLI (scaffold)
```bash
python -m raman.cli ingest --cfg config/config.yaml
python -m raman.cli qa --cfg config/config.yaml
python -m raman.cli calibrate --cfg config/config.yaml
python -m raman.cli preprocess --cfg config/config.yaml
python -m raman.cli peaks --cfg config/config.yaml
python -m raman.cli maps --cfg config/config.yaml
python -m raman.cli identify --cfg config/config.yaml
python -m raman.cli quantify --cfg config/config.yaml
python -m raman.cli validate --cfg config/config.yaml
```
Les artefacts seront écrits dans `artifacts/` selon la structure documentée.
