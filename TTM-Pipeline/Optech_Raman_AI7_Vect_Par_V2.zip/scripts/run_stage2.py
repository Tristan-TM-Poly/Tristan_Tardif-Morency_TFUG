
import argparse
from stage2_ai7.config import ConfigStage2
from stage2_ai7.runner import run_stage2

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="artifacts/stage1")
    ap.add_argument("--out", default="artifacts/stage2")
    ap.add_argument("--active_k", type=int, default=5)
    ap.add_argument("--alpha", type=float, default=1.0)
    ap.add_argument("--beta", type=float, default=100.0)
    args = ap.parse_args()

    cfg = ConfigStage2(input_path=args.input, out_dir=args.out, active_k=args.active_k, alpha=args.alpha, beta=args.beta)
    info = run_stage2(cfg)
    print(f"[stage2] samples={info['n']} features={info['features']} ood_thr={info['ood_thr']:.3f}")

if __name__ == "__main__":
    main()
