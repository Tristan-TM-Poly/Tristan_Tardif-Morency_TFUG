
import numpy as np

def mahalanobis_params(X: np.ndarray):
    mu = X.mean(axis=0, keepdims=True)
    cov = np.cov(X.T) + 1e-6*np.eye(X.shape[1])
    cov_inv = np.linalg.inv(cov)
    return mu, cov_inv

def mahalanobis_dist(X: np.ndarray, mu, cov_inv):
    D = X - mu
    return np.sqrt(np.sum(D @ cov_inv * D, axis=1))

def threshold_from_dist(d: np.ndarray, q: float = 0.95):
    return float(np.quantile(d, q))

def acquisition_variance(pred_var: np.ndarray, k: int = 5):
    idx = np.argsort(-pred_var)[:k]
    return idx
