
import numpy as np
import pandas as pd
from optech_raman_ai7.bayes_multi import fit_blr_multi, predict_blr_multi
from optech_raman_ai7.preprocessing import moving_average

def test_blr_multi_shapes():
    X = np.random.randn(40, 10)
    Y = np.random.randn(40, 2)
    post = fit_blr_multi(X, Y, alpha=1.0, beta=100.0)
    m, v = predict_blr_multi(post, X[:5])
    assert m.shape == (5, 2)
    assert v.shape == (5,)

def test_ma_filter():
    x = np.arange(10.0)
    y = moving_average(x, 3)
    assert len(y) == 10
