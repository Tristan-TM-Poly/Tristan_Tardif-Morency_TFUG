
# Optech Raman AI‑7 — V2.0 (TFUG/Bayesian/IEEE)

**Scope V2** — This release implements the next five priorities:
1) Standards library (Si, polymers, metals) for automatic calibration.  
2) TFUG/FWT quaternionic feature block (multi‑scale + polarization).  
3) Bayesian multi‑output regression (e.g., dopant, temperature).  
4) Parquet (optional) + DVC scaffolding + full CLI.  
5) Auto IEEE report (LaTeX + BibTeX + TikZ).

## Quick start
```bash
python -m optech_raman_ai7.cli run --config config/config.json
# Or generate IEEE report
python -m optech_raman_ai7.cli report --config config/config.json
```

Results land in `artifacts/` and `report/`.

## Notes
- Parquet writing is **optional** (falls back to CSV when `pyarrow/fastparquet` is missing).
- DVC files are scaffolded (you still run `dvc init`, `dvc add`, `dvc push` locally).
- CLI uses `argparse` (no external deps).
- TikZ/BibTeX templates are emitted; compile in Overleaf/LaTeX environment.
