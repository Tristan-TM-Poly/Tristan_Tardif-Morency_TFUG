
import argparse, json, sys
from .config import RamanConfig
from .run import run_pipeline

def main():
    ap = argparse.ArgumentParser(prog="optech_raman_ai7")
    sub = ap.add_subparsers(dest="cmd")

    p_run = sub.add_parser("run", help="Run end-to-end pipeline")
    p_run.add_argument("--config", default="config/config.json")

    p_report = sub.add_parser("report", help="Regenerate LaTeX report from artifacts (if needed)")
    p_report.add_argument("--config", default="config/config.json")

    args = ap.parse_args()

    if args.cmd == "run":
        cfg = RamanConfig.load(args.config)
        run_pipeline(cfg)
        print("Pipeline run complete.")
    elif args.cmd == "report":
        cfg = RamanConfig.load(args.config)
        run_pipeline(cfg)  # for demo, regenerate
        print("Report generated.")
    else:
        ap.print_help(); sys.exit(2)

if __name__ == "__main__":
    main()
