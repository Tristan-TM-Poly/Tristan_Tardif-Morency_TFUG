
import numpy as np
import pandas as pd

def find_peaks_basic(x: np.ndarray, y: np.ndarray, prominence: float = 0.03, min_distance: int = 5):
    dy = np.diff(y)
    sign = np.sign(dy)
    zero_cross = np.where((sign[:-1] > 0) & (sign[1:] < 0))[0] + 1
    peaks = []
    last = -min_distance
    for idx in zero_cross:
        if y[idx] >= prominence and (idx - last) >= min_distance:
            peaks.append(idx); last = idx
    return np.array(peaks, dtype=int)

def half_max_width(x: np.ndarray, y: np.ndarray, idx: int):
    h = y[idx] / 2.0
    i = idx
    while i > 0 and y[i] > h: i -= 1
    x_left = x[i]
    if i < idx and y[i] != y[i+1]:
        x_left = np.interp(h, [y[i], y[i+1]], [x[i], x[i+1]])
    j = idx
    while j < len(y)-1 and y[j] > h: j += 1
    x_right = x[j]
    if j > idx and y[j-1] != y[j]:
        x_right = np.interp(h, [y[j-1], y[j]], [x[j-1], x[j]])
    return max(x_right - x_left, 1e-9)

def integrate_peak(x: np.ndarray, y: np.ndarray, idx: int, window: int = 10):
    i0 = max(0, idx - window)
    i1 = min(len(x)-1, idx + window)
    return np.trapz(y[i0:i1+1], x[i0:i1+1])

def extract_peaks(df: pd.DataFrame, prominence: float, min_distance: int) -> pd.DataFrame:
    x = df['wavenumber'].to_numpy()
    y = df['intensity_proc'].to_numpy()
    pk = find_peaks_basic(x, y, prominence=prominence, min_distance=min_distance)
    rows = []
    for i in pk:
        width = half_max_width(x, y, i)
        area = integrate_peak(x, y, i, window=10)
        rows.append({'wavenumber': x[i], 'height': y[i], 'fwhm': width, 'area': area})
    return pd.DataFrame(rows)
