
import numpy as np
import pandas as pd

def multiscale_features(x: np.ndarray, y: np.ndarray, scales=(3,5,9,17,33)):
    feats = {}
    y = y.astype(float); x = x.astype(float)
    scalelist = []; res_stds = []
    for s in scales:
        w = max(1, int(s))
        if w % 2 == 0: w += 1
        pad = w // 2
        ypad = np.pad(y, (pad, pad), mode='edge')
        kernel = np.ones(w)/w
        y_lp = np.convolve(ypad, kernel, mode='valid')
        res = y - y_lp
        feats[f"lp_mean_s{w}"] = float(np.mean(y_lp))
        feats[f"lp_std_s{w}"] = float(np.std(y_lp))
        feats[f"res_std_s{w}"] = float(np.std(res))
        dx = np.gradient(x); dy = np.gradient(y_lp)
        slope = dy / (dx + 1e-12)
        feats[f"slope_std_s{w}"] = float(np.std(slope))
        scalelist.append(w); res_stds.append(np.std(res))
    if len(res_stds) >= 2:
        s_arr = np.array(scalelist, dtype=float)
        v_arr = np.array(res_stds, dtype=float)
        s_log = np.log(s_arr+1e-9); v_log = np.log(v_arr+1e-9)
        A = np.vstack([s_log, np.ones_like(s_log)]).T
        m, c = np.linalg.lstsq(A, v_log, rcond=None)[0]
        feats["fractal_variance_slope"] = float(m)
    return pd.DataFrame([feats])
