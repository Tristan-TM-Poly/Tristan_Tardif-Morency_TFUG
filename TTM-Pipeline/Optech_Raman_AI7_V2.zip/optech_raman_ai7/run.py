
import json
import numpy as np
import pandas as pd
from pathlib import Path

from .config import RamanConfig
from .io import load_table, save_csv, ensure_parent, list_csvs, save_parquet_optional
from .preprocessing import preprocess
from .peaks import extract_peaks
from .features import feature_vector
from .bayes_multi import fit_blr_multi, predict_blr_multi
from .ood import mahalanobis_params, mahalanobis_dist, threshold_from_dist
from .reporting import write_latex_report
from .standards import match_standards
from .plots import plot_raw_processed, plot_peaks
from .synth import ensure_synth_dataset, synth_spectrum

def run_pipeline(cfg: RamanConfig):
    # Prepare folders
    outdir = Path(cfg.output_dir); outdir.mkdir(parents=True, exist_ok=True)
    repdir = Path(cfg.report_dir); repdir.mkdir(parents=True, exist_ok=True)
    datadir = Path(cfg.input_path); datadir.mkdir(parents=True, exist_ok=True)

    # Data (synth for demo)
    ensure_synth_dataset(cfg.input_path, n=cfg.n_synth, seed=cfg.seed)

    meta = pd.read_csv(datadir/'metadata.csv')
    files = list_csvs(cfg.input_path)

    X_list = []; Y_list = []; peak_tables = []
    example_fig_done = False

    for f in files:
        df = load_table(f)
        dfp = preprocess(df, cfg.smoothing_window, cfg.baseline_order, cfg.normalize)
        peaks_df = extract_peaks(dfp, prominence=cfg.peak_prominence, min_distance=cfg.peak_min_distance)

        # Standards-based calibration (axis shift)
        calib = match_standards(peaks_df)
        if abs(calib['offset_cm1']) > 0:
            dfp['wavenumber'] = dfp['wavenumber'] - calib['offset_cm1']
            peaks_df = extract_peaks(dfp, prominence=cfg.peak_prominence, min_distance=cfg.peak_min_distance)

        peaks_top = peaks_df.sort_values('height', ascending=False).head(10).reset_index(drop=True)
        peak_tables.append((Path(f).name, peaks_top))

        if not example_fig_done:
            plot_raw_processed(dfp, str(outdir/'fig_raw_processed.png'))
            plot_peaks(dfp, peaks_top, str(outdir/'fig_peaks.png'))
            example_fig_done = True

        fv = feature_vector(dfp, peaks_top)
        X_list.append(fv)
        row = meta.loc[meta['file']==Path(f).name]
        # Multi-outputs: dopant_ppm, temperature_C (demo)
        y_multi = np.array([float(row['dopant_ppm'].values[0]), float(row['temperature_C'].values[0])])
        Y_list.append(y_multi)

    X = np.vstack(X_list)
    Y = np.vstack(Y_list)  # (n x 2)

    # BLR multi-output
    post = fit_blr_multi(X, Y, alpha=1.0, beta=100.0)
    mean, var = predict_blr_multi(post, X)

    # OOD
    mu, cov_inv = mahalanobis_params(X)
    d_maha = mahalanobis_dist(X, mu, cov_inv)
    thr = threshold_from_dist(d_maha, 0.95)

    # Save artifacts
    ensure_parent(str(outdir/'peaks_top10.csv'))
    peak_rows = []
    for fname, tab in peak_tables:
        t = tab.copy(); t.insert(0, 'file', fname); peak_rows.append(t)
    if len(peak_rows)>0:
        pd.concat(peak_rows, axis=0).to_csv(outdir/'peaks_top10.csv', index=False)

    preds = pd.DataFrame({
        'file':[Path(f).name for f in files],
        'dopant_ppm_true': Y[:,0],
        'temperature_true': Y[:,1],
        'dopant_ppm_pred': mean[:,0],
        'temperature_pred': mean[:,1],
        'pred_var_shared': var,
        'mahalanobis': d_maha
    })
    preds.to_csv(outdir/'predictions_multi.csv', index=False)

    # Optional Parquet dump
    if not save_parquet_optional(preds, str(outdir/'predictions_multi.parquet')):
        # ignore if parquet backend missing
        pass

    # Report
    ctx = {
        'instrument': cfg.instrument,
        'n_samples': int(X.shape[0]),
        'output': str(outdir),
        'fig_raw': str(outdir/'fig_raw_processed.png'),
        'fig_peaks': str(outdir/'fig_peaks.png'),
        'feat_dim': int(X.shape[1]),
        'n_train': int(X.shape[0]),
        'al_k': int(cfg.active_learning_points),
        'al_grid': 50,
        'ood_thr': float(thr),
    }
    write_latex_report(str(Path(cfg.report_dir)/'report.tex'), ctx)

    # Minimal provenance
    with open(outdir/'provenance.json', 'w', encoding='utf-8') as fp:
        json.dump({'config': cfg.to_dict(), 'n_samples': int(X.shape[0])}, fp, indent=2)

    return {'X': X, 'Y': Y, 'thr': thr}

