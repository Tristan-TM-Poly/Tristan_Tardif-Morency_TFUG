
import numpy as np
from dataclasses import dataclass

@dataclass
class BLRMultiPosterior:
    M: np.ndarray  # (p x q) posterior mean for q outputs
    S: np.ndarray  # (p x p) posterior covariance (shared per-output under IID noise)
    alpha: float
    beta: float

def fit_blr_multi(X: np.ndarray, Y: np.ndarray, alpha: float=1.0, beta: float=100.0) -> BLRMultiPosterior:
    # Y is (n x q), X is (n x p)
    XtX = X.T @ X
    S_inv = alpha * np.eye(X.shape[1]) + beta * XtX
    S = np.linalg.inv(S_inv)
    M = beta * S @ X.T @ Y
    return BLRMultiPosterior(M=M, S=S, alpha=alpha, beta=beta)

def predict_blr_multi(post: BLRMultiPosterior, Xnew: np.ndarray):
    # mean: (n x q), var_diag: (n,) predictive variance per sample (shared across outputs here)
    mean = Xnew @ post.M
    var = (1.0/post.beta) + np.sum(Xnew @ post.S * Xnew, axis=1)
    return mean, var
