
from .io import ensure_parent
import matplotlib.pyplot as plt

def plot_raw_processed(df, outpath: str):
    ensure_parent(outpath)
    fig = plt.figure(figsize=(9,4))
    plt.plot(df['wavenumber'], df['intensity'], label='raw')
    if 'intensity_proc' in df.columns:
        plt.plot(df['wavenumber'], df['intensity_proc'], label='processed')
    plt.xlabel('Wavenumber (cm$^{-1}$)'); plt.ylabel('Intensity (a.u.)')
    plt.legend(); plt.tight_layout(); fig.savefig(outpath, dpi=160); plt.close(fig)

def plot_peaks(dfp, peaks_df, outpath: str):
    ensure_parent(outpath)
    fig = plt.figure(figsize=(9,4))
    plt.plot(dfp['wavenumber'], dfp['intensity_proc'])
    for _, r in peaks_df.iterrows():
        plt.scatter([r['wavenumber']], [r['height']])
    plt.xlabel('Wavenumber (cm$^{-1}$)'); plt.ylabel('Processed intensity (a.u.)')
    plt.tight_layout(); fig.savefig(outpath, dpi=160); plt.close(fig)
