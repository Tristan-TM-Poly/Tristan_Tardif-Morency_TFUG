
import numpy as np
import pandas as pd

def quaternionic_features(x: np.ndarray, y_parallel: np.ndarray, y_perp: np.ndarray):
    # Quaternion proxy components: (intensity, fractal proxy, polarization diff, derivative correlation)
    # No external libs; lightweight statistics to capture TFUG-like structure.
    y_parallel = y_parallel.astype(float)
    y_perp = y_perp.astype(float)
    # Fractal proxy via derivative variability
    dy_par = np.gradient(y_parallel)
    dy_perp = np.gradient(y_perp)
    roughness = float(np.std(dy_par - dy_perp))
    # Log-log slope as crude fractal exponent proxy
    s = np.arange(1, len(y_parallel)+1, dtype=float)
    s_log = np.log(s+1e-9)
    v_log = np.log(np.abs(dy_par)+1e-9)
    A = np.vstack([s_log, np.ones_like(s_log)]).T
    m, c = np.linalg.lstsq(A, v_log, rcond=None)[0]
    D_f = float(-m)  # sign convention
    # Phase/polarization coupling
    corr = float(np.corrcoef(y_parallel, y_perp)[0,1]) if np.std(y_perp)>0 else 0.0
    return pd.DataFrame([{
        "D_f": D_f,
        "polar_roughness": roughness,
        "phase_corr": corr
    }])
