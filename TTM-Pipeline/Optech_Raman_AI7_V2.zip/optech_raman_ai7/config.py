
from dataclasses import dataclass
from typing import Dict, Any
import json

@dataclass
class RamanConfig:
    input_path: str = "data/synth"
    output_dir: str = "artifacts"
    report_dir: str = "report"
    instrument: str = "Demo-Confocal-532nm"
    smoothing_window: int = 7
    baseline_order: int = 3
    peak_prominence: float = 0.03
    peak_min_distance: int = 5
    normalize: bool = True
    active_learning_points: int = 5
    n_synth: int = 32
    seed: int = 1234
    write_parquet: bool = True  # optional

    @staticmethod
    def load(path: str) -> "RamanConfig":
        with open(path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        return RamanConfig(**cfg)

    def to_dict(self) -> Dict[str, Any]:
        return self.__dict__.copy()
