
import numpy as np
import pandas as pd
from .fwt import multiscale_features
from .tfug_fwt import quaternionic_features

def feature_vector(dfp: pd.DataFrame, peaks_top: pd.DataFrame) -> np.ndarray:
    x = dfp['wavenumber'].to_numpy()
    y = dfp['intensity_proc'].to_numpy()
    fwt_df = multiscale_features(x, y)
    stats = {
        'mean_int': float(np.mean(y)),
        'std_int': float(np.std(y)),
        'sum_int': float(np.sum(y)),
    }
    peaks_top = peaks_top.sort_values('height', ascending=False).head(4).reset_index(drop=True)
    for i in range(4):
        if i < len(peaks_top):
            r = peaks_top.iloc[i]
            stats[f'p{i}_h'] = float(r['height']); stats[f'p{i}_a'] = float(r['area']); stats[f'p{i}_w'] = float(r['fwhm'])
        else:
            stats[f'p{i}_h']=0.0; stats[f'p{i}_a']=0.0; stats[f'p{i}_w']=0.0

    vec = pd.concat([pd.DataFrame([stats]), fwt_df], axis=1).fillna(0.0)

    # Optional quaternionic/polarization features if available
    if 'intensity_perp' in dfp.columns:
        q_feats = quaternionic_features(x, dfp['intensity_proc'].to_numpy(), dfp['intensity_perp'].to_numpy())
        vec = pd.concat([vec, q_feats], axis=1)

    return vec.astype(float).to_numpy().ravel()
