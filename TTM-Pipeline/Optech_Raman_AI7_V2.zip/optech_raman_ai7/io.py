
import pandas as pd
from pathlib import Path
from typing import List

def ensure_parent(path: str):
    Path(path).parent.mkdir(parents=True, exist_ok=True)

def save_csv(df: pd.DataFrame, path: str):
    ensure_parent(path); df.to_csv(path, index=False)

def save_parquet_optional(df: pd.DataFrame, path: str) -> bool:
    try:
        ensure_parent(path)
        df.to_parquet(path, index=False)
        return True
    except Exception:
        return False

def load_table(path: str) -> pd.DataFrame:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Missing input file: {p}")
    if p.suffix.lower() in {'.csv', '.txt'}:
        return pd.read_csv(p)
    elif p.suffix.lower() == '.parquet':
        return pd.read_parquet(p)
    else:
        return pd.read_csv(p)

def list_csvs(folder: str) -> List[str]:
    p = Path(folder)
    return [str(q) for q in sorted(p.glob("*.csv")) if q.name != 'metadata.csv']
