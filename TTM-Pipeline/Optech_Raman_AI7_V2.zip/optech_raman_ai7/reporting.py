
from pathlib import Path

def write_latex_report(path: str, context: dict):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    tex = f"""
\documentclass[11pt]{{article}}
\usepackage[a4paper,margin=2.2cm]{{geometry}}
\usepackage{{graphicx}}
\usepackage{{booktabs}}
\usepackage{{siunitx}}
\usepackage{{hyperref}}
\title{{Optech Raman AI‑7 — Rapport (V2 demo)}}
\author{{Pipeline auto}}
\date{{\today}}
\begin{document}
\maketitle

\section*{{Résumé}}
Rapport généré automatiquement : étalonnage standards, prétraitements, pics, features TFUG/FWT, régression bayésienne multi‑sorties, OOD et Active Learning.

\section*{{Configuration}}
Instrument: {context.get('instrument','N/A')}\\
Entrées: {context.get('n_samples',0)} spectres; Sorties: {context.get('output','N/A')}\\

\section*{{Figures}}
\begin{figure}[h]
\centering
\includegraphics[width=0.95\linewidth]{{{context.get('fig_raw','')}}}
\caption{{Spectre brut vs prétraité (exemple)}}\end{figure}

\begin{figure}[h]
\centering
\includegraphics[width=0.95\linewidth]{{{context.get('fig_peaks','')}}}
\caption{{Pics détectés (exemple)}}\end{figure}

\clearpage
\section*{{Bayésien multi‑sorties}}
Dimension des features: {context.get('feat_dim',0)}, N entraînement: {context.get('n_train',0)}.\\
Coverage visé: 95\%.

\section*{{OOD}}
Seuil Mahalanobis (95e): {context.get('ood_thr', 'N/A')}.

\section*{{Active Learning}}
Points proposés: {context.get('al_k',0)} parmi {context.get('al_grid',0)} candidats.

\end{document}
"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(tex)
