
import numpy as np
import pandas as pd

STANDARDS = {
    "Si": [520.7],
    "Polystyrene": [620.0, 1001.0, 1602.0],
    "Quartz": [464.0],
    "Al2O3": [417.0, 577.0, 645.0],
}

def match_standards(peaks_df: pd.DataFrame, standards: dict = STANDARDS, tol_cm1: float = 10.0):
    # Compute average offset from nearest expected standard lines.
    if peaks_df.empty:
        return {"offset_cm1": 0.0, "matches": 0}
    obs = peaks_df["wavenumber"].to_numpy().astype(float)
    diffs = []
    for lines in standards.values():
        for cm1 in lines:
            j = np.argmin(np.abs(obs - cm1))
            if abs(obs[j] - cm1) <= tol_cm1:
                diffs.append(obs[j] - cm1)
    if len(diffs) == 0:
        return {"offset_cm1": 0.0, "matches": 0}
    offset = float(np.mean(diffs))
    return {"offset_cm1": offset, "matches": int(len(diffs))}
