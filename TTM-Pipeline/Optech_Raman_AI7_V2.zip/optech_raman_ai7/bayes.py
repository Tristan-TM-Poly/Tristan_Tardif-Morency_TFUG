
import numpy as np
from dataclasses import dataclass

@dataclass
class BLRPosterior:
    m: np.ndarray  # posterior mean
    S: np.ndarray  # posterior covariance
    alpha: float   # prior precision
    beta: float    # noise precision (1/sigma^2)

def fit_blr(X: np.ndarray, y: np.ndarray, alpha: float=1.0, beta: float=100.0) -> BLRPosterior:
    XtX = X.T @ X
    S_inv = alpha * np.eye(X.shape[1]) + beta * XtX
    S = np.linalg.inv(S_inv)
    m = beta * S @ X.T @ y
    return BLRPosterior(m=m, S=S, alpha=alpha, beta=beta)

def predict_blr(post: BLRPosterior, Xnew: np.ndarray):
    mean = Xnew @ post.m
    var = (1.0/post.beta) + np.sum(Xnew @ post.S * Xnew, axis=1)
    return mean, var
