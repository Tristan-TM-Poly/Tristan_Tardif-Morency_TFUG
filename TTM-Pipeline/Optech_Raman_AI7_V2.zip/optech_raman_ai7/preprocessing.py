
import numpy as np
import pandas as pd

def moving_average(x: np.ndarray, w: int) -> np.ndarray:
    w = max(1, int(w))
    if w % 2 == 0: w += 1
    pad = w // 2
    xpad = np.pad(x, (pad, pad), mode='edge')
    c = np.ones(w) / w
    y = np.convolve(xpad, c, mode='valid')
    return y

def poly_baseline(x: np.ndarray, y: np.ndarray, order: int = 3) -> np.ndarray:
    order = max(1, int(order))
    coeff = np.polyfit(x, y, order)
    base = np.polyval(coeff, x)
    return base

def normalize_area(y: np.ndarray) -> np.ndarray:
    area = np.trapz(np.maximum(y, 0.0))
    if area <= 0: return y
    return y / area

def preprocess(df: pd.DataFrame, smoothing_window: int, baseline_order: int, do_normalize: bool) -> pd.DataFrame:
    x = df['wavenumber'].to_numpy()
    y = df['intensity'].to_numpy()

    y_smooth = moving_average(y, smoothing_window)
    base = poly_baseline(x, y_smooth, baseline_order)
    y_corr = y_smooth - base
    y_corr = np.maximum(y_corr, 0.0)

    if do_normalize:
        y_norm = normalize_area(y_corr)
    else:
        y_norm = y_corr

    out = df.copy()
    out['intensity_smooth'] = y_smooth
    out['baseline'] = base
    out['intensity_proc'] = y_norm
    return out
