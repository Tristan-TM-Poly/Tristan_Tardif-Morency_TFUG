
import numpy as np, pandas as pd
from pathlib import Path
from optech_raman_ai.cli import report_cmd

def make_clean_dir(tmp: Path, n=3):
    tmp.mkdir(parents=True, exist_ok=True)
    for i in range(n):
        x = np.linspace(100, 2000, 512)
        y = 0.02*np.random.randn(512)
        for c in [520, 1000, 1580]:
            y += np.exp(-0.5*((x-c)/6)**2)
        pd.DataFrame({"sample_id":[f"s{i}"]*len(x),"wavenumber_cm1":x,"intensity":y}).to_parquet(tmp/f"s{i}.parquet", index=False)
    return tmp

def test_report_e2e(tmp_path, monkeypatch):
    inp = make_clean_dir(tmp_path/"clean")
    feat_out = tmp_path/"features.parquet"
    figs = tmp_path/"figs"
    ltx = tmp_path/"latex"
    # call Click command function directly (bypassing CLI parsing)
    report_cmd.callback(input_dir=inp, features_out=feat_out, fig_dir=figs, latex_dir=ltx,
                        method="physics", prominence=0.02, distance=5, topk=5, downsample=64)
    assert feat_out.exists()
    assert any(figs.glob("*.png"))
    assert (ltx/"metrics_table.tex").exists()
    assert (ltx/"fig_gallery.tex").exists()
