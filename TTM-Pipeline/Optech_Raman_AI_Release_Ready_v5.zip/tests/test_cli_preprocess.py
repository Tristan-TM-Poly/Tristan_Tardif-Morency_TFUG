
import numpy as np, pandas as pd
from pathlib import Path
from optech_raman_ai.pipelines.preprocess import preprocess_df, PreprocessParams

def demo_parquet(tmp: Path):
    x = np.linspace(100, 2000, 512)
    y = np.sin(x/80.0) + 0.05*np.random.randn(512)
    df = pd.DataFrame({"sample_id":["t"]*len(x),"wavenumber_cm1":x,"intensity":y})
    p = tmp/"in.parquet"; df.to_parquet(p, index=False)
    return df, p

def test_preprocess_df(tmp_path):
    df, pq = demo_parquet(tmp_path)
    params = PreprocessParams(savgol_window=21, savgol_poly=3, als_lambda=1e5, als_p=0.01, area_norm=True)
    out = preprocess_df(df, params)
    assert "intensity" in out.columns
    assert len(out) == len(df)
    # Aire ~1 après normalisation
    x = out["wavenumber_cm1"].to_numpy()
    y = out["intensity"].to_numpy()
    area = float(np.trapz(y, x))
    assert 0.8 <= area <= 1.2
