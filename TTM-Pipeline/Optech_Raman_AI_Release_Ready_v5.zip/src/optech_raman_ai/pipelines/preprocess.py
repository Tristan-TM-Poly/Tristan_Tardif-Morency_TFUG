
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import pandas as pd
import numpy as np
from typing import Optional, Dict, Any

try:
    import yaml
except Exception:
    yaml = None

from scipy.signal import savgol_filter
import scipy.sparse as sp
from scipy.sparse.linalg import spsolve

@dataclass
class PreprocessParams:
    savgol_window: int = 21
    savgol_poly: int = 3
    als_lambda: float = 1.0e5
    als_p: float = 0.01
    area_norm: bool = True

def baseline_als(y: np.ndarray, lam: float = 1e5, p: float = 0.01, niter: int = 10) -> np.ndarray:
    L = len(y)
    D = sp.diags([1, -2, 1], [0, -1, -2], shape=(L, L - 2))
    D = (D @ D.T)
    w = np.ones(L)
    for _ in range(niter):
        W = sp.diags(w, 0)
        Z = W + lam * D
        z = spsolve(Z, w * y)
        w = p * (y > z) + (1 - p) * (y < z)
    return z

def preprocess_df(df: pd.DataFrame, p: PreprocessParams) -> pd.DataFrame:
    df = df.copy()
    x = df["wavenumber_cm1"].to_numpy()
    y = df["intensity"].to_numpy()
    win = p.savgol_window if p.savgol_window % 2 == 1 else p.savgol_window + 1
    y_s = savgol_filter(y, window_length=win, polyorder=p.savgol_poly)
    b = baseline_als(y_s, lam=p.als_lambda, p=p.als_p, niter=10)
    y_c = y_s - b
    if p.area_norm:
        area = np.trapz(y_c, x)
        if area != 0:
            y_c = y_c / area
    df["intensity"] = y_c
    return df

def load_params_yaml(path: Path | str | None) -> PreprocessParams:
    if path is None:
        return PreprocessParams()
    if yaml is None:
        raise RuntimeError("PyYAML is required to load params.yaml")
    d = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    d = d.get("preprocess", d) if isinstance(d, dict) else {}
    return PreprocessParams(
        savgol_window=int(d.get("savgol_window", 21)),
        savgol_poly=int(d.get("savgol_poly", 3)),
        als_lambda=float(d.get("als_lambda", 1.0e5)),
        als_p=float(d.get("als_p", 0.01)),
        area_norm=bool(d.get("area_norm", True)),
    )
