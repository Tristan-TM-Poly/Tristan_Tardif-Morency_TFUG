
import numpy as np
import pandas as pd
from scipy.signal import find_peaks

def features_physics(df: pd.DataFrame, prominence: float=0.01, distance: int=5, topk: int=5) -> pd.DataFrame:
    x = df["wavenumber_cm1"].to_numpy()
    y = df["intensity"].to_numpy()
    peaks, props = find_peaks(y, prominence=prominence, distance=distance)
    prom = props.get("prominences", np.zeros_like(peaks))
    order = np.argsort(prom)[::-1]
    peaks = peaks[order][:topk]
    feats = {
        "n_peaks": int(len(peaks)),
        "y_mean": float(np.mean(y)),
        "y_std": float(np.std(y)),
        "area": float(np.trapz(y, x)),
    }
    for i, p in enumerate(peaks):
        feats[f"peak_{i+1}_pos"] = float(x[p])
        feats[f"peak_{i+1}_height"] = float(y[p])
    return pd.DataFrame([feats])
