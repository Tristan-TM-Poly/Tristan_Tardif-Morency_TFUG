
from __future__ import annotations
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from typing import Optional, Sequence
from scipy.signal import find_peaks

def plot_spectrum_with_peaks(df: pd.DataFrame, out_png: Path, title: Optional[str]=None,
                             prominence: float=0.02, distance: int=5, dpi: int=120) -> Path:
    x = df["wavenumber_cm1"].to_numpy()
    y = df["intensity"].to_numpy()
    peaks, props = find_peaks(y, prominence=prominence, distance=distance)
    fig, ax = plt.subplots(figsize=(8,4.5))
    ax.plot(x, y, label="Intensity")
    if len(peaks):
        ax.plot(x[peaks], y[peaks], "o", ms=4, label="Peaks")
        for p in peaks:
            ax.annotate(f"{x[p]:.0f}", (x[p], y[p]), textcoords="offset points", xytext=(0,6), ha="center", fontsize=8)
    ax.set_xlabel("Wavenumber (cm$^{-1}$)")
    ax.set_ylabel("Intensity (a.u.)")
    if title:
        ax.set_title(title)
    ax.legend()
    out_png.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(out_png, dpi=dpi)
    plt.close(fig)
    return out_png

def plot_folder(input_dir: Path, output_dir: Path, prominence: float=0.02, distance: int=5, dpi: int=120) -> list[Path]:
    paths = []
    for p in sorted(Path(input_dir).glob("*.parquet")):
        df = pd.read_parquet(p)
        out = Path(output_dir) / (p.stem + ".png")
        plot_spectrum_with_peaks(df, out, title=p.stem, prominence=prominence, distance=distance, dpi=dpi)
        paths.append(out)
    return paths
